import { Check } from "lucide-react";
import { OPTIONS, type PricedService } from "../config";
import { optText, useI18n } from "../i18n";
import { hrefOf } from "../lib/router";
import { photo } from "../photos";
import { NextPage, PageHero } from "../components/PageKit";
import { usePlanner } from "../components/Planner";
import { Arrow, Img, Reveal, RevealMask, Shell, btn, cx } from "../components/ui";

const ROMAN = ["I", "II", "III", "IV", "V"];

type ChapterKey = "highlights" | "night" | "versailles" | "disney" | "full";

const CHAPTERS: { key: ChapterKey; photo: string; service: PricedService; options: string[] }[] = [
  { key: "highlights", photo: "eiffelGold", service: "tour", options: ["t2", "t3", "t4"] },
  { key: "night", photo: "bridgeNight", service: "tour", options: ["t2", "t3"] },
  { key: "versailles", photo: "versailles", service: "versailles", options: ["oneway", "return"] },
  { key: "disney", photo: "disney", service: "disney", options: ["oneway", "return"] },
  { key: "full", photo: "montmartreStreet", service: "tour", options: ["t8"] },
];

const STOPS: { place: "eiffel" | "louvre" | "notredame" | "montmartre" | "seine"; photo: string }[] = [
  { place: "eiffel", photo: "eiffelSunset" },
  { place: "louvre", photo: "louvre" },
  { place: "notredame", photo: "notredame" },
  { place: "montmartre", photo: "montmartre" },
  { place: "seine", photo: "seine" },
];

export default function ToursPage() {
  const { t, s, price, cap } = useI18n();
  const planner = usePlanner();
  return (
    <>
      <PageHero page="tours" variant="full" eyebrow={t.tours.eyebrow} title={t.tours.title} sub={t.tours.sub} photos={["louvre"]}>
        <button type="button" onClick={() => planner.open({ service: "tour" })} className={btn.ivory}>
          <span className="eyebrow">{t.hero.ctaPlan}</span>
          <Arrow />
        </button>
        <a href={hrefOf("availability")} className={btn.light}>
          <span className="eyebrow">{t.cal.title}</span>
        </a>
      </PageHero>

      <section aria-label={t.tours.eyebrow} className="bg-ivory py-24 md:py-32">
        <Shell>
          <div className="space-y-24 md:space-y-36">
            {CHAPTERS.map((c, idx) => {
              const p = photo(c.photo);
              const card = c.key === "full" ? null : t.tours.cards[c.key];
              const title = card ? card.t : s.tours.fullT;
              const desc = card ? card.d : s.tours.fullD;
              const meta = card ? card.meta : optText(t, "tour", "t8")?.l ?? "";
              return (
                <article key={c.key} className="grid grid-cols-12 items-center gap-y-10 lg:gap-x-16">
                  <div className={cx("col-span-12 lg:col-span-6", idx % 2 === 1 && "lg:order-2")}>
                    <RevealMask className={cx("relative overflow-hidden bg-night", idx % 2 === 0 ? "arch aspect-[4/5]" : "aspect-[4/5] lg:aspect-[5/6]")}>
                      <Img
                        photo={p}
                        alt={cap(p.key)}
                        sizes="(min-width:1024px) 45vw, 100vw"
                        className="h-full w-full object-cover transition-transform duration-[1600ms] ease-out hover:scale-105"
                      />
                    </RevealMask>
                    <p className="mt-3 font-display text-[0.98rem] italic text-stone">— {cap(p.key)}</p>
                  </div>
                  <Reveal delay={0.1} className="col-span-12 lg:col-span-6">
                    <p className="eyebrow text-golddeep">
                      {s.common.chapter(ROMAN[idx])} · {meta}
                    </p>
                    <h2 className="display mt-4 text-navy [font-size:clamp(2.4rem,4.6vw,3.8rem)]">{title}</h2>
                    <p className="mt-5 max-w-[48ch] text-[1.06rem] leading-relaxed text-stone">{desc}</p>
                    <ul className="mt-8 border-t border-navy/80">
                      {c.options.map((id) => {
                        const o = OPTIONS[c.service].find((x) => x.id === id);
                        const txt = optText(t, c.service, id);
                        if (!o) return null;
                        return (
                          <li key={id} className="border-b border-rule">
                            <button
                              type="button"
                              onClick={() => planner.open({ service: c.service, optionId: id })}
                              className="group flex w-full items-center justify-between gap-5 py-4 text-left"
                            >
                              <span>
                                <span className="block font-display text-[1.3rem] text-navy transition-colors group-hover:text-golddeep">
                                  {txt?.l}
                                </span>
                                <span className="mt-0.5 block text-[0.86rem] text-stone">{txt?.d}</span>
                              </span>
                              <span className="flex shrink-0 items-center gap-4">
                                <span className="display num text-[1.7rem] text-navy">{price(o.price)}</span>
                                <span aria-hidden="true" className="text-golddeep transition-transform duration-500 group-hover:translate-x-1">
                                  →
                                </span>
                              </span>
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                    <p className="mt-4 flex items-center gap-2 text-[0.86rem] text-stone">
                      <Check size={14} className="text-avail" aria-hidden="true" />
                      {t.plan.included}
                    </p>
                  </Reveal>
                </article>
              );
            })}
          </div>
        </Shell>
      </section>

      <section aria-labelledby="stops-title" className="bg-cream py-20 md:py-24">
        <Shell>
          <Reveal>
            <h2 id="stops-title" className="display text-center text-navy [font-size:clamp(2rem,4vw,3rem)]">
              {s.tours.stops}
            </h2>
          </Reveal>
          <div className="no-scrollbar mt-12 flex gap-6 overflow-x-auto pb-2 md:justify-center">
            {STOPS.map((st, i) => {
              const p = photo(st.photo);
              return (
                <Reveal key={st.place} delay={i * 0.06} className="w-[150px] shrink-0 text-center">
                  <div className="mx-auto aspect-square w-[130px] overflow-hidden rounded-full ring-1 ring-gold/50 ring-offset-4 ring-offset-cream">
                    <Img photo={p} alt={cap(p.key)} sizes="130px" className="h-full w-full object-cover" />
                  </div>
                  <p className="mt-4 font-display text-[1.2rem] text-navy">{t.places[st.place]}</p>
                </Reveal>
              );
            })}
          </div>
        </Shell>
      </section>

      <NextPage current="tours" />
    </>
  );
}
