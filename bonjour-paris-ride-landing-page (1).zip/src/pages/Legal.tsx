import { useI18n } from "../i18n";
import { LEGAL, type LegalDoc } from "../legal";
import { Fleuron, Shell, cx } from "../components/ui";

export default function LegalPage({ sub }: { sub: string }) {
  const { t, s, lang } = useI18n();
  const doc: LegalDoc = sub === "privacy" || sub === "terms" ? sub : "notice";
  const d = LEGAL[lang === "fr" ? "fr" : "en"][doc];
  return (
    <>
      <section className="bg-night pb-14 pt-36 text-ivory md:pt-44">
        <Shell>
          <nav aria-label="Breadcrumb" className="eyebrow flex items-center gap-2 text-ivory/60">
            <a href="#/" className="transition-colors hover:text-ivory">
              {s.nav.home}
            </a>
            <span aria-hidden="true" className="text-gold">
              ◆
            </span>
            <span className="text-ivory">{t.footer.legal}</span>
          </nav>
          <h1 className="display mt-6 [font-size:clamp(2.6rem,6vw,4.6rem)]">{d.title}</h1>
          {lang !== "en" && lang !== "fr" && <p className="mt-4 text-ivory/70">{t.legal.onlyEnFr}</p>}
          <div className="mt-8 flex flex-wrap gap-2">
            {(["notice", "privacy", "terms"] as const).map((k) => (
              <a
                key={k}
                href={`#/legal/${k}`}
                aria-current={k === doc ? "page" : undefined}
                className={cx(
                  "border px-4 py-2 text-[0.88rem] transition-colors",
                  k === doc ? "border-gold bg-gold text-night" : "border-ivory/30 text-ivory hover:border-ivory",
                )}
              >
                {t.footer[k]}
              </a>
            ))}
          </div>
        </Shell>
      </section>
      <section className="bg-ivory py-16 md:py-24">
        <Shell>
          <div className="mx-auto max-w-3xl">
            <Fleuron className="text-golddeep" />
            {d.intro && <p className="mt-8 border-l-2 border-limited bg-limited/10 px-4 py-3 text-[0.92rem] text-navy">{d.intro}</p>}
            {d.sections.map((sec) => (
              <div key={sec.h} className="mt-10">
                <h2 className="font-display text-[1.8rem] text-navy">{sec.h}</h2>
                {sec.p.map((p) => (
                  <p key={p} className="mt-3 leading-relaxed text-stone">
                    {p}
                  </p>
                ))}
              </div>
            ))}
          </div>
        </Shell>
      </section>
    </>
  );
}
