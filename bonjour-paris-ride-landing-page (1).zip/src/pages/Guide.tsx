import { motion, useReducedMotion } from "framer-motion";
import { OPTIONS } from "../config";
import { optText, useI18n } from "../i18n";
import { scrollToId } from "../lib/router";
import { photo } from "../photos";
import { Crumbs, NextPage } from "../components/PageKit";
import { EASE, Fleuron, Img, Parallax, Reveal, RevealMask, Shell, cx, rich } from "../components/ui";

const CHAPTER_PHOTOS = ["cdg", "eiffelSunset", "montmartre", "louvre", "versaillesGold", "disney2", "giverny", "croissant"];
const ROMAN = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII"];

interface Dest {
  id: string;
  label: string;
  km: number;
  min: [number, number];
  x: number;
  y: number;
  left: boolean;
}

function useDestinations(): Dest[] {
  const { t } = useI18n();
  const air = (id: string): [number, number] => OPTIONS.airport.find((o) => o.id === id)?.travel ?? [45, 60];
  return [
    { id: "cdg", label: optText(t, "airport", "cdg")?.l ?? "CDG", km: 30, min: air("cdg"), x: 372, y: 150, left: false },
    { id: "ory", label: optText(t, "airport", "ory")?.l ?? "ORY", km: 18, min: air("ory"), x: 318, y: 300, left: false },
    { id: "bva", label: optText(t, "airport", "bva")?.l ?? "BVA", km: 85, min: air("bva"), x: 262, y: 52, left: false },
    { id: "versailles", label: t.places.versailles, km: 20, min: [35, 45], x: 214, y: 248, left: true },
    { id: "disney", label: t.places.disney, km: 40, min: [45, 60], x: 452, y: 238, left: false },
    { id: "giverny", label: t.places.giverny, km: 75, min: [70, 90], x: 88, y: 160, left: false },
    { id: "fontainebleau", label: t.places.fontainebleau, km: 65, min: [60, 80], x: 372, y: 398, left: false },
  ];
}

/** Schematic map — the Seine flows from Fontainebleau through Paris to Giverny. */
function DistanceMap({ dests }: { dests: Dest[] }) {
  const reduce = useReducedMotion();
  return (
    <svg viewBox="0 0 600 440" className="w-full" aria-hidden="true">
      <defs>
        <radialGradient id="paris-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#c6a770" stopOpacity="0.35" />
          <stop offset="100%" stopColor="#c6a770" stopOpacity="0" />
        </radialGradient>
      </defs>
      <motion.path
        d="M20 146 C70 150 90 168 140 178 S230 205 262 214 S312 228 330 248 S352 300 360 336 S372 392 384 440"
        fill="none"
        stroke="#6f8fc9"
        strokeOpacity="0.55"
        strokeWidth="3"
        strokeLinecap="round"
        initial={reduce ? { pathLength: 1 } : { pathLength: 0 }}
        whileInView={{ pathLength: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 2.2, ease: "easeInOut" }}
      />
      <circle cx={300} cy={225} r={70} fill="url(#paris-glow)" />
      {dests.map((d, i) => (
        <motion.line
          key={d.id}
          x1={300}
          y1={225}
          x2={d.x}
          y2={d.y}
          stroke="#c6a770"
          strokeOpacity="0.5"
          strokeDasharray="3 5"
          initial={reduce ? { opacity: 1 } : { opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 + i * 0.12, duration: 0.6 }}
        />
      ))}
      {dests.map((d) => (
        <g key={`p-${d.id}`}>
          <circle cx={d.x} cy={d.y} r={5} fill="#c6a770" />
          <circle cx={d.x} cy={d.y} r={10} fill="none" stroke="#c6a770" strokeOpacity="0.35" />
          <text
            x={d.left ? d.x - 16 : d.x + 16}
            y={d.y + 5}
            textAnchor={d.left ? "end" : "start"}
            fill="#faf6ee"
            style={{ font: "500 16px var(--font-display)" }}
          >
            {d.label}
          </text>
        </g>
      ))}
      <circle cx={300} cy={225} r={9} fill="#e2575d" />
      <text x={300} y={260} textAnchor="middle" fill="#faf6ee" style={{ font: "italic 600 21px var(--font-display)" }}>
        Paris
      </text>
    </svg>
  );
}

export default function GuidePage() {
  const { t, s, cap } = useI18n();
  const reduce = useReducedMotion();
  const cover = photo("arc");
  const dests = useDestinations();

  return (
    <>
      <section className="relative isolate overflow-hidden bg-night pb-16 pt-36 text-ivory md:pb-24 md:pt-44">
        <Parallax className="absolute inset-0 -z-20" amount={6}>
          <Img photo={cover} alt="" eager sizes="100vw" className="h-full w-full object-cover opacity-75" />
        </Parallax>
        <div aria-hidden="true" className="absolute inset-0 -z-10 bg-[linear-gradient(180deg,rgba(11,18,34,0.55),rgba(11,18,34,0.25)_45%,rgba(11,18,34,0.92))]" />
        <Shell>
          <Crumbs page="guide" on="dark" />
          <motion.div
            initial={reduce ? { opacity: 0 } : { opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2, ease: EASE }}
            className="mt-10 max-w-2xl border border-ivory/25 bg-night/55 p-8 backdrop-blur-md md:p-12"
          >
            <div className="flex items-center justify-between gap-4 border-b border-ivory/20 pb-4">
              <span className="font-display text-[1.35rem] italic text-gold">Bonjour Paris</span>
              <span className="eyebrow num text-ivory/70">{s.guide.edition(new Date().getFullYear())}</span>
            </div>
            <p className="eyebrow mt-8 text-gold">{s.guide.eyebrow}</p>
            <h1 className="display mt-4 [font-size:clamp(3rem,7vw,5.6rem)] [&_em]:text-gold">{rich(s.guide.title)}</h1>
            <p className="mt-6 text-[1.06rem] leading-relaxed text-ivory/85">{s.guide.sub}</p>
          </motion.div>
          <p className="mt-8 font-display text-[1rem] italic text-ivory/65">— {cap(cover.key)}</p>
        </Shell>
      </section>

      <section aria-labelledby="toc-title" className="bg-ivory py-20 md:py-24">
        <Shell>
          <div className="grid grid-cols-12 gap-y-8 lg:gap-x-16">
            <Reveal className="col-span-12 lg:col-span-4">
              <Fleuron className="text-golddeep" />
              <h2 id="toc-title" className="display mt-5 text-navy [font-size:clamp(2.4rem,4.4vw,3.6rem)]">
                {s.guide.contents}
              </h2>
            </Reveal>
            <ol className="col-span-12 grid grid-cols-1 gap-x-10 sm:grid-cols-2 lg:col-span-8">
              {s.guide.chapters.map((c, i) => (
                <li key={c.t}>
                  <button type="button" onClick={() => scrollToId(`ch-${i}`)} className="group flex w-full items-baseline gap-4 border-b border-rule py-4 text-left">
                    <span className="w-8 shrink-0 font-display text-[1.2rem] italic text-golddeep">{ROMAN[i]}</span>
                    <span className="font-display text-[1.35rem] text-navy transition-colors group-hover:text-golddeep">{c.t}</span>
                    <span aria-hidden="true" className="ml-auto text-golddeep opacity-0 transition-opacity group-hover:opacity-100">
                      ↓
                    </span>
                  </button>
                </li>
              ))}
            </ol>
          </div>
        </Shell>
      </section>

      <section className="bg-cream py-24 md:py-32">
        <Shell>
          <div className="space-y-24 md:space-y-32">
            {s.guide.chapters.map((c, i) => {
              const p = photo(CHAPTER_PHOTOS[i] ?? "seine");
              const flip = i % 2 === 1;
              return (
                <article key={c.t} id={`ch-${i}`} className="grid scroll-mt-28 grid-cols-12 items-center gap-y-10 lg:gap-x-16">
                  <div className={cx("col-span-12 lg:col-span-5", flip && "lg:order-2")}>
                    <RevealMask className={cx("relative overflow-hidden bg-night", flip ? "aspect-[4/5]" : "arch aspect-[4/5]")}>
                      <Img photo={p} alt={cap(p.key)} sizes="(min-width:1024px) 38vw, 100vw" className="h-full w-full object-cover" />
                    </RevealMask>
                    <p className="mt-3 font-display text-[0.98rem] italic text-stone">— {cap(p.key)}</p>
                  </div>
                  <Reveal delay={0.1} className="col-span-12 lg:col-span-7">
                    <p className="eyebrow text-golddeep">{s.common.chapter(ROMAN[i])}</p>
                    <h2 className="display mt-4 text-navy [font-size:clamp(2.4rem,4.6vw,3.8rem)]">{c.t}</h2>
                    <p className="mt-4 font-display text-[1.4rem] italic leading-snug text-stone">{c.d}</p>
                    <ol className="mt-8 space-y-5">
                      {c.tips.map((tip, k) => (
                        <li key={k} className="flex gap-5 border-t border-rule pt-5">
                          <span className="display num text-[1.6rem] leading-none text-golddeep">{String(k + 1).padStart(2, "0")}</span>
                          <span className="text-[1.02rem] leading-relaxed text-navy">{tip}</span>
                        </li>
                      ))}
                    </ol>
                  </Reveal>
                </article>
              );
            })}
          </div>
        </Shell>
      </section>

      <section aria-labelledby="dist-title" className="bg-night py-24 text-ivory md:py-32">
        <Shell>
          <div className="grid grid-cols-12 items-center gap-y-12 lg:gap-x-16">
            <Reveal className="col-span-12 lg:col-span-5">
              <h2 id="dist-title" className="display text-ivory [font-size:clamp(2.4rem,4.6vw,3.8rem)] [&_em]:text-gold">
                {rich(s.guide.distT)}
              </h2>
              <p className="mt-5 text-[1rem] leading-relaxed text-ivory/70">{s.guide.distNote}</p>
              <dl className="mt-8 border-t border-ivory/15">
                {dests.map((d) => (
                  <div key={d.id} className="flex items-baseline justify-between gap-4 border-b border-ivory/10 py-3.5">
                    <dt className="font-display text-[1.25rem]">{d.label}</dt>
                    <dd className="num shrink-0 text-[0.92rem] text-ivory/75">
                      {d.km} km · {t.common.minutes(d.min[0], d.min[1])}
                    </dd>
                  </div>
                ))}
              </dl>
            </Reveal>
            <Reveal delay={0.1} className="col-span-12 lg:col-span-7">
              <DistanceMap dests={dests} />
            </Reveal>
          </div>
        </Shell>
      </section>

      <NextPage current="guide" />
    </>
  );
}
