import { LINKS, waLink } from "../config";
import { useI18n } from "../i18n";
import { usePublicContent } from "../lib/store";
import { NextPage, PageHero } from "../components/PageKit";
import { ReviewCard, StoriesInvite } from "../components/Stories";
import { Heading, Reveal, Shell, btn } from "../components/ui";

export default function ReviewsPage() {
  const { t } = useI18n();
  const { reviews } = usePublicContent();
  const leave = LINKS.writeReview || waLink(t.stories.waMsg);
  return (
    <>
      <PageHero page="reviews" variant="band" eyebrow={t.stories.eyebrow} title={t.stories.title} sub={t.stories.pageSub} photos={["seine"]}>
        {LINKS.reviews && (
          <a href={LINKS.reviews} target="_blank" rel="noopener noreferrer" className={btn.ivory}>
            <span className="eyebrow">{t.stories.external}</span> ↗
          </a>
        )}
        <a href={leave} target="_blank" rel="noopener noreferrer" className={btn.light}>
          <span className="eyebrow">{t.stories.leave}</span>
        </a>
      </PageHero>

      <section className="bg-cream py-20 md:py-28">
        <Shell>
          <Heading center eyebrow={t.stories.eyebrow} title={t.stories.pageTitle} className="mb-14 md:mb-16" />
          {reviews.length ? (
            <div className="columns-1 gap-6 md:columns-2 lg:columns-3">
              {reviews.map((r) => (
                <Reveal key={r.id} className="mb-6 break-inside-avoid">
                  <ReviewCard r={r} />
                </Reveal>
              ))}
            </div>
          ) : (
            <Reveal>
              <StoriesInvite placeholders={2} />
            </Reveal>
          )}
        </Shell>
      </section>

      <NextPage current="reviews" />
    </>
  );
}
