import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useMemo, useState } from "react";
import { Mail, Phone, Search } from "lucide-react";
import { mailLink, telLink, waLink } from "../config";
import { useI18n } from "../i18n";
import { NextPage, PageHero } from "../components/PageKit";
import { EASE, Reveal, Shell, WhatsAppIcon, cx } from "../components/ui";

/** Question indexes per group: booking & payment · airports & the car · tours & groups */
const GROUPS = [
  [0, 1, 2, 6],
  [3, 4],
  [5, 7],
];

const norm = (x: string) =>
  x
    .toLocaleLowerCase()
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "");

export default function FAQPage() {
  const { t, s } = useI18n();
  const reduce = useReducedMotion();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<number | null>(0);
  const query = norm(q.trim());

  const groups = useMemo(
    () =>
      GROUPS.map((idx, g) => ({
        title: s.faq.groups[g] ?? "",
        items: idx
          .map((i) => ({ i, item: t.faq.items[i] }))
          .filter(({ item }) => item && (!query || norm(`${item.q} ${item.a}`).includes(query))),
      })).filter((g) => g.items.length),
    [query, s, t],
  );

  const contact = "inline-flex items-center gap-3 border border-ivory/20 px-5 py-3.5 transition-colors hover:border-gold hover:text-gold";

  return (
    <>
      <PageHero page="faq" variant="band" eyebrow={t.faq.eyebrow} title={t.faq.title} sub={t.faq.sub} photos={["montmartreStreet"]} />

      <section className="bg-ivory py-20 md:py-28">
        <Shell>
          <div className="grid grid-cols-12 gap-y-12 lg:gap-x-16">
            <div className="col-span-12 lg:col-span-8">
              <label className="relative block">
                <span className="sr-only">{s.faq.search}</span>
                <Search size={18} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-golddeep" aria-hidden="true" />
                <input
                  type="search"
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder={s.faq.search}
                  className="w-full border border-rule bg-[#fffdf8] py-4 pl-12 pr-4 text-[1rem] text-navy placeholder:text-stone/60 focus:border-golddeep focus:outline-none"
                />
              </label>

              {groups.length === 0 && <p className="mt-10 font-display text-[1.25rem] italic text-stone">{s.faq.none}</p>}

              {groups.map((g) => (
                <div key={g.title} className="mt-12">
                  <h2 className="eyebrow text-golddeep">{g.title}</h2>
                  <div className="mt-4 border-t border-navy">
                    {g.items.map(({ i, item }) => {
                      const isOpen = open === i || query.length > 0;
                      return (
                        <div key={i} className="border-b border-rule">
                          <h3>
                            <button
                              type="button"
                              id={`faq-b-${i}`}
                              aria-expanded={isOpen}
                              aria-controls={`faq-p-${i}`}
                              onClick={() => setOpen(open === i ? null : i)}
                              className="group flex w-full items-start justify-between gap-6 py-6 text-left"
                            >
                              <span
                                className={cx(
                                  "font-display text-[1.3rem] leading-snug transition-colors md:text-[1.5rem]",
                                  isOpen ? "text-golddeep" : "text-navy group-hover:text-golddeep",
                                )}
                              >
                                {item.q}
                              </span>
                              <span
                                aria-hidden="true"
                                className={cx("relative mt-2 h-4 w-4 shrink-0 transition-transform duration-500", isOpen ? "rotate-45 text-golddeep" : "text-navy")}
                              >
                                <span className="absolute left-0 top-1/2 h-px w-full -translate-y-1/2 bg-current" />
                                <span className="absolute left-1/2 top-0 h-full w-px -translate-x-1/2 bg-current" />
                              </span>
                            </button>
                          </h3>
                          <AnimatePresence initial={false}>
                            {isOpen && (
                              <motion.div
                                id={`faq-p-${i}`}
                                role="region"
                                aria-labelledby={`faq-b-${i}`}
                                initial={reduce ? { opacity: 0 } : { height: 0, opacity: 0 }}
                                animate={{ height: "auto", opacity: 1 }}
                                exit={reduce ? { opacity: 0 } : { height: 0, opacity: 0 }}
                                transition={{ duration: 0.45, ease: EASE }}
                                className="overflow-hidden"
                              >
                                <p className="max-w-[64ch] pb-7 pr-8 text-[1.02rem] leading-relaxed text-stone">{item.a}</p>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            <aside className="col-span-12 lg:col-span-4">
              <Reveal className="bg-night p-8 text-ivory lg:sticky lg:top-28">
                <p className="font-display text-[1.9rem] leading-tight">{s.faq.stillT}</p>
                <p className="mt-3 text-[0.98rem] leading-relaxed text-ivory/70">{s.faq.stillD}</p>
                <div className="mt-7 flex flex-col gap-3">
                  <a href={waLink(t.contact.waMsg)} target="_blank" rel="noopener noreferrer" className={contact}>
                    <WhatsAppIcon className="h-4 w-4" />
                    <span className="eyebrow">{t.common.whatsapp}</span>
                  </a>
                  <a href={telLink} className={contact}>
                    <Phone size={15} aria-hidden="true" />
                    <span className="eyebrow">{t.common.call}</span>
                  </a>
                  <a href={mailLink(t.cal.subject)} className={contact}>
                    <Mail size={15} aria-hidden="true" />
                    <span className="eyebrow">{t.common.email}</span>
                  </a>
                </div>
              </Reveal>
            </aside>
          </div>
        </Shell>
      </section>

      <NextPage current="faq" />
    </>
  );
}
