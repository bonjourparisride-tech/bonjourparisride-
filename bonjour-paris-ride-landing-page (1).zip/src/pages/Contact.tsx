import { motion, useReducedMotion } from "framer-motion";
import { useState, type FormEvent, type ReactNode } from "react";
import { Mail, Phone, UserPlus } from "lucide-react";
import { CONTACT, DATA, mailLink, telLink, waLink } from "../config";
import { useI18n } from "../i18n";
import { photo } from "../photos";
import { Crumbs, NextPage } from "../components/PageKit";
import { Arrow, EASE, Eyebrow, Field, Img, Item, Parallax, Reveal, Shell, Stagger, WhatsAppIcon, btn, cx, inputCls, rich } from "../components/ui";

function downloadContact() {
  const vcf = [
    "BEGIN:VCARD",
    "VERSION:3.0",
    "FN:Bonjour Paris Ride",
    "ORG:Bonjour Paris Ride",
    `TEL;TYPE=CELL:${CONTACT.phone}`,
    `EMAIL:${CONTACT.email}`,
    "NOTE:Private driver in Paris — airport transfers, Paris tours, Versailles, Disneyland Paris.",
    "END:VCARD",
  ].join("\r\n");
  const url = URL.createObjectURL(new Blob([vcf], { type: "text/vcard" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = "bonjour-paris-ride.vcf";
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export default function ContactPage() {
  const { t, s, cap } = useI18n();
  const reduce = useReducedMotion();
  const hero = photo("terrace");
  const [f, setF] = useState({ name: "", email: "", phone: "", message: "" });
  const [state, setState] = useState<"idle" | "sending" | "sent" | "ready">("idle");
  const [err, setErr] = useState("");
  const [saved, setSaved] = useState(false);
  const set = (p: Partial<typeof f>) => setF((x) => ({ ...x, ...p }));

  const lines = [s.contact.subject, "", f.message.trim(), ""];
  if (f.name.trim()) lines.push(`${t.plan.name}: ${f.name.trim()}`);
  if (f.email.trim()) lines.push(`${t.plan.email}: ${f.email.trim()}`);
  if (f.phone.trim()) lines.push(`${t.plan.phone}: ${f.phone.trim()}`);
  const text = lines.join("\n");

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!f.email.trim() && !f.phone.trim()) {
      setErr(t.plan.errContact);
      return;
    }
    setErr("");
    if (!DATA.formEndpoint) {
      setState("ready");
      return;
    }
    setState("sending");
    try {
      const res = await fetch(DATA.formEndpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ kind: "message", ...f, message: text, _subject: `Bonjour Paris Ride — ${s.contact.subject}` }),
      });
      if (!res.ok) throw new Error(String(res.status));
      setState("sent");
    } catch {
      setState("ready");
    }
  };

  const cards: { key: string; href: string; ext: boolean; icon: ReactNode; title: string; sub: string; value: string }[] = [
    { key: "wa", href: waLink(t.contact.waMsg), ext: true, icon: <WhatsAppIcon className="h-5 w-5" />, title: t.common.whatsapp, sub: t.contact.wa, value: CONTACT.phoneDisplay },
    { key: "tel", href: telLink, ext: false, icon: <Phone size={19} aria-hidden="true" />, title: t.common.call, sub: t.contact.call, value: CONTACT.phoneDisplay },
    { key: "mail", href: mailLink(s.contact.subject), ext: false, icon: <Mail size={19} aria-hidden="true" />, title: t.common.email, sub: t.contact.email, value: CONTACT.email },
  ];

  return (
    <>
      <section className="relative isolate overflow-hidden bg-night pb-40 pt-40 text-ivory md:pb-48 md:pt-48">
        <Parallax className="absolute inset-0 -z-20" amount={6}>
          <Img photo={hero} alt="" eager sizes="100vw" className="h-full w-full object-cover opacity-70" />
        </Parallax>
        <div
          aria-hidden="true"
          className="absolute inset-0 -z-10 bg-[linear-gradient(180deg,rgba(11,18,34,0.72),rgba(11,18,34,0.45)_45%,rgba(11,18,34,0.92))]"
        />
        <Shell>
          <Crumbs page="contact" on="dark" />
          <Eyebrow on="dark" className="mt-8">
            {t.contact.eyebrow}
          </Eyebrow>
          <motion.h1
            initial={reduce ? { opacity: 0 } : { opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.2, ease: EASE }}
            className="display mt-6 max-w-[14ch] text-ivory [font-size:clamp(3rem,7vw,5.8rem)] [&_em]:text-gold"
          >
            {rich(t.contact.title)}
          </motion.h1>
          <p className="mt-6 max-w-[52ch] text-[1.08rem] leading-relaxed text-ivory/85">{t.contact.sub}</p>
          <p className="mt-8 font-display text-[1rem] italic text-ivory/65">— {cap(hero.key)}</p>
        </Shell>
      </section>

      <section className="relative z-10 -mt-28 pb-8 md:-mt-32">
        <Shell>
          <Stagger className="grid grid-cols-1 gap-4 md:grid-cols-3">
            {cards.map((c) => (
              <Item key={c.key}>
                <a
                  href={c.href}
                  {...(c.ext ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                  className="group flex h-full flex-col bg-[#fffdf8] p-7 shadow-[0_40px_80px_-40px_rgba(11,18,34,0.6)] ring-1 ring-gold/30 transition-all duration-500 hover:-translate-y-1 hover:ring-golddeep"
                >
                  <span className="flex h-12 w-12 items-center justify-center rounded-full bg-navy text-ivory transition-colors duration-500 group-hover:bg-golddeep">
                    {c.icon}
                  </span>
                  <p className="mt-7 font-display text-[1.8rem] text-navy">{c.title}</p>
                  <p className="eyebrow mt-1.5 text-golddeep">{c.sub}</p>
                  <p className="num mt-6 break-all text-[1rem] text-navy">{c.value}</p>
                  <span aria-hidden="true" className="mt-auto pt-6 text-golddeep transition-transform duration-500 group-hover:translate-x-1">
                    →
                  </span>
                </a>
              </Item>
            ))}
          </Stagger>
        </Shell>
      </section>

      <section aria-labelledby="msg-title" className="bg-ivory py-20 md:py-28">
        <Shell>
          <div className="grid grid-cols-12 gap-y-12 lg:gap-x-16">
            <Reveal className="col-span-12 lg:col-span-5">
              <Eyebrow>{s.nav.contact}</Eyebrow>
              <h2 id="msg-title" className="display mt-6 text-navy [font-size:clamp(2.4rem,4.8vw,3.8rem)] [&_em]:text-golddeep">
                {rich(s.contact.formT)}
              </h2>
              <ul className="mt-8 space-y-3 text-[1rem] text-navy">
                <li className="flex items-center gap-3">
                  <span aria-hidden="true" className="h-1.5 w-1.5 rotate-45 bg-golddeep" />
                  {t.contact.langs}
                </li>
                <li className="flex items-center gap-3">
                  <span aria-hidden="true" className="h-1.5 w-1.5 rotate-45 bg-golddeep" />
                  {t.contact.hours}
                </li>
              </ul>
              <button
                type="button"
                onClick={() => {
                  downloadContact();
                  setSaved(true);
                }}
                className={cx(btn.ghost, "mt-8")}
              >
                <UserPlus size={15} aria-hidden="true" />
                <span className="eyebrow">{saved ? t.contact.saved : t.contact.save}</span>
              </button>
            </Reveal>

            <Reveal delay={0.1} className="col-span-12 lg:col-span-7">
              <div className="border border-rule bg-[#fffdf8] p-6 shadow-[0_50px_100px_-70px_rgba(11,18,34,0.6)] md:p-10">
                {state === "sent" || state === "ready" ? (
                  <div role="status" aria-live="polite">
                    <p className="display text-[2.4rem] text-navy">{s.contact.sentT}</p>
                    <p className="mt-3 text-[1rem] leading-relaxed text-stone">{state === "sent" ? s.contact.sentD : s.contact.readyD}</p>
                    <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
                      <a href={waLink(text)} target="_blank" rel="noopener noreferrer" className={state === "sent" ? btn.ghost : btn.gold}>
                        <WhatsAppIcon className="h-4 w-4" />
                        <span className="eyebrow">{t.plan.sendWa}</span>
                      </a>
                      <a href={mailLink(s.contact.subject, text)} className={btn.ghost}>
                        <Mail size={15} aria-hidden="true" />
                        <span className="eyebrow">{t.plan.sendEmail}</span>
                      </a>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={submit} className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <Field label={t.plan.name} className="sm:col-span-2">
                      <input value={f.name} onChange={(e) => set({ name: e.target.value })} autoComplete="name" className={inputCls} />
                    </Field>
                    <Field label={t.plan.email}>
                      <input type="email" value={f.email} onChange={(e) => set({ email: e.target.value })} autoComplete="email" className={inputCls} />
                    </Field>
                    <Field label={t.plan.phone}>
                      <input type="tel" value={f.phone} onChange={(e) => set({ phone: e.target.value })} autoComplete="tel" className={inputCls} />
                    </Field>
                    <Field label={s.contact.message} className="sm:col-span-2">
                      <textarea
                        required
                        rows={5}
                        value={f.message}
                        onChange={(e) => set({ message: e.target.value })}
                        placeholder={s.contact.messagePh}
                        className={cx(inputCls, "resize-y")}
                      />
                    </Field>
                    {err && (
                      <p role="alert" className="text-[0.9rem] text-red sm:col-span-2">
                        {err}
                      </p>
                    )}
                    <div className="flex flex-col gap-4 border-t border-rule pt-6 sm:col-span-2 sm:flex-row sm:items-center sm:justify-between">
                      <p className="max-w-[40ch] text-[0.84rem] leading-snug text-stone">
                        {t.plan.contactHint} {t.plan.privacy}
                      </p>
                      <button type="submit" disabled={state === "sending"} className={btn.navy}>
                        <span className="eyebrow">{state === "sending" ? t.plan.sending : s.contact.send}</span>
                        <Arrow />
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </Reveal>
          </div>
        </Shell>
      </section>

      <NextPage current="contact" />
    </>
  );
}
