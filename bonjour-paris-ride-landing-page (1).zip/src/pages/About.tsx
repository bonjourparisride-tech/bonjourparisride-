import { useEffect } from "react";
import { Clock, HeartHandshake, Route, ShieldCheck } from "lucide-react";
import { useI18n } from "../i18n";
import { scrollToId } from "../lib/router";
import { CarImage, LuggageDiagram } from "../components/Car";
import { NextPage, PageHero } from "../components/PageKit";
import { usePlanner } from "../components/Planner";
import { Arrow, Eyebrow, Frame, Heading, Item, Reveal, Shell, Stagger, btn, cx } from "../components/ui";

const VALUE_ICONS = [Clock, ShieldCheck, HeartHandshake, Route];

export default function AboutPage({ params }: { params: URLSearchParams }) {
  const { t, s } = useI18n();
  const planner = usePlanner();
  const qs = params.get("s");

  useEffect(() => {
    if (qs !== "car") return;
    const id = window.setTimeout(() => scrollToId("car"), 500);
    return () => window.clearTimeout(id);
  }, [qs]);

  return (
    <>
      <PageHero page="about" variant="split" eyebrow={s.about.eyebrow} title={s.about.title} sub={s.about.sub} photos={["rooftops"]}>
        <button type="button" onClick={() => scrollToId("car")} className={btn.navy}>
          <span className="eyebrow">{s.home.carCta}</span>
          <Arrow />
        </button>
      </PageHero>

      <section aria-labelledby="story-title" className="bg-cream py-24 md:py-32">
        <Shell>
          <div className="grid grid-cols-12 gap-y-12 lg:gap-x-16">
            <Reveal className="col-span-12 lg:col-span-5">
              <Eyebrow>{s.about.eyebrow}</Eyebrow>
              <h2 id="story-title" className="display mt-6 text-navy [font-size:clamp(2.4rem,4.8vw,3.8rem)]">
                {s.about.storyT}
              </h2>
              <p aria-hidden="true" className="mt-8 font-display text-[2.2rem] italic leading-none text-golddeep">
                « Bonjour. »
              </p>
            </Reveal>
            <div className="col-span-12 space-y-6 lg:col-span-7">
              {s.about.story.map((para, i) => (
                <Reveal key={i} delay={i * 0.08}>
                  <p className={i === 0 ? "font-display text-[1.6rem] leading-snug text-navy md:text-[1.9rem]" : "text-[1.06rem] leading-relaxed text-stone"}>
                    {para}
                  </p>
                </Reveal>
              ))}
            </div>
          </div>
          <Stagger className="mt-20 grid grid-cols-1 gap-px bg-rule sm:grid-cols-2 lg:grid-cols-4">
            {s.about.values.map((v, i) => {
              const Icon = VALUE_ICONS[i] ?? ShieldCheck;
              return (
                <Item key={v.t} className="group bg-cream p-7 transition-colors duration-500 hover:bg-ivory">
                  <span className="flex h-12 w-12 items-center justify-center rounded-full border border-gold text-golddeep transition-colors duration-500 group-hover:bg-golddeep group-hover:text-ivory">
                    <Icon size={19} aria-hidden="true" />
                  </span>
                  <h3 className="mt-6 font-display text-[1.6rem] text-navy">{v.t}</h3>
                  <p className="mt-2 text-[0.96rem] leading-relaxed text-stone">{v.d}</p>
                </Item>
              );
            })}
          </Stagger>
        </Shell>
      </section>

      <section id="car" aria-labelledby="car-title" className="scroll-mt-24 bg-ivory py-24 md:py-32">
        <Shell>
          <Heading id="car-title" eyebrow={s.about.carEyebrow} title={s.about.carTitle} sub={s.about.carSub} />
          <div className="mt-14 grid grid-cols-12 gap-4 md:mt-20 md:gap-6">
            <Reveal className="col-span-12 lg:col-span-8">
              <Frame caption={s.about.slots.front}>
                <div className="aspect-[16/10]">
                  <CarImage slot="front" sizes="(min-width:1024px) 60vw, 100vw" />
                </div>
              </Frame>
            </Reveal>
            <Reveal delay={0.1} className="col-span-12 sm:col-span-6 lg:col-span-4">
              <Frame caption={s.about.slots.side}>
                <div className="aspect-[4/3] lg:aspect-[4/5]">
                  <CarImage slot="side" sizes="(min-width:1024px) 30vw, 50vw" />
                </div>
              </Frame>
            </Reveal>
            <Reveal className="col-span-12 sm:col-span-6 lg:col-span-4">
              <Frame caption={s.about.slots.interior}>
                <div className="aspect-[4/3] lg:aspect-[4/5]">
                  <CarImage slot="interior" sizes="(min-width:1024px) 30vw, 50vw" />
                </div>
              </Frame>
            </Reveal>
            <Reveal delay={0.1} className="col-span-12 lg:col-span-8">
              <Frame caption={s.about.slots.luggage}>
                <div className="aspect-[16/10]">
                  <CarImage slot="luggage" sizes="(min-width:1024px) 60vw, 100vw" />
                </div>
              </Frame>
            </Reveal>
          </div>

          <div className="mt-16 grid grid-cols-12 gap-y-12 lg:gap-x-16">
            <Reveal className="col-span-12 lg:col-span-7">
              <p className="eyebrow text-golddeep">{t.why.specsT}</p>
              <dl className="mt-4 border-t border-navy">
                {t.why.specs.map(([k, v]) => (
                  <div key={k} className="grid grid-cols-[8.5rem_1fr] gap-4 border-b border-rule py-4 sm:grid-cols-[11rem_1fr]">
                    <dt className="eyebrow pt-1 text-stone">{k}</dt>
                    <dd className="font-display text-[1.2rem] text-navy">{v}</dd>
                  </div>
                ))}
              </dl>
              <p className="mt-6 max-w-[60ch] font-display text-[1rem] italic text-stone">{s.about.note}</p>
            </Reveal>
            <Reveal delay={0.1} className="col-span-12 lg:col-span-5">
              <div className="bg-night p-8 text-ivory md:p-10">
                <p className="eyebrow text-gold">{s.transfers.luggageEyebrow}</p>
                <LuggageDiagram on="dark" className="mt-6" />
                <button type="button" onClick={() => planner.open()} className={cx(btn.ivory, "mt-8 w-full")}>
                  <span className="eyebrow">{t.nav.book}</span>
                  <Arrow />
                </button>
              </div>
            </Reveal>
          </div>
        </Shell>
      </section>

      <NextPage current="about" />
    </>
  );
}
