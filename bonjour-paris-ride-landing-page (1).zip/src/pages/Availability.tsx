import { Phone } from "lucide-react";
import { telLink, waLink } from "../config";
import { useI18n } from "../i18n";
import { CalendarPanel } from "../components/Calendar";
import { NextPage, PageHero } from "../components/PageKit";
import { usePlanner } from "../components/Planner";
import { Reveal, Shell, WhatsAppIcon, cx } from "../components/ui";

export default function AvailabilityPage() {
  const { t, s } = useI18n();
  const planner = usePlanner();
  const legend = [
    { dot: "bg-avail", label: t.cal.available, d: s.avail.legend.available },
    { dot: "bg-limited", label: t.cal.limited, d: s.avail.legend.limited },
    { dot: "bg-booked", label: t.cal.booked, d: s.avail.legend.booked },
  ];
  return (
    <>
      <PageHero page="availability" variant="band" eyebrow={t.cal.eyebrow} title={s.nav.availability} sub={t.cal.sectionSub} photos={["eiffelLights"]} />

      <section className="relative bg-cream py-20 md:py-28">
        <Shell>
          <div className="grid grid-cols-12 gap-y-12 lg:gap-x-14">
            <aside className="col-span-12 lg:col-span-4">
              <Reveal>
                <p className="eyebrow text-golddeep">{t.multi.howT}</p>
                <ol className="mt-6 space-y-6">
                  {s.avail.how.map((h, i) => (
                    <li key={h} className="flex gap-5">
                      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-gold font-display text-[1.25rem] italic text-golddeep">
                        {i + 1}
                      </span>
                      <span className="pt-2 text-[1rem] leading-relaxed text-navy">{h}</span>
                    </li>
                  ))}
                </ol>
              </Reveal>
              <Reveal delay={0.1} className="mt-10 border-t border-rule pt-8">
                <p className="eyebrow text-golddeep">{t.cal.legend}</p>
                <ul className="mt-5 space-y-4">
                  {legend.map((l) => (
                    <li key={l.label} className="flex gap-3">
                      <span aria-hidden="true" className={cx("mt-1.5 h-3 w-3 shrink-0 rounded-full", l.dot)} />
                      <span>
                        <span className="block font-display text-[1.2rem] text-navy">{l.label}</span>
                        <span className="block text-[0.9rem] text-stone">{l.d}</span>
                      </span>
                    </li>
                  ))}
                </ul>
              </Reveal>
              <Reveal delay={0.15} className="mt-10 flex flex-col gap-3 border-t border-rule pt-8">
                <a
                  href={waLink(t.cal.askAny)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-3 text-navy transition-colors hover:text-golddeep"
                >
                  <WhatsAppIcon className="h-4 w-4" />
                  <span className="eyebrow">{t.common.whatsapp}</span>
                </a>
                <a href={telLink} className="inline-flex items-center gap-3 text-navy transition-colors hover:text-golddeep">
                  <Phone size={15} aria-hidden="true" />
                  <span className="eyebrow">{t.common.call}</span>
                </a>
              </Reveal>
            </aside>

            <Reveal delay={0.05} className="col-span-12 lg:col-span-8">
              <div className="border border-gold/40 bg-[#fffdf8] p-5 shadow-[0_60px_120px_-70px_rgba(11,18,34,0.6)] md:p-10">
                <CalendarPanel
                  titleId="avail-cal-title"
                  selected={planner.draft.date}
                  onSelect={planner.setDate}
                  onPlan={() => planner.open({ step: 1 })}
                />
              </div>
            </Reveal>
          </div>
        </Shell>
      </section>

      <NextPage current="availability" />
    </>
  );
}
