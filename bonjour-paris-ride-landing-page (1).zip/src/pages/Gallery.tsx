import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import { Image as ImageIcon } from "lucide-react";
import { useI18n } from "../i18n";
import { GALLERY_CATS, type GalleryCat } from "../photos";
import { GalleryTile, Lightbox, useGalleryItems } from "../components/Lightbox";
import { NextPage, PageHero } from "../components/PageKit";
import { EASE, Shell, cx } from "../components/ui";

export default function GalleryPage() {
  const { t } = useI18n();
  const items = useGalleryItems();
  const [cat, setCat] = useState<GalleryCat | "all">("all");
  const [open, setOpen] = useState<number | null>(null);
  const list = useMemo(() => (cat === "all" ? items : items.filter((i) => i.cats.includes(cat))), [items, cat]);
  const count = (c: GalleryCat | "all") => (c === "all" ? items.length : items.filter((i) => i.cats.includes(c)).length);

  return (
    <>
      <PageHero
        page="gallery"
        variant="mosaic"
        eyebrow={t.gallery.eyebrow}
        title={t.gallery.pageTitle}
        sub={t.gallery.sub}
        photos={["givernyPond", "eiffelSunset", "cafe"]}
      />

      <section className="bg-ivory pb-20 md:pb-28">
        <Shell>
          <div
            role="group"
            aria-label={t.gallery.filter}
            className="no-scrollbar -mx-6 flex gap-2 overflow-x-auto border-y border-rule px-6 py-5 md:mx-0 md:flex-wrap md:justify-center md:px-0"
          >
            {(["all", ...GALLERY_CATS] as const).map((c) => {
              const on = cat === c;
              return (
                <button
                  key={c}
                  type="button"
                  aria-pressed={on}
                  onClick={() => setCat(c)}
                  className={cx("shrink-0 px-4 py-2.5 text-[0.9rem] transition-all duration-300", on ? "bg-navy text-ivory" : "text-navy hover:bg-cream")}
                >
                  {c === "all" ? t.gallery.all : t.gallery.cats[c]}
                  <span className={cx("num ml-1.5 text-[0.8rem]", on ? "text-gold" : "text-stone")}>{count(c)}</span>
                </button>
              );
            })}
          </div>

          {list.length ? (
            <motion.div
              key={cat}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, ease: EASE }}
              className="mt-10 columns-1 gap-5 sm:columns-2 lg:columns-3"
            >
              {list.map((g, i) => (
                <div key={g.id} className="mb-5 break-inside-avoid">
                  <GalleryTile item={g} onOpen={() => setOpen(i)} sizes="(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw" />
                </div>
              ))}
            </motion.div>
          ) : (
            <div className="mt-10 flex flex-col items-center border border-dashed border-booked/70 px-6 py-20 text-center">
              <ImageIcon size={28} className="text-stone" aria-hidden="true" />
              <p className="mt-4 max-w-[46ch] text-[0.98rem] text-stone">{t.gallery.empty}</p>
            </div>
          )}
          <p className="mx-auto mt-10 max-w-[70ch] text-center font-display text-[1rem] italic text-stone">{t.gallery.note}</p>
        </Shell>
      </section>

      <AnimatePresence>
        {open !== null && list[open] && <Lightbox items={list} index={open} onIndex={setOpen} onClose={() => setOpen(null)} />}
      </AnimatePresence>

      <NextPage current="gallery" />
    </>
  );
}
