import { useEffect, useState } from "react";
import { Check } from "lucide-react";
import { MULTI_TOURS } from "../config";
import { useI18n } from "../i18n";
import { scrollToId } from "../lib/router";
import { photo } from "../photos";
import { NextPage, PageHero } from "../components/PageKit";
import { QuoteForm } from "../components/QuoteForm";
import { Arrow, Eyebrow, Img, Parallax, Reveal, Shell, btn, cx, rich } from "../components/ui";

type TourKey = "a" | "b" | "c";
const asTour = (v: string | null | undefined): TourKey | undefined => (v === "a" || v === "b" || v === "c" ? v : undefined);

export default function MultiDayPage({ params }: { params: URLSearchParams }) {
  const { t, s, cap } = useI18n();
  const [tour, setTour] = useState<TourKey | undefined>(asTour(params.get("tour")));
  const qTour = params.get("tour");
  const qForm = params.get("form");

  useEffect(() => {
    const tp = asTour(qTour);
    if (tp) setTour(tp);
    if (!tp && !qForm) return;
    const id = window.setTimeout(() => scrollToId("multi-form"), 500);
    return () => window.clearTimeout(id);
  }, [qTour, qForm]);

  const choose = (id: TourKey) => {
    setTour(id);
    scrollToId("multi-form");
  };

  return (
    <>
      <PageHero
        page="multi-day"
        variant="framed"
        eyebrow={t.multi.eyebrow}
        title={t.multi.pageTitle}
        sub={t.multi.intro}
        photos={["versaillesGardens", "givernyPond"]}
      >
        <button type="button" onClick={() => scrollToId("multi-form")} className={btn.navy}>
          <span className="eyebrow">{t.quote.submitMulti}</span>
          <Arrow />
        </button>
      </PageHero>

      <section aria-label={t.multi.eyebrow} className="bg-ivory py-24 md:py-32">
        <Shell>
          <div className="space-y-24 md:space-y-32">
            {MULTI_TOURS.map((m, idx) => {
              const tr = t.multi.tours[m.id];
              const p = photo(m.photo);
              return (
                <article key={m.id} className="grid grid-cols-12 items-center gap-y-10 lg:gap-x-16">
                  <Reveal className={cx("col-span-12 lg:col-span-6", idx % 2 === 1 && "lg:order-2")}>
                    <Parallax className={cx("bg-night", idx % 2 === 0 ? "arch aspect-[4/5]" : "aspect-[4/3]")}>
                      <Img photo={p} alt={cap(p.key)} sizes="(min-width:1024px) 45vw, 100vw" className="h-full w-full object-cover" />
                    </Parallax>
                  </Reveal>
                  <Reveal delay={0.1} className="col-span-12 lg:col-span-6">
                    <p className="eyebrow text-golddeep">{t.multi.concept}</p>
                    <h2 className="display mt-4 text-navy [font-size:clamp(2.3rem,4.2vw,3.6rem)]">{tr.t}</h2>
                    <p className="display num mt-2 text-[1.5rem] italic text-golddeep">{t.multi.days(m.days)}</p>
                    <ol className="mt-8 border-l border-gold/50">
                      {tr.plan.map((items, d) => (
                        <li key={d} className="relative pb-7 pl-8 last:pb-0">
                          <span aria-hidden="true" className="absolute -left-[7px] top-1 h-3.5 w-3.5 rotate-45 border border-golddeep bg-ivory" />
                          <p className="eyebrow text-navy">{t.multi.day(d + 1)}</p>
                          <ul className="mt-2.5 space-y-1.5">
                            {items.map((x) => (
                              <li key={x} className="flex items-start gap-2 text-[0.98rem] text-stone">
                                <Check size={15} className="mt-1 shrink-0 text-avail" aria-hidden="true" />
                                {x}
                              </li>
                            ))}
                          </ul>
                        </li>
                      ))}
                    </ol>
                    <button type="button" onClick={() => choose(m.id)} className={cx(btn.ghost, "mt-8")}>
                      <span className="eyebrow">{t.multi.customize}</span>
                      <Arrow />
                    </button>
                  </Reveal>
                </article>
              );
            })}
          </div>
        </Shell>
      </section>

      <section className="bg-night py-20 text-ivory md:py-24">
        <Shell>
          <div className="grid grid-cols-1 gap-12 md:grid-cols-3 md:gap-10">
            <Reveal>
              <h3 className="font-display text-[1.7rem] text-gold">{t.multi.howT}</h3>
              <ol className="mt-5 space-y-4">
                {t.multi.how.map((h, i) => (
                  <li key={h} className="flex gap-4">
                    <span className="display num text-[2rem] italic leading-none text-gold">{i + 1}</span>
                    <span className="pt-1 text-[0.98rem] text-ivory/85">{h}</span>
                  </li>
                ))}
              </ol>
            </Reveal>
            <Reveal delay={0.08}>
              <h3 className="font-display text-[1.7rem] text-gold">{t.multi.includedT}</h3>
              <p className="mt-5 text-[0.98rem] leading-relaxed text-ivory/75">{t.multi.included}</p>
            </Reveal>
            <Reveal delay={0.16}>
              <h3 className="font-display text-[1.7rem] text-gold">{t.multi.feasibleT}</h3>
              <p className="mt-5 text-[0.98rem] leading-relaxed text-ivory/75">{t.multi.feasible}</p>
              <p className="mt-4 text-[0.98rem] leading-relaxed text-ivory/75">{t.quote.paxWarn}</p>
            </Reveal>
          </div>
        </Shell>
      </section>

      <section id="multi-form" aria-labelledby="multi-form-title" className="scroll-mt-24 bg-cream py-24 md:py-32">
        <Shell>
          <div className="grid grid-cols-12 gap-y-10 lg:gap-x-16">
            <Reveal className="col-span-12 lg:col-span-4">
              <Eyebrow>{s.nav.multiday}</Eyebrow>
              <h2 id="multi-form-title" className="display mt-6 text-navy [font-size:clamp(2.3rem,4.6vw,3.6rem)] [&_em]:text-golddeep">
                {rich(t.multi.formT)}
              </h2>
              <p className="mt-6 text-[1rem] leading-relaxed text-stone">{t.multi.intro}</p>
              {tour && (
                <p className="mt-6 inline-flex items-center gap-2 border border-gold/50 bg-ivory px-4 py-2 text-[0.9rem] text-navy">
                  <Check size={14} className="text-avail" aria-hidden="true" />
                  {t.multi.based(t.multi.tours[tour].t)}
                </p>
              )}
            </Reveal>
            <Reveal delay={0.1} className="col-span-12 lg:col-span-8">
              <div className="border border-rule bg-[#fffdf8] p-6 shadow-[0_50px_100px_-70px_rgba(11,18,34,0.6)] md:p-10">
                <QuoteForm variant="multi" tour={tour} />
              </div>
            </Reveal>
          </div>
        </Shell>
      </section>

      <NextPage current="multi-day" />
    </>
  );
}
