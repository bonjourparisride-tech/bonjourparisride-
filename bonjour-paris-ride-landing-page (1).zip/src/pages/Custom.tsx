import { useEffect } from "react";
import { useI18n } from "../i18n";
import { scrollToId } from "../lib/router";
import { photo } from "../photos";
import { NextPage, PageHero } from "../components/PageKit";
import { QuoteForm } from "../components/QuoteForm";
import { Arrow, Eyebrow, Heading, Img, Reveal, RevealMask, Shell, btn, rich } from "../components/ui";

const IDEA_PHOTOS = ["giverny", "fontainebleau", "eiffelSunset", "bridgeNight"];

export default function CustomPage({ params }: { params: URLSearchParams }) {
  const { t, s, cap } = useI18n();
  const qForm = params.get("form");

  useEffect(() => {
    if (!qForm) return;
    const id = window.setTimeout(() => scrollToId("custom-form"), 500);
    return () => window.clearTimeout(id);
  }, [qForm]);

  return (
    <>
      <PageHero page="custom" variant="framed" eyebrow={t.quote.eyebrow} title={t.quote.title} sub={t.quote.sub} photos={["croissant", "village"]}>
        <button type="button" onClick={() => scrollToId("custom-form")} className={btn.navy}>
          <span className="eyebrow">{t.quote.submitCustom}</span>
          <Arrow />
        </button>
      </PageHero>

      <section aria-labelledby="ideas-title" className="bg-ivory py-24 md:py-32">
        <Shell>
          <Heading id="ideas-title" eyebrow={s.custom.ideasEyebrow} title={s.custom.ideasTitle} />
          <div className="mt-14 grid grid-cols-1 gap-x-6 gap-y-14 sm:grid-cols-2 md:mt-20 lg:grid-cols-4">
            {s.custom.ideas.map((idea, i) => {
              const p = photo(IDEA_PHOTOS[i] ?? "giverny");
              return (
                <Reveal key={idea.t} delay={i * 0.08} className={i % 2 === 1 ? "lg:mt-16" : undefined}>
                  <article className="group">
                    <RevealMask className="arch relative aspect-[3/4] overflow-hidden bg-night">
                      <Img
                        photo={p}
                        alt={cap(p.key)}
                        sizes="(min-width:1024px) 24vw, (min-width:640px) 50vw, 100vw"
                        className="h-full w-full object-cover transition-transform duration-[1600ms] ease-out group-hover:scale-105"
                      />
                    </RevealMask>
                    <h3 className="mt-6 font-display text-[1.6rem] leading-tight text-navy">{idea.t}</h3>
                    <p className="mt-2 text-[0.96rem] leading-relaxed text-stone">{idea.d}</p>
                  </article>
                </Reveal>
              );
            })}
          </div>
        </Shell>
      </section>

      <section id="custom-form" aria-labelledby="custom-form-title" className="scroll-mt-24 bg-cream py-24 md:py-32">
        <Shell>
          <div className="grid grid-cols-12 gap-y-10 lg:gap-x-16">
            <Reveal className="col-span-12 lg:col-span-4">
              <Eyebrow>{t.quote.eyebrow}</Eyebrow>
              <h2 id="custom-form-title" className="display mt-6 text-navy [font-size:clamp(2.3rem,4.6vw,3.6rem)] [&_em]:text-golddeep">
                {rich(t.multi.formT)}
              </h2>
              <p className="mt-6 text-[1rem] leading-relaxed text-stone">{t.quote.noPrice}</p>
            </Reveal>
            <Reveal delay={0.1} className="col-span-12 lg:col-span-8">
              <div className="border border-rule bg-[#fffdf8] p-6 shadow-[0_50px_100px_-70px_rgba(11,18,34,0.6)] md:p-10">
                <QuoteForm variant="custom" />
              </div>
            </Reveal>
          </div>
        </Shell>
      </section>

      <NextPage current="custom" />
    </>
  );
}
