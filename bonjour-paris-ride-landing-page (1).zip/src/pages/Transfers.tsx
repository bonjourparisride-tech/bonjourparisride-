import { motion, useReducedMotion } from "framer-motion";
import { Baby, BadgeCheck, Clock, Plane, PlaneLanding, Signpost } from "lucide-react";
import { OPTIONS } from "../config";
import { optText, useI18n } from "../i18n";
import { hrefOf } from "../lib/router";
import { CarImage, LuggageDiagram } from "../components/Car";
import { NextPage, PageHero } from "../components/PageKit";
import { usePlanner } from "../components/Planner";
import { Arrow, EASE, Eyebrow, Heading, Item, Reveal, Shell, Stagger, btn, cx, rich, useParisClock } from "../components/ui";

const ROMAN = ["I", "II", "III", "IV"];
const PERK_ICONS = [PlaneLanding, Clock, Signpost, Baby];

/** Split-flap letters, like the departure boards of Parisian stations. */
function Flap({ text, delay }: { text: string; delay: number }) {
  const reduce = useReducedMotion();
  return (
    <span className="inline-flex gap-[3px] [perspective:400px]">
      <span className="sr-only">{text}</span>
      {text.split("").map((ch, i) => (
        <motion.span
          key={i}
          aria-hidden="true"
          initial={reduce ? { opacity: 0 } : { rotateX: -90, opacity: 0 }}
          whileInView={{ rotateX: 0, opacity: 1 }}
          viewport={{ once: true, margin: "-10% 0px" }}
          transition={{ duration: 0.5, delay: delay + i * 0.08, ease: EASE }}
          className="relative flex h-11 w-8 origin-top items-center justify-center rounded-[3px] bg-[#070b16] font-sans text-[1.3rem] font-medium text-gold shadow-[inset_0_-1px_0_rgba(255,255,255,0.06)] after:absolute after:inset-x-0 after:top-1/2 after:h-px after:bg-black/70 md:h-12 md:w-9"
        >
          {ch}
        </motion.span>
      ))}
    </span>
  );
}

function Board() {
  const { t, s, price } = useI18n();
  const planner = usePlanner();
  const clock = useParisClock();
  return (
    <div className="overflow-hidden bg-night text-ivory shadow-[0_60px_120px_-60px_rgba(11,18,34,0.95)] ring-1 ring-gold/20">
      <div className="flex items-center justify-between gap-4 border-b border-ivory/10 px-5 py-5 md:px-8">
        <p className="flex items-center gap-3">
          <Plane size={18} className="text-gold" aria-hidden="true" />
          <span className="font-display text-[1.7rem] italic">{s.transfers.board}</span>
        </p>
        <p className="eyebrow num text-ivory/60">
          Paris <span className="ml-2 font-display text-[1.3rem] normal-case tracking-normal text-gold">{clock}</span>
        </p>
      </div>
      <div className="hidden grid-cols-[7.5rem_1.4fr_1fr_8rem_6.5rem] gap-x-6 border-b border-ivory/10 px-8 py-3 md:grid">
        <span className="eyebrow text-ivory/45">{s.transfers.cols[0]}</span>
        <span />
        <span className="eyebrow text-ivory/45">{s.transfers.cols[1]}</span>
        <span className="eyebrow text-ivory/45">{s.transfers.cols[2]}</span>
        <span />
      </div>
      <ul>
        {OPTIONS.airport.map((o, i) => {
          const txt = optText(t, "airport", o.id);
          return (
            <li
              key={o.id}
              className="grid grid-cols-[auto_1fr] items-center gap-x-5 gap-y-4 border-b border-ivory/10 px-5 py-6 last:border-0 md:grid-cols-[7.5rem_1.4fr_1fr_8rem_6.5rem] md:gap-x-6 md:px-8"
            >
              <Flap text={o.code ?? ""} delay={i * 0.18} />
              <div className="min-w-0">
                <p className="font-display text-[1.5rem] leading-tight">{txt?.l}</p>
                <p className="mt-1 text-[0.85rem] text-ivory/55">{txt?.d}</p>
              </div>
              <p className="col-span-2 text-[0.95rem] text-ivory/80 md:col-span-1">
                <span className="eyebrow mr-2 text-ivory/45 md:hidden">{s.transfers.cols[1]}</span>
                {o.travel ? t.common.minutes(o.travel[0], o.travel[1]) : ""}
              </p>
              <p className="display num text-[2.3rem] leading-none text-gold">{price(o.price)}</p>
              <button
                type="button"
                onClick={() => planner.open({ service: "airport", optionId: o.id })}
                className={cx(btn.ivory, "justify-self-end px-5 py-3")}
              >
                <span className="eyebrow">{t.common.book}</span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

export default function TransfersPage() {
  const { t, s } = useI18n();
  const planner = usePlanner();
  return (
    <>
      <PageHero
        page="transfers"
        variant="split"
        eyebrow={t.transfers.eyebrow}
        title={t.transfers.title}
        sub={t.transfers.sub}
        photos={["cdg"]}
      >
        <button type="button" onClick={() => planner.open({ service: "airport" })} className={btn.navy}>
          <span className="eyebrow">{t.hero.ctaTransfer}</span>
          <Arrow />
        </button>
        <a href={hrefOf("availability")} className={btn.ghost}>
          <span className="eyebrow">{t.cal.title}</span>
        </a>
      </PageHero>

      <section aria-label={s.transfers.board} className="relative bg-ivory pb-24 md:pb-32">
        <Shell>
          <Reveal>
            <Board />
          </Reveal>
          <Stagger className="mt-10 grid grid-cols-2 gap-4 lg:grid-cols-4">
            {t.transfers.perks.map((p, i) => {
              const Icon = PERK_ICONS[i] ?? BadgeCheck;
              return (
                <Item key={p} className="flex items-center gap-3 border-t border-rule pt-4 text-[0.95rem] text-navy">
                  <Icon size={18} className="shrink-0 text-golddeep" aria-hidden="true" />
                  {p}
                </Item>
              );
            })}
          </Stagger>
        </Shell>
      </section>

      <section aria-labelledby="steps-title" className="relative bg-cream py-24 md:py-32">
        <Shell>
          <Heading id="steps-title" eyebrow={s.transfers.stepsEyebrow} title={s.transfers.stepsTitle} />
          <div className="relative mt-14 md:mt-20">
            <div aria-hidden="true" className="absolute left-0 right-0 top-7 hidden h-px bg-gold/40 lg:block" />
            <Stagger className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-4">
              {s.transfers.steps.map((st, i) => (
                <Item key={st.t} className="relative">
                  <span className="relative z-10 flex h-14 w-14 items-center justify-center rounded-full border border-gold bg-cream font-display text-[1.6rem] italic text-golddeep">
                    {ROMAN[i]}
                  </span>
                  <h3 className="mt-6 font-display text-[1.55rem] leading-tight text-navy">{st.t}</h3>
                  <p className="mt-2 text-[0.98rem] leading-relaxed text-stone">{st.d}</p>
                </Item>
              ))}
            </Stagger>
          </div>
        </Shell>
      </section>

      <section aria-labelledby="luggage-title" className="relative overflow-hidden bg-ivory py-24 md:py-32">
        <Shell>
          <div className="grid grid-cols-12 items-center gap-y-14 lg:gap-x-16">
            <Reveal className="col-span-12 lg:col-span-6">
              <div className="relative">
                <div className="aspect-[4/3] overflow-hidden shadow-[0_50px_100px_-60px_rgba(11,18,34,0.8)]">
                  <CarImage slot="luggage" sizes="(min-width:1024px) 45vw, 100vw" />
                </div>
                <div className="relative mt-6 bg-[#fffdf8] p-5 shadow-[0_30px_60px_-30px_rgba(11,18,34,0.6)] ring-1 ring-gold/30 sm:absolute sm:-bottom-10 sm:right-6 sm:mt-0 sm:w-[46%]">
                  <LuggageDiagram />
                </div>
              </div>
            </Reveal>
            <div className="col-span-12 lg:col-span-6 lg:pt-0">
              <Reveal>
                <Eyebrow>{s.transfers.luggageEyebrow}</Eyebrow>
                <h2 id="luggage-title" className="display mt-6 text-navy [font-size:clamp(2.4rem,5vw,4rem)] [&_em]:text-golddeep">
                  {rich(s.transfers.luggageTitle)}
                </h2>
                <p className="mt-6 max-w-[48ch] text-[1.06rem] leading-relaxed text-stone">{s.transfers.luggageText}</p>
                <ul className="mt-7 space-y-2.5">
                  {t.trust.limits.map((l) => (
                    <li key={l} className="flex items-center gap-3 text-[0.98rem] text-navy">
                      <span aria-hidden="true" className="h-1.5 w-1.5 rotate-45 bg-golddeep" />
                      {l}
                    </li>
                  ))}
                </ul>
                <a href={hrefOf("about", "s=car")} className={cx(btn.ghost, "mt-9")}>
                  <span className="eyebrow">{s.home.carCta}</span>
                  <Arrow />
                </a>
              </Reveal>
            </div>
          </div>
        </Shell>
      </section>

      <section className="bg-cream py-16">
        <Shell>
          <Reveal className="flex flex-col gap-5 border border-gold/40 bg-[#fffdf8] p-7 md:flex-row md:items-center md:justify-between md:p-9">
            <div>
              <p className="font-display text-[1.6rem] text-navy">{t.transfers.otherT}</p>
              <p className="mt-1.5 text-[0.98rem] text-stone">{t.transfers.otherD}</p>
            </div>
            <a href={hrefOf("custom")} className={cx(btn.gold, "shrink-0")}>
              <span className="eyebrow">{t.common.getQuote}</span>
              <Arrow />
            </a>
          </Reveal>
        </Shell>
      </section>

      <NextPage current="transfers" />
    </>
  );
}
