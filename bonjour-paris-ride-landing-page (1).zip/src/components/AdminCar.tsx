import { useState, type ChangeEvent, type MouseEvent } from "react";
import { Trash2, Upload } from "lucide-react";
import { CAR_GRADE, CAR_SLOTS, cms, compressImage, useStore, type CarSlot } from "../lib/store";
import { cx } from "./ui";

/* Owner area — real photos of the Toyota C-HR replace the illustrations on the
   site (home, airport transfers, about, gallery) and are labelled as real. */

const LABEL: Record<CarSlot, string> = {
  front: "Front — three-quarter view",
  side: "Side profile",
  interior: "Interior",
  luggage: "Luggage space (open boot)",
};

const btn = "inline-flex items-center gap-2 border px-3.5 py-2 text-[0.85rem] transition-colors";
const clamp = (n: number) => Math.min(100, Math.max(0, n));

export default function CarPhotos() {
  const { state } = useStore();
  const [busy, setBusy] = useState<CarSlot | null>(null);
  const [err, setErr] = useState("");

  const onFile = async (slot: CarSlot, e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setBusy(slot);
    setErr("");
    try {
      const { src, w, h } = await compressImage(file, 2000, 0.85);
      cms.setCar(slot, { src, w, h, pos: "50% 50%", grade: true, updatedAt: new Date().toISOString() });
    } catch {
      setErr("This image could not be read.");
    }
    setBusy(null);
  };

  const setFocus = (slot: CarSlot, e: MouseEvent<HTMLButtonElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const x = clamp(Math.round(((e.clientX - r.left) / r.width) * 100));
    const y = clamp(Math.round(((e.clientY - r.top) / r.height) * 100));
    cms.updateCar(slot, { pos: `${x}% ${y}%` });
  };

  return (
    <div>
      <div className="max-w-[85ch] space-y-2 text-[0.9rem] leading-relaxed text-stone">
        <p>
          Upload real photos of your Toyota C-HR. They replace the illustrations on the website and are labelled
          “Photo of our car”.
        </p>
        <p>
          Click a photo to choose the point that must stay visible when it is cropped. “Soft Paris light” adds a
          gentle, warm finish without altering the car.
        </p>
        <p>
          Tips: soft daylight (early morning or late afternoon), a freshly washed car, a calm background (avoid
          billboards and bins), the whole car in frame — and hide the number plate if you prefer.
        </p>
      </div>
      {err && (
        <p role="alert" className="mt-3 text-[0.85rem] text-red">
          {err}
        </p>
      )}
      <div className="mt-6 grid grid-cols-1 gap-5 md:grid-cols-2">
        {CAR_SLOTS.map((slot) => {
          const c = state.car[slot];
          const [fx, fy] = (c?.pos ?? "50% 50%").split(" ");
          return (
            <div key={slot} className="border border-rule bg-[#fffdf9] p-4">
              <div className="flex items-center justify-between gap-3">
                <p className="font-display text-[1.25rem] text-ink">{LABEL[slot]}</p>
                <span className={cx("eyebrow px-2 py-1", c ? "bg-avail text-paper" : "bg-paper2 text-stone")}>
                  {c ? "Real photo" : "Illustration shown"}
                </span>
              </div>
              {c ? (
                <button
                  type="button"
                  onClick={(e) => setFocus(slot, e)}
                  aria-label="Set the focal point"
                  className="relative mt-3 block aspect-[16/10] w-full cursor-crosshair overflow-hidden bg-paper2"
                >
                  <img
                    src={c.src}
                    alt=""
                    style={{ objectPosition: c.pos, filter: c.grade ? CAR_GRADE : undefined }}
                    className="h-full w-full object-cover"
                  />
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute h-6 w-6 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-paper shadow-[0_0_0_1px_rgba(0,0,0,0.45)]"
                    style={{ left: fx, top: fy }}
                  />
                </button>
              ) : (
                <div className="mt-3 flex aspect-[16/10] items-center justify-center border border-dashed border-rule text-[0.85rem] text-stone">
                  No photo yet
                </div>
              )}
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <label
                  className={cx(
                    btn,
                    "cursor-pointer border-ink bg-ink text-paper hover:border-rouge hover:bg-rouge",
                    busy === slot && "pointer-events-none opacity-50",
                  )}
                >
                  <Upload size={14} aria-hidden="true" />
                  {busy === slot ? "Optimising…" : c ? "Replace" : "Upload"}
                  <input type="file" accept="image/*" onChange={(e) => void onFile(slot, e)} className="sr-only" />
                </label>
                {c && (
                  <label className="flex items-center gap-2 text-[0.85rem] text-ink">
                    <input
                      type="checkbox"
                      checked={c.grade}
                      onChange={(e) => cms.updateCar(slot, { grade: e.target.checked })}
                      className="h-4 w-4 accent-[#8b6b32]"
                    />
                    Soft Paris light
                  </label>
                )}
                {c && (
                  <button
                    type="button"
                    onClick={() => window.confirm("Remove this photo?") && cms.setCar(slot, null)}
                    className={cx(btn, "border-rule text-red hover:border-ink")}
                  >
                    <Trash2 size={13} aria-hidden="true" /> Remove
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
      <p className="mt-6 text-[0.82rem] leading-relaxed text-stone">
        To show these photos to every visitor, export content.json in “Data &amp; checks” and publish it. Alternative:
        replace the files in public/images with your photos, set CAR_FILES_ARE_REAL_PHOTOS to true in src/assets.ts and
        rebuild.
      </p>
    </div>
  );
}
