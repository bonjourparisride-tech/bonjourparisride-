import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useEffect, useState } from "react";
import { fromPrice, waLink } from "../config";
import { useI18n } from "../i18n";
import type { Page } from "../lib/router";
import { usePlanner } from "./Planner";
import { EASE, WhatsAppIcon } from "./ui";

/** Discreet floating WhatsApp button (desktop) + persistent BOOK NOW bar (mobile).
 *  Both step aside while the planner is open or while a form field is focused. */
export default function Floating({ page }: { page: Page }) {
  const { t, price } = useI18n();
  const planner = usePlanner();
  const reduce = useReducedMotion();
  const [scrolled, setScrolled] = useState(false);
  const [typing, setTyping] = useState(false);

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > window.innerHeight * 0.45);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  useEffect(() => {
    const isField = (el: EventTarget | null) => el instanceof HTMLElement && el.matches("input, textarea, select");
    const fi = (e: FocusEvent) => isField(e.target) && setTyping(true);
    const fo = (e: FocusEvent) => isField(e.target) && setTyping(false);
    document.addEventListener("focusin", fi);
    document.addEventListener("focusout", fo);
    return () => {
      document.removeEventListener("focusin", fi);
      document.removeEventListener("focusout", fo);
    };
  }, []);

  const show = (scrolled || page !== "home") && !planner.isOpen;
  const wa = waLink(t.contact.waMsg);

  return (
    <>
      <AnimatePresence>
        {show && (
          <motion.a
            key="wa"
            href={wa}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={t.float.chat}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: reduce ? 0 : 0.35, ease: EASE }}
            className="group fixed bottom-6 right-6 z-30 hidden items-center md:flex"
          >
            <span className="pointer-events-none mr-3 translate-x-2 whitespace-nowrap bg-navy px-3 py-2 text-[0.82rem] text-ivory opacity-0 shadow-lg transition-all duration-300 group-hover:translate-x-0 group-hover:opacity-100 group-focus-visible:translate-x-0 group-focus-visible:opacity-100">
              {t.float.chat}
            </span>
            <span className="relative flex h-14 w-14 items-center justify-center rounded-full bg-navy text-ivory shadow-[0_18px_40px_-14px_rgba(11,18,34,0.8)] ring-1 ring-gold/60 ring-offset-2 ring-offset-transparent transition-colors duration-300 group-hover:bg-[#1f8a4c]">
              <WhatsAppIcon className="h-6 w-6" />
              <span className="absolute right-1 top-1 h-3 w-3 rounded-full border-2 border-navy bg-avail" />
            </span>
          </motion.a>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {show && !typing && (
          <motion.div
            key="bar"
            initial={{ y: "110%" }}
            animate={{ y: 0 }}
            exit={{ y: "110%" }}
            transition={{ duration: reduce ? 0 : 0.45, ease: EASE }}
            className="fixed inset-x-0 bottom-0 z-30 border-t border-rule bg-ivory/92 px-4 pt-3 backdrop-blur-xl md:hidden"
            style={{ paddingBottom: "max(0.75rem, env(safe-area-inset-bottom))" }}
          >
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => planner.open()}
                className="flex flex-1 items-center justify-between gap-2 bg-golddeep px-5 py-3.5 text-ivory"
              >
                <span className="eyebrow">{t.nav.book}</span>
                <span className="num font-display text-[1.1rem] leading-none">{t.common.fromP(price(fromPrice("airport")))}</span>
              </button>
              <a
                href={wa}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={t.float.chat}
                className="flex h-[3.1rem] w-[3.1rem] shrink-0 items-center justify-center bg-navy text-ivory"
              >
                <WhatsAppIcon className="h-5 w-5" />
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
