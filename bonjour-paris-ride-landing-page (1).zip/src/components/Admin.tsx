import { useMemo, useState, type ChangeEvent, type FormEvent, type ReactNode } from "react";
import { ChevronLeft, ChevronRight, CircleCheck, CircleX, Download, Lock, Trash2, Upload } from "lucide-react";
import {
  ADMIN_PASSCODE,
  CALENDAR,
  CONTACT,
  DATA,
  OPTIONS,
  SERVICES,
  findOption,
  fromPrice,
  isPlaceholderPhone,
  isPriced,
  mailLink,
  optionsOf,
  telLink,
  waLink,
  type DayStatus,
  type ServiceId,
} from "../config";
import { DICTS } from "../i18n";
import en from "../i18n/en";
import {
  addDays,
  busyByDay,
  computeStatus,
  durationOf,
  exportAvailability,
  findConflicts,
  fmtMin,
  isSelectable,
  isValidISO,
  slotsOf,
  toISO,
  todayISO,
} from "../lib/availability";
import { cms, compressImage, uid, useStore, type GalleryItem, type Req, type ReqStatus, type Review } from "../lib/store";
import { GALLERY_CATS, type GalleryCat } from "../photos";
import { Shell, cx } from "./ui";
import CarPhotos from "./AdminCar";

/* Owner area (English only). Data lives in this browser — export the JSON
   files in "Data & checks" and publish them to update every visitor. */

const SKEY = "bpr-admin";
const field =
  "mt-1.5 w-full border border-rule bg-paper px-3 py-2.5 text-[0.92rem] text-ink focus:border-rouge focus:outline-none";
const btn = "inline-flex items-center gap-2 border px-3.5 py-2 text-[0.85rem] transition-colors";
const btnInk = cx(btn, "border-ink bg-ink text-paper hover:bg-rouge hover:border-rouge");
const btnGhost = cx(btn, "border-rule text-ink hover:border-ink");

const svcLabel = (r: Pick<Req, "service" | "optionId">) => {
  const base = en.services[r.service];
  if (!isPriced(r.service)) return base;
  const o = (en.opt[r.service] as Record<string, { l: string }>)[r.optionId ?? ""];
  return o ? `${base} · ${o.l}` : base;
};

type Tab = "requests" | "availability" | "reviews" | "gallery" | "car" | "data";
const TABS: { id: Tab; label: string }[] = [
  { id: "requests", label: "Requests" },
  { id: "availability", label: "Availability" },
  { id: "reviews", label: "Reviews" },
  { id: "gallery", label: "Gallery" },
  { id: "car", label: "Car photos" },
  { id: "data", label: "Data & checks" },
];

export default function Admin() {
  const [ok, setOk] = useState(() => {
    try {
      return sessionStorage.getItem(SKEY) === "1";
    } catch {
      return false;
    }
  });
  const [tab, setTab] = useState<Tab>("requests");
  const { state, ready, error } = useStore();

  if (!ok)
    return (
      <Gate
        onOk={() => {
          try {
            sessionStorage.setItem(SKEY, "1");
          } catch {
            /* ignore */
          }
          setOk(true);
        }}
      />
    );

  const pending = state.requests.filter((r) => r.status === "pending").length;

  return (
    <section className="min-h-screen bg-paper pb-24 pt-28">
      <Shell>
        <header className="flex flex-wrap items-end justify-between gap-6 border-b border-ink pb-6">
          <div>
            <p className="eyebrow text-rouge">Owner area</p>
            <h1 className="display mt-3 text-[2.4rem] text-ink">Bonjour Paris Ride — admin</h1>
            <p className="mt-2 max-w-[78ch] text-[0.9rem] leading-relaxed text-stone">
              Everything here is stored in this browser only.{" "}
              {DATA.availabilityUrl || DATA.contentUrl
                ? "Published files are configured — export and re-upload them after changes."
                : "The website runs in demonstration mode until you publish the exported files (see Data & checks)."}
            </p>
          </div>
          <div className="flex gap-2">
            <a href="#top" className={btnGhost}>
              View website
            </a>
            <button
              type="button"
              onClick={() => {
                try {
                  sessionStorage.removeItem(SKEY);
                } catch {
                  /* ignore */
                }
                setOk(false);
              }}
              className={btnGhost}
            >
              <Lock size={14} aria-hidden="true" /> Lock
            </button>
          </div>
        </header>
        {error && <p className="mt-4 border-l-2 border-rouge bg-rouge/10 px-4 py-3 text-[0.9rem] text-rouge">{error}</p>}
        <div role="tablist" aria-label="Admin sections" className="mt-6 flex flex-wrap gap-2">
          {TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              role="tab"
              aria-selected={tab === t.id}
              onClick={() => setTab(t.id)}
              className={cx(
                "border px-4 py-2.5 text-[0.9rem] transition-colors",
                tab === t.id ? "border-ink bg-ink text-paper" : "border-rule text-ink hover:border-ink",
              )}
            >
              {t.label}
              {t.id === "requests" && pending > 0 && (
                <span className="num ml-2 rounded-full bg-rouge px-2 py-0.5 text-[0.75rem] text-paper">{pending}</span>
              )}
            </button>
          ))}
        </div>
        <div className="mt-8" role="tabpanel">
          {!ready ? (
            <p className="text-stone">Loading…</p>
          ) : tab === "requests" ? (
            <Requests />
          ) : tab === "availability" ? (
            <Availability />
          ) : tab === "reviews" ? (
            <Reviews />
          ) : tab === "gallery" ? (
            <Gallery />
          ) : tab === "car" ? (
            <CarPhotos />
          ) : (
            <DataTab />
          )}
        </div>
      </Shell>
    </section>
  );
}

function Gate({ onOk }: { onOk: () => void }) {
  const [v, setV] = useState("");
  const [bad, setBad] = useState(false);
  return (
    <section className="flex min-h-screen items-center justify-center bg-paper px-6 pt-20">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (v === ADMIN_PASSCODE) onOk();
          else setBad(true);
        }}
        className="w-full max-w-sm border border-rule bg-[#fffdf9] p-8"
      >
        <Lock className="text-rouge" aria-hidden="true" />
        <h1 className="display mt-4 text-[2rem] text-ink">Owner area</h1>
        <p className="mt-2 text-[0.88rem] leading-relaxed text-stone">
          Enter the passcode set in <code>src/config.ts</code> (ADMIN_PASSCODE). This is a convenience lock, not real
          security.
        </p>
        <label className="mt-6 block">
          <span className="eyebrow text-stone">Passcode</span>
          <input
            type="password"
            value={v}
            onChange={(e) => {
              setV(e.target.value);
              setBad(false);
            }}
            className={field}
            autoComplete="current-password"
          />
        </label>
        {bad && (
          <p role="alert" className="mt-2 text-[0.85rem] text-rouge">
            Wrong passcode.
          </p>
        )}
        <button type="submit" className="mt-6 w-full bg-ink px-6 py-3.5 text-paper transition-colors hover:bg-rouge">
          <span className="eyebrow">Unlock</span>
        </button>
        <a href="#top" className="mt-4 block text-center text-[0.85rem] text-stone hover:text-ink">
          ← Back to the website
        </a>
      </form>
    </section>
  );
}

/* ── Requests ────────────────────────────────────────────────────────────── */

const replyText = (r: Req, status: ReqStatus) =>
  `Hello${r.name ? ` ${r.name}` : ""}, this is Bonjour Paris Ride about your request ${r.id} (${svcLabel(r)}, ${r.date}${
    r.time ? ` at ${r.time}` : ""
  }). ${
    status === "confirmed"
      ? "I am happy to confirm your booking."
      : status === "declined"
        ? "Unfortunately I am not available at that time — may I suggest another time?"
        : ""
  }`;

function Requests() {
  const { state } = useStore();
  const [filter, setFilter] = useState<ReqStatus | "all">("pending");
  const [adding, setAdding] = useState(false);
  const [note, setNote] = useState<{ id: string; text: string; ok: boolean } | null>(null);

  const list = useMemo(
    () =>
      state.requests
        .filter((r) => filter === "all" || r.status === filter)
        .sort((a, b) => (a.date || "9999").localeCompare(b.date || "9999") || (a.time ?? "").localeCompare(b.time ?? "")),
    [state.requests, filter],
  );
  const count = (s: ReqStatus | "all") => (s === "all" ? state.requests.length : state.requests.filter((r) => r.status === s).length);

  /** Editing a confirmed journey must never create an overlap: if it would, it goes back to pending. */
  const edit = (r: Req, patch: Partial<Req>) => {
    const next = { ...r, ...patch };
    if (r.status === "confirmed") {
      const clash = findConflicts(next, state.requests);
      const blocked = slotsOf(next).some((s) => state.overrides[s.date] === "booked" || state.overrides[s.date] === "blocked");
      if (clash.length || blocked) {
        cms.updateRequest(r.id, { ...patch, status: "pending" });
        setNote({
          id: r.id,
          text: `This change overlaps ${clash.length ? clash.map((c) => c.id).join(", ") : "a fully booked / blocked day"} — the request was moved back to pending.`,
          ok: false,
        });
        return;
      }
    }
    cms.updateRequest(r.id, patch);
  };

  const doConfirm = (r: Req) => {
    if (!isValidISO(r.date)) {
      setNote({ id: r.id, text: "Set a valid date before confirming.", ok: false });
      return;
    }
    const days = slotsOf(r).map((s) => s.date);
    const blocked = days.find((d) => state.overrides[d] === "booked" || state.overrides[d] === "blocked");
    if (blocked) {
      setNote({ id: r.id, text: `${blocked} is marked "${state.overrides[blocked]}" in Availability — change that day first.`, ok: false });
      return;
    }
    const clash = findConflicts(r, state.requests);
    if (clash.length) {
      setNote({
        id: r.id,
        text: `Not confirmed — overlaps with ${clash
          .map((c) => `${c.id} (${c.date}${c.time ? ` ${c.time}` : ", whole day"})`)
          .join(", ")}. One car, one driver: change the time or decline.`,
        ok: false,
      });
      return;
    }
    cms.updateRequest(r.id, { status: "confirmed" });
    setNote({ id: r.id, text: "Confirmed — the calendar now reflects this journey. Reply to the guest below.", ok: true });
  };

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap gap-2">
          {(["pending", "confirmed", "declined", "all"] as const).map((s) => (
            <button
              key={s}
              type="button"
              aria-pressed={filter === s}
              onClick={() => setFilter(s)}
              className={cx(btn, filter === s ? "border-ink bg-ink text-paper" : "border-rule text-ink hover:border-ink")}
            >
              {s[0].toUpperCase() + s.slice(1)} <span className="num opacity-60">{count(s)}</span>
            </button>
          ))}
        </div>
        <button type="button" onClick={() => setAdding((a) => !a)} className={btnInk}>
          {adding ? "Close" : "+ Add a request received by phone/WhatsApp"}
        </button>
      </div>
      {adding && <AddRequest onDone={() => setAdding(false)} />}
      <p className="mt-4 text-[0.82rem] text-stone">
        Requests sent from this browser appear here automatically. With a form endpoint configured, requests arrive by
        email instead — add them here to track them and to protect your calendar from overlaps.
      </p>
      <div className="mt-6 space-y-4">
        {list.length === 0 && <p className="border border-dashed border-rule p-8 text-center text-stone">No requests in this list.</p>}
        {list.map((r) => {
          const rows: [string, ReactNode][] = [
            ["Passengers", `${r.pax}${r.adults !== undefined ? ` (${r.adults} adults${r.children ? `, ${r.children} children${r.childAges ? ` — ages ${r.childAges}` : ""}` : ""})` : ""}`],
            ["Luggage", r.bags !== undefined ? `${r.bags} large${r.cabin !== undefined ? ` · ${r.cabin} cabin` : ""}` : ""],
            ["Pickup", r.pickup ?? ""],
            ["Drop-off", r.dropoff ?? ""],
            ["Flight", r.flight ?? ""],
            ["Hotel", r.hotel ?? ""],
            ["Destinations", r.destinations?.join(", ") ?? ""],
            ["Notes", r.notes ?? ""],
            ["Child seat", r.childSeat ? "Yes" : ""],
            ["Price", r.price != null ? `€${r.price}` : "Quotation"],
            ["Name", r.name ?? ""],
            ["Email", r.email ?? ""],
            ["Phone", r.phone ?? ""],
            ["Language", r.lang ?? ""],
          ];
          return (
            <article key={r.id} className="border border-rule bg-[#fffdf9] p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="eyebrow num text-stone">
                    {r.id} · {r.kind} · {r.source ?? "website"} · received {new Date(r.createdAt).toLocaleString("en-GB")}
                  </p>
                  <h3 className="mt-1 font-display text-[1.3rem] text-ink">
                    {svcLabel(r)}
                    {r.service === "airport" ? ` (${r.direction === "to" ? "Paris → airport" : "airport → Paris"})` : ""}
                  </h3>
                </div>
                <span
                  className={cx(
                    "eyebrow px-2.5 py-1",
                    r.status === "confirmed" ? "bg-avail text-paper" : r.status === "declined" ? "bg-booked text-paper" : "bg-limited text-paper",
                  )}
                >
                  {r.status}
                </span>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <label>
                  <span className="eyebrow text-stone">Date</span>
                  <input type="date" value={r.date} onChange={(e) => edit(r, { date: e.target.value })} className={field} />
                </label>
                {r.service === "multiday" && (
                  <label>
                    <span className="eyebrow text-stone">End date</span>
                    <input
                      type="date"
                      value={r.endDate ?? ""}
                      onChange={(e) => edit(r, { endDate: e.target.value || undefined })}
                      className={field}
                    />
                  </label>
                )}
                {r.service !== "multiday" && (
                  <label>
                    <span className="eyebrow text-stone">Time</span>
                    <input type="time" value={r.time ?? ""} onChange={(e) => edit(r, { time: e.target.value || undefined })} className={field} />
                  </label>
                )}
                {r.service !== "multiday" && (
                  <label>
                    <span className="eyebrow text-stone">Car busy (min)</span>
                    <input
                      type="number"
                      min={30}
                      step={15}
                      value={durationOf(r)}
                      onChange={(e) => edit(r, { minutes: Number(e.target.value) || undefined })}
                      className={field}
                    />
                  </label>
                )}
              </div>
              {!r.time && r.service !== "multiday" && (
                <p className="mt-2 text-[0.8rem] text-limited">No time set — the whole day is blocked when confirmed.</p>
              )}
              <dl className="mt-4 grid grid-cols-1 gap-x-6 gap-y-1.5 text-[0.88rem] sm:grid-cols-2">
                {rows
                  .filter(([, v]) => v !== "" && v !== undefined)
                  .map(([k, v]) => (
                    <div key={k} className="flex gap-2">
                      <dt className="shrink-0 text-stone">{k}:</dt>
                      <dd className="break-words text-ink">{v}</dd>
                    </div>
                  ))}
              </dl>
              {note?.id === r.id && <p className={cx("mt-3 text-[0.86rem]", note.ok ? "text-avail" : "text-rouge")}>{note.text}</p>}
              <div className="mt-4 flex flex-wrap gap-2">
                {r.status !== "confirmed" && (
                  <button type="button" onClick={() => doConfirm(r)} className={cx(btn, "border-avail bg-avail text-paper hover:opacity-90")}>
                    Confirm
                  </button>
                )}
                {r.status !== "declined" && (
                  <button type="button" onClick={() => cms.updateRequest(r.id, { status: "declined" })} className={btnGhost}>
                    Decline
                  </button>
                )}
                {r.status !== "pending" && (
                  <button type="button" onClick={() => cms.updateRequest(r.id, { status: "pending" })} className={btnGhost}>
                    Back to pending
                  </button>
                )}
                {r.phone && (
                  <a
                    href={`https://wa.me/${r.phone.replace(/\D/g, "")}?text=${encodeURIComponent(replyText(r, r.status))}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={btnGhost}
                  >
                    WhatsApp reply
                  </a>
                )}
                {r.email && (
                  <a
                    href={`mailto:${r.email}?subject=${encodeURIComponent(`Your request ${r.id} — Bonjour Paris Ride`)}&body=${encodeURIComponent(replyText(r, r.status))}`}
                    className={btnGhost}
                  >
                    Email reply
                  </a>
                )}
                <button
                  type="button"
                  onClick={() => window.confirm(`Delete request ${r.id}?`) && cms.removeRequest(r.id)}
                  className={cx(btnGhost, "text-rouge")}
                >
                  <Trash2 size={13} aria-hidden="true" /> Delete
                </button>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}

function AddRequest({ onDone }: { onDone: () => void }) {
  const [f, setF] = useState({
    service: "airport" as ServiceId,
    optionId: "cdg",
    direction: "from" as "from" | "to",
    date: todayISO(),
    endDate: "",
    time: "",
    pax: 2,
    name: "",
    phone: "",
    email: "",
    notes: "",
  });
  const set = (p: Partial<typeof f>) => setF((x) => ({ ...x, ...p }));
  const submit = (e: FormEvent) => {
    e.preventDefault();
    const priced = isPriced(f.service);
    cms.addRequest({
      id: `BPR-${uid()}`,
      createdAt: new Date().toISOString(),
      status: "pending",
      kind: priced ? "booking" : "quote",
      source: "manual",
      service: f.service,
      optionId: priced ? f.optionId : undefined,
      direction: f.service === "airport" ? f.direction : undefined,
      date: f.date,
      endDate: f.service === "multiday" ? f.endDate || undefined : undefined,
      time: f.time || undefined,
      pax: f.pax,
      price: priced ? findOption(f.service, f.optionId)?.price ?? null : null,
      name: f.name || undefined,
      phone: f.phone || undefined,
      email: f.email || undefined,
      notes: f.notes || undefined,
      lang: "en",
    });
    onDone();
  };
  return (
    <form onSubmit={submit} className="mt-5 grid grid-cols-2 gap-3 border border-rule bg-[#fffdf9] p-5 md:grid-cols-4">
      <label className="col-span-2 md:col-span-1">
        <span className="eyebrow text-stone">Service</span>
        <select
          value={f.service}
          onChange={(e) => {
            const s = e.target.value as ServiceId;
            set({ service: s, optionId: optionsOf(s)[0]?.id ?? "" });
          }}
          className={field}
        >
          {SERVICES.map((s) => (
            <option key={s} value={s}>
              {en.services[s]}
            </option>
          ))}
        </select>
      </label>
      {isPriced(f.service) && (
        <label className="col-span-2 md:col-span-1">
          <span className="eyebrow text-stone">Option</span>
          <select value={f.optionId} onChange={(e) => set({ optionId: e.target.value })} className={field}>
            {optionsOf(f.service).map((o) => (
              <option key={o.id} value={o.id}>
                {svcLabel({ service: f.service, optionId: o.id })}
              </option>
            ))}
          </select>
        </label>
      )}
      {f.service === "airport" && (
        <label>
          <span className="eyebrow text-stone">Direction</span>
          <select value={f.direction} onChange={(e) => set({ direction: e.target.value as "from" | "to" })} className={field}>
            <option value="from">Airport → Paris</option>
            <option value="to">Paris → airport</option>
          </select>
        </label>
      )}
      <label>
        <span className="eyebrow text-stone">Date</span>
        <input type="date" required value={f.date} onChange={(e) => set({ date: e.target.value })} className={field} />
      </label>
      {f.service === "multiday" ? (
        <label>
          <span className="eyebrow text-stone">End date</span>
          <input type="date" value={f.endDate} onChange={(e) => set({ endDate: e.target.value })} className={field} />
        </label>
      ) : (
        <label>
          <span className="eyebrow text-stone">Time</span>
          <input type="time" value={f.time} onChange={(e) => set({ time: e.target.value })} className={field} />
        </label>
      )}
      <label>
        <span className="eyebrow text-stone">Passengers</span>
        <input type="number" min={1} max={8} value={f.pax} onChange={(e) => set({ pax: Number(e.target.value) || 1 })} className={field} />
      </label>
      <label>
        <span className="eyebrow text-stone">Name</span>
        <input value={f.name} onChange={(e) => set({ name: e.target.value })} className={field} />
      </label>
      <label>
        <span className="eyebrow text-stone">Phone</span>
        <input value={f.phone} onChange={(e) => set({ phone: e.target.value })} className={field} />
      </label>
      <label>
        <span className="eyebrow text-stone">Email</span>
        <input value={f.email} onChange={(e) => set({ email: e.target.value })} className={field} />
      </label>
      <label className="col-span-2 md:col-span-3">
        <span className="eyebrow text-stone">Notes</span>
        <input value={f.notes} onChange={(e) => set({ notes: e.target.value })} className={field} />
      </label>
      <div className="col-span-2 flex items-end md:col-span-1">
        <button type="submit" className={cx(btnInk, "w-full justify-center py-2.5")}>
          Add request
        </button>
      </div>
    </form>
  );
}

/* ── Availability ────────────────────────────────────────────────────────── */

const BRUSHES: { id: DayStatus | "clear"; label: string; dot: string }[] = [
  { id: "available", label: "Available", dot: "bg-avail" },
  { id: "limited", label: "Limited", dot: "bg-limited" },
  { id: "booked", label: "Fully booked", dot: "bg-booked" },
  { id: "blocked", label: "Blocked (holiday / personal)", dot: "bg-ink" },
  { id: "clear", label: "Clear manual status", dot: "border border-ink bg-transparent" },
];

const CELL: Record<DayStatus, string> = {
  available: "border-avail/30 bg-avail/10",
  limited: "border-limited/40 bg-limited/15",
  booked: "border-booked/50 bg-booked/25",
  blocked: "border-ink/40 bg-ink/15",
};

function Availability() {
  const { state } = useStore();
  const [brush, setBrush] = useState<DayStatus | "clear">("blocked");
  const now = new Date();
  const minIdx = now.getFullYear() * 12 + now.getMonth();
  const [view, setView] = useState(minIdx);
  const y = Math.floor(view / 12);
  const m = view % 12;
  const busy = useMemo(() => busyByDay(state.requests), [state.requests]);
  const today = todayISO();

  const cells = useMemo(() => {
    const lead = new Date(y, m, 1).getDay();
    const n = new Date(y, m + 1, 0).getDate();
    return [...Array.from({ length: lead }, () => null), ...Array.from({ length: n }, (_, i) => toISO(new Date(y, m, i + 1, 12)))];
  }, [y, m]);

  const upcoming = useMemo(
    () =>
      state.requests
        .filter((r) => r.status === "confirmed")
        .flatMap((r) => slotsOf(r).map((s) => ({ ...s, r })))
        .filter((s) => s.date >= today)
        .sort((a, b) => a.date.localeCompare(b.date) || a.start - b.start)
        .slice(0, 25),
    [state.requests, today],
  );

  return (
    <div className="grid grid-cols-12 gap-8">
      <div className="col-span-12 lg:col-span-8">
        <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Status to apply">
          {BRUSHES.map((b) => (
            <button
              key={b.id}
              type="button"
              role="radio"
              aria-checked={brush === b.id}
              onClick={() => setBrush(b.id)}
              className={cx(btn, brush === b.id ? "border-ink bg-paper2 text-ink" : "border-rule text-ink hover:border-ink")}
            >
              <span className={cx("h-2.5 w-2.5 rounded-full", b.dot)} />
              {b.label}
            </button>
          ))}
        </div>
        <p className="mt-3 text-[0.84rem] leading-relaxed text-stone">
          Choose a status, then click days to apply it. Days without a manual status follow confirmed journeys
          automatically — limited when partly busy, fully booked from {CALENDAR.dayCapacityMinutes / 60} busy hours —
          otherwise they show as “{CALENDAR.defaultStatus}”. Visitors never see names or details, only colours.
        </p>

        <div className="mt-6 flex items-center justify-between">
          <button type="button" onClick={() => setView((v) => Math.max(minIdx, v - 1))} disabled={view <= minIdx} aria-label="Previous month" className={cx(btnGhost, "disabled:opacity-30")}>
            <ChevronLeft size={16} aria-hidden="true" />
          </button>
          <p className="font-display text-[1.5rem] text-ink">
            {new Date(y, m, 1).toLocaleDateString("en-GB", { month: "long", year: "numeric" })}
          </p>
          <button
            type="button"
            onClick={() => setView((v) => Math.min(minIdx + CALENDAR.horizonMonths, v + 1))}
            disabled={view >= minIdx + CALENDAR.horizonMonths}
            aria-label="Next month"
            className={cx(btnGhost, "disabled:opacity-30")}
          >
            <ChevronRight size={16} aria-hidden="true" />
          </button>
        </div>
        <div className="mt-4 grid grid-cols-7 gap-1.5">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
            <span key={d} className="eyebrow py-1 text-center text-stone">
              {d}
            </span>
          ))}
          {cells.map((iso, i) => {
            if (!iso) return <span key={`e${i}`} />;
            const past = iso < today;
            const st = computeStatus(iso, state.overrides, busy);
            const manual = Boolean(state.overrides[iso]);
            const jobs = new Set((busy.get(iso) ?? []).map((s) => s.id)).size;
            return (
              <button
                key={iso}
                type="button"
                disabled={past}
                onClick={() => cms.setOverride(iso, brush === "clear" ? null : brush)}
                aria-label={`${iso}: ${st}${manual ? " (manual)" : ""}${jobs ? `, ${jobs} confirmed` : ""}`}
                className={cx(
                  "relative flex h-16 flex-col items-start justify-between border p-1.5 text-left transition-transform hover:-translate-y-0.5 disabled:pointer-events-none disabled:opacity-35",
                  CELL[st],
                )}
              >
                <span className="num font-display text-[1rem] text-ink">{Number(iso.slice(8))}</span>
                <span className="flex w-full items-center justify-between text-[0.66rem] text-ink/70">
                  <span>{manual ? "manual" : ""}</span>
                  {jobs > 0 && <span className="num rounded-full bg-ink px-1.5 text-paper">{jobs}</span>}
                </span>
              </button>
            );
          })}
        </div>
      </div>
      <aside className="col-span-12 lg:col-span-4">
        <h3 className="font-display text-[1.3rem] text-ink">Upcoming confirmed journeys</h3>
        {upcoming.length === 0 ? (
          <p className="mt-3 text-[0.88rem] text-stone">None yet. Confirm a request to see it here.</p>
        ) : (
          <ul className="mt-3 divide-y divide-rule border-y border-rule">
            {upcoming.map((s, i) => (
              <li key={`${s.id}-${s.date}-${i}`} className="py-2.5 text-[0.86rem]">
                <p className="num text-ink">
                  {s.date} · {s.start === 0 && s.end === 1440 ? "whole day" : `${fmtMin(s.start)}–${fmtMin(s.end)}`}
                </p>
                <p className="text-stone">
                  {svcLabel(s.r)} · {s.r.id}
                </p>
              </li>
            ))}
          </ul>
        )}
        <p className="mt-4 text-[0.8rem] leading-relaxed text-stone">
          A {CALENDAR.bufferMinutes}-minute buffer is kept between journeys. Overlapping confirmations are refused
          automatically.
        </p>
      </aside>
    </div>
  );
}

/* ── Reviews ─────────────────────────────────────────────────────────────── */

const EMPTY_REVIEW: Review = {
  id: "",
  name: "",
  country: "",
  rating: 5,
  text: "",
  service: undefined,
  date: "",
  sourceName: "",
  sourceUrl: "",
  photo: "",
  consent: false,
  published: true,
};

function Reviews() {
  const { state } = useStore();
  const [f, setF] = useState<Review>(EMPTY_REVIEW);
  const [err, setErr] = useState("");
  const set = (p: Partial<Review>) => setF((x) => ({ ...x, ...p }));

  const save = (e: FormEvent) => {
    e.preventDefault();
    if (!f.name.trim() || !f.text.trim()) {
      setErr("Display name and review text are required.");
      return;
    }
    if (f.photo && !f.consent) {
      setErr("Tick the consent box to publish the guest's photo.");
      return;
    }
    if (f.sourceUrl && !/^https?:\/\//.test(f.sourceUrl)) {
      setErr("The source link must start with https://");
      return;
    }
    cms.saveReview({ ...f, id: f.id || `RV-${uid()}`, name: f.name.trim(), text: f.text.trim() });
    setF(EMPTY_REVIEW);
    setErr("");
  };

  const onPhoto = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      const { src } = await compressImage(file, 320, 0.8);
      set({ photo: src });
    } catch {
      setErr("This image could not be read.");
    }
  };

  return (
    <div className="grid grid-cols-12 gap-8">
      <form onSubmit={save} className="col-span-12 space-y-4 border border-rule bg-[#fffdf9] p-5 lg:col-span-5">
        <p className="border-l-2 border-limited bg-limited/10 px-3 py-2 text-[0.82rem] leading-snug text-ink">
          Only publish genuine reviews, with the guest's permission. Never invent names, ratings, photos or review
          counts. Link to the original review when there is one.
        </p>
        <div className="grid grid-cols-2 gap-3">
          <label>
            <span className="eyebrow text-stone">Display name *</span>
            <input value={f.name} onChange={(e) => set({ name: e.target.value })} className={field} />
          </label>
          <label>
            <span className="eyebrow text-stone">Country (optional)</span>
            <input value={f.country} onChange={(e) => set({ country: e.target.value })} className={field} />
          </label>
          <label>
            <span className="eyebrow text-stone">Rating</span>
            <select value={f.rating} onChange={(e) => set({ rating: Number(e.target.value) })} className={field}>
              {[5, 4, 3, 2, 1].map((n) => (
                <option key={n} value={n}>
                  {"★".repeat(n)} ({n})
                </option>
              ))}
            </select>
          </label>
          <label>
            <span className="eyebrow text-stone">Service used</span>
            <select value={f.service ?? ""} onChange={(e) => set({ service: (e.target.value || undefined) as ServiceId | undefined })} className={field}>
              <option value="">—</option>
              {SERVICES.map((s) => (
                <option key={s} value={s}>
                  {en.services[s]}
                </option>
              ))}
            </select>
          </label>
        </div>
        <label className="block">
          <span className="eyebrow text-stone">Review text *</span>
          <textarea rows={5} value={f.text} onChange={(e) => set({ text: e.target.value })} className={field} />
        </label>
        <div className="grid grid-cols-2 gap-3">
          <label>
            <span className="eyebrow text-stone">Date of the trip</span>
            <input type="date" value={f.date} onChange={(e) => set({ date: e.target.value })} className={field} />
          </label>
          <label>
            <span className="eyebrow text-stone">Source name</span>
            <input value={f.sourceName} onChange={(e) => set({ sourceName: e.target.value })} placeholder="Google, TripAdvisor…" className={field} />
          </label>
        </div>
        <label className="block">
          <span className="eyebrow text-stone">Link to the original review</span>
          <input value={f.sourceUrl} onChange={(e) => set({ sourceUrl: e.target.value })} placeholder="https://…" className={field} />
        </label>
        <div className="flex items-center gap-4">
          {f.photo ? <img src={f.photo} alt="" className="h-14 w-14 rounded-full object-cover" /> : <span className="h-14 w-14 rounded-full bg-paper2" />}
          <label className={cx(btnGhost, "cursor-pointer")}>
            <Upload size={14} aria-hidden="true" /> Guest photo (optional)
            <input type="file" accept="image/*" onChange={onPhoto} className="sr-only" />
          </label>
          {f.photo && (
            <button type="button" onClick={() => set({ photo: "" })} className="text-[0.82rem] text-rouge">
              Remove
            </button>
          )}
        </div>
        <label className="flex items-start gap-2.5 text-[0.86rem] text-ink">
          <input type="checkbox" checked={f.consent} onChange={(e) => set({ consent: e.target.checked })} className="mt-0.5 h-4 w-4 accent-[#c8552b]" />
          The guest agreed to the publication of this review{f.photo ? " and photo" : ""}.
        </label>
        <label className="flex items-center gap-2.5 text-[0.86rem] text-ink">
          <input type="checkbox" checked={f.published} onChange={(e) => set({ published: e.target.checked })} className="h-4 w-4 accent-[#c8552b]" />
          Published on the website
        </label>
        {err && (
          <p role="alert" className="text-[0.85rem] text-rouge">
            {err}
          </p>
        )}
        <div className="flex gap-2">
          <button type="submit" className={btnInk}>
            {f.id ? "Save changes" : "Add review"}
          </button>
          {f.id && (
            <button type="button" onClick={() => setF(EMPTY_REVIEW)} className={btnGhost}>
              Cancel
            </button>
          )}
        </div>
      </form>
      <div className="col-span-12 space-y-3 lg:col-span-7">
        {state.reviews.length === 0 && (
          <p className="border border-dashed border-rule p-8 text-center text-[0.9rem] text-stone">
            No reviews yet. Until you add one, the website shows an elegant invitation with clearly labelled
            placeholders.
          </p>
        )}
        {state.reviews.map((r) => (
          <div key={r.id} className="flex flex-wrap items-start gap-4 border border-rule bg-[#fffdf9] p-4">
            <div className="min-w-0 flex-1">
              <p className="font-display text-[1.05rem] text-ink">
                {r.name} <span className="text-limited">{"★".repeat(r.rating)}</span>
              </p>
              <p className="mt-1 line-clamp-2 text-[0.86rem] text-stone">{r.text}</p>
              <p className="eyebrow mt-2 text-stone">{r.published ? "Published" : "Hidden"}</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button type="button" onClick={() => setF(r)} className={btnGhost}>
                Edit
              </button>
              <button type="button" onClick={() => cms.saveReview({ ...r, published: !r.published })} className={btnGhost}>
                {r.published ? "Hide" : "Publish"}
              </button>
              <button type="button" onClick={() => window.confirm("Delete this review?") && cms.removeReview(r.id)} className={cx(btnGhost, "text-rouge")}>
                <Trash2 size={13} aria-hidden="true" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── Gallery ─────────────────────────────────────────────────────────────── */

function Gallery() {
  const { state } = useStore();
  const [cat, setCat] = useState<GalleryCat>("guests");
  const [caption, setCaption] = useState("");
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const needsConsent = cat === "guests" || cat === "couples" || cat === "families";

  const onFiles = async (e: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    e.target.value = "";
    if (!files.length) return;
    if (needsConsent && !consent) {
      setErr("Confirm that the people in these photos agreed to their publication.");
      return;
    }
    setBusy(true);
    setErr("");
    try {
      const items: GalleryItem[] = [];
      for (const file of files) {
        const { src, w, h } = await compressImage(file);
        items.push({
          id: `PH-${uid()}`,
          src,
          w,
          h,
          caption: caption.trim() || file.name.replace(/\.[^.]+$/, ""),
          category: cat,
          consent,
          createdAt: new Date().toISOString(),
        });
      }
      cms.addPhotos(items);
      setCaption("");
    } catch {
      setErr("One of the files could not be read.");
    }
    setBusy(false);
  };

  return (
    <div>
      <div className="grid grid-cols-1 gap-3 border border-rule bg-[#fffdf9] p-5 md:grid-cols-4">
        <label>
          <span className="eyebrow text-stone">Category</span>
          <select value={cat} onChange={(e) => setCat(e.target.value as GalleryCat)} className={field}>
            {GALLERY_CATS.map((c) => (
              <option key={c} value={c}>
                {en.gallery.cats[c]}
              </option>
            ))}
          </select>
        </label>
        <label className="md:col-span-2">
          <span className="eyebrow text-stone">Caption</span>
          <input value={caption} onChange={(e) => setCaption(e.target.value)} placeholder="e.g. Arrival at CDG with the Martin family" className={field} />
        </label>
        <label className={cx(btnInk, "cursor-pointer justify-center self-end py-2.5", busy && "pointer-events-none opacity-50")}>
          <Upload size={14} aria-hidden="true" /> {busy ? "Optimising…" : "Upload photos"}
          <input type="file" accept="image/*" multiple onChange={onFiles} className="sr-only" />
        </label>
        <label className="flex items-start gap-2.5 text-[0.86rem] text-ink md:col-span-4">
          <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} className="mt-0.5 h-4 w-4 accent-[#c8552b]" />
          These are customer photos and every identifiable person agreed to their publication.
          {needsConsent ? " (required for this category)" : ""}
        </label>
        {err && (
          <p role="alert" className="text-[0.85rem] text-rouge md:col-span-4">
            {err}
          </p>
        )}
        <p className="text-[0.8rem] text-stone md:col-span-4">
          Photos are resized to 1600 px and compressed automatically so the gallery stays fast.
        </p>
      </div>
      <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
        {state.photos.length === 0 && (
          <p className="col-span-full border border-dashed border-rule p-8 text-center text-[0.9rem] text-stone">
            No uploads yet. The gallery shows curated Paris photography meanwhile, and an invitation in “Customer
            experiences”.
          </p>
        )}
        {state.photos.map((p) => (
          <div key={p.id} className="border border-rule bg-[#fffdf9]">
            <img src={p.src} alt={p.caption} className="aspect-[4/3] w-full object-cover" />
            <div className="space-y-2 p-3">
              <input
                defaultValue={p.caption}
                onBlur={(e) => cms.updatePhoto(p.id, { caption: e.target.value })}
                aria-label="Caption"
                className={field}
              />
              <select value={p.category} onChange={(e) => cms.updatePhoto(p.id, { category: e.target.value as GalleryCat })} aria-label="Category" className={field}>
                {GALLERY_CATS.map((c) => (
                  <option key={c} value={c}>
                    {en.gallery.cats[c]}
                  </option>
                ))}
              </select>
              <div className="flex items-center justify-between">
                <span className="eyebrow text-stone">{p.consent ? "Customer · consent" : "Owner photo"}</span>
                <button type="button" onClick={() => window.confirm("Delete this photo?") && cms.removePhoto(p.id)} className="text-rouge" aria-label="Delete photo">
                  <Trash2 size={15} aria-hidden="true" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── Data & acceptance checks ────────────────────────────────────────────── */

interface Check {
  name: string;
  pass: boolean;
  detail: string;
}

function keysOf(o: unknown, prefix = ""): string[] {
  if (!o || typeof o !== "object") return [];
  return Object.entries(o as Record<string, unknown>).flatMap(([k, v]) =>
    Array.isArray(v)
      ? [`${prefix}${k}[${v.length}]`]
      : v && typeof v === "object"
        ? keysOf(v, `${prefix}${k}.`)
        : [`${prefix}${k}:${typeof v}`],
  );
}

function runChecks(): Check[] {
  const out: Check[] = [];
  const add = (name: string, pass: boolean, detail: string) => out.push({ name, pass, detail });
  const today = todayISO();

  add(
    "Standard transfer prices come from the approved price list",
    OPTIONS.airport.every((o) => o.price !== null && Number.isInteger(o.price) && o.price > 0),
    OPTIONS.airport.map((o) => `${o.code} €${o.price}`).join(" · "),
  );
  add(
    "Multi-day & custom journeys are quotations (no invented price)",
    optionsOf("multiday").length === 0 && optionsOf("custom").length === 0 && fromPrice("multiday") === null,
    "Shown as “on request”; the forms send quotation requests",
  );
  const yesterday = addDays(today, -1);
  add("Past dates cannot be booked", yesterday < today && !isSelectable("past"), `${yesterday} is rendered as a disabled “past” day`);

  const far = addDays(today, 500);
  const mk = (id: string, time: string, status: ReqStatus, extra: Partial<Req> = {}): Req => ({
    id,
    createdAt: "",
    status,
    kind: "booking",
    service: "airport",
    optionId: "cdg",
    date: far,
    time,
    pax: 2,
    ...extra,
  });
  const a = mk("T1", "10:00", "confirmed");
  add("Overlapping journeys cannot both be confirmed", findConflicts(mk("T2", "11:30", "pending"), [a]).length === 1, "CDG 10:00 (150 min + 30 min buffer) refuses 11:30");
  add("Separate journeys on the same day are allowed", findConflicts(mk("T3", "14:00", "pending"), [a]).length === 0, "CDG 10:00 then 14:00 → accepted");
  add(
    "Multi-day tours block whole days",
    findConflicts(mk("T4", "", "pending", { service: "multiday", optionId: undefined, endDate: addDays(far, 1) }), [a]).length === 1,
    "2-day tour vs. a 10:00 transfer → refused",
  );
  add(
    "Availability data source",
    true,
    DATA.availabilityUrl ? `Published file: ${DATA.availabilityUrl}` : "Demonstration mode — owner-managed in this browser, labelled on the calendar",
  );
  add(
    "Requests reach the business",
    true,
    DATA.formEndpoint ? `Form endpoint: ${DATA.formEndpoint}` : "WhatsApp / email hand-off with the full request (add a form endpoint for automatic delivery)",
  );
  add("WhatsApp link format", /^https:\/\/wa\.me\/\d{8,15}$/.test(waLink()), waLink());
  add("Telephone link format", /^tel:\+\d{8,15}$/.test(telLink), telLink);
  add("Email link format", /^mailto:[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(mailLink()), mailLink());
  add("Real contact details entered", !isPlaceholderPhone, isPlaceholderPhone ? `${CONTACT.phoneDisplay} is a placeholder — replace it in src/config.ts` : CONTACT.phoneDisplay);
  const ref = keysOf(en).join("|");
  const bad = Object.entries(DICTS)
    .filter(([, d]) => keysOf(d).join("|") !== ref)
    .map(([k]) => k);
  add("All 7 languages are complete", bad.length === 0, bad.length ? `Different structure: ${bad.join(", ")}` : Object.keys(DICTS).join(" · "));
  add("Admin passcode changed", ADMIN_PASSCODE !== "bonjour-paris", ADMIN_PASSCODE === "bonjour-paris" ? "Still the default — change it in src/config.ts" : "Custom passcode");
  return out;
}

function download(name: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function DataTab() {
  const { state } = useStore();
  const [checks, setChecks] = useState<Check[] | null>(null);
  const [msg, setMsg] = useState("");

  const onImport = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      const json = JSON.parse(await file.text());
      if (!window.confirm("Replace all data stored in this browser with this backup?")) return;
      cms.replace(json);
      setMsg("Backup imported.");
    } catch {
      setMsg("This file is not a valid backup.");
    }
  };

  return (
    <div className="grid grid-cols-12 gap-8">
      <div className="col-span-12 space-y-6 lg:col-span-6">
        <div className="border border-rule bg-[#fffdf9] p-5">
          <h3 className="font-display text-[1.3rem] text-ink">Publish to every visitor</h3>
          <ol className="mt-3 list-decimal space-y-1.5 pl-5 text-[0.88rem] leading-relaxed text-stone">
            <li>Download the two public files below (they contain no personal data).</li>
            <li>Upload them to your hosting.</li>
            <li>
              Paste their URLs in <code>src/config.ts</code> → <code>DATA.availabilityUrl</code> and{" "}
              <code>DATA.contentUrl</code>, then rebuild. The calendar label switches from “demonstration” to live.
            </li>
          </ol>
          <div className="mt-4 flex flex-wrap gap-2">
            <button type="button" onClick={() => download("availability.json", exportAvailability(state.overrides, state.requests))} className={btnInk}>
              <Download size={14} aria-hidden="true" /> availability.json
            </button>
            <button
              type="button"
              onClick={() => download("content.json", { reviews: state.reviews.filter((r) => r.published), photos: state.photos, car: state.car })}
              className={btnInk}
            >
              <Download size={14} aria-hidden="true" /> content.json
            </button>
          </div>
        </div>
        <div className="border border-rule bg-[#fffdf9] p-5">
          <h3 className="font-display text-[1.3rem] text-ink">Backup</h3>
          <p className="mt-2 text-[0.86rem] text-stone">
            The full backup includes guests' contact details — keep it private.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <button type="button" onClick={() => download(`bpr-backup-${todayISO()}.json`, state)} className={btnGhost}>
              <Download size={14} aria-hidden="true" /> Download backup
            </button>
            <label className={cx(btnGhost, "cursor-pointer")}>
              <Upload size={14} aria-hidden="true" /> Import backup
              <input type="file" accept="application/json" onChange={onImport} className="sr-only" />
            </label>
            <button
              type="button"
              onClick={() => window.confirm("Delete ALL requests, statuses, reviews and photos stored in this browser?") && cms.reset()}
              className={cx(btnGhost, "text-rouge")}
            >
              <Trash2 size={14} aria-hidden="true" /> Reset everything
            </button>
          </div>
          {msg && <p className="mt-3 text-[0.85rem] text-ink">{msg}</p>}
        </div>
      </div>
      <div className="col-span-12 lg:col-span-6">
        <div className="border border-rule bg-[#fffdf9] p-5">
          <div className="flex items-center justify-between gap-4">
            <h3 className="font-display text-[1.3rem] text-ink">Acceptance checks</h3>
            <button type="button" onClick={() => setChecks(runChecks())} className={btnInk}>
              Run checks
            </button>
          </div>
          <p className="mt-2 text-[0.84rem] text-stone">
            Automated checks of prices, dates, overlap rules, links and translations. Opening the calendar, switching
            languages and the mobile layout should also be tried by hand before launch.
          </p>
          {checks && (
            <ul className="mt-4 divide-y divide-rule border-y border-rule">
              {checks.map((c) => (
                <li key={c.name} className="flex gap-3 py-3">
                  {c.pass ? (
                    <CircleCheck size={18} className="mt-0.5 shrink-0 text-avail" aria-label="Pass" />
                  ) : (
                    <CircleX size={18} className="mt-0.5 shrink-0 text-rouge" aria-label="Needs attention" />
                  )}
                  <div className="min-w-0">
                    <p className="text-[0.9rem] text-ink">{c.name}</p>
                    <p className="break-words text-[0.8rem] text-stone">{c.detail}</p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
