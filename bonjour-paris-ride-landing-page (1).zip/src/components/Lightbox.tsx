import { motion, useReducedMotion } from "framer-motion";
import { useCallback, useEffect, useMemo, useRef } from "react";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { useI18n } from "../i18n";
import { CURATED, srcOf, srcSetOf, type GalleryCat, type Photo } from "../photos";
import { usePublicContent } from "../lib/store";
import { EASE, Img, cx, useFocusTrap, useLockBody } from "./ui";

export interface GItem {
  id: string;
  src: string;
  photo?: Photo;
  caption: string;
  cats: GalleryCat[];
  kind: "stock" | "illustrative" | "guest" | "owner";
  credit?: string;
  w: number;
  h: number;
}

/** Owner uploads first (customer photos only with consent), then curated photography. */
export function useGalleryItems(): GItem[] {
  const { s, cap } = useI18n();
  const { photos, car } = usePublicContent();
  return useMemo(() => {
    const uploads: GItem[] = photos.map((p) => {
      const guest = p.consent || p.category === "guests";
      const cats = Array.from(new Set<GalleryCat>([p.category, ...(guest ? (["guests"] as GalleryCat[]) : [])]));
      return {
        id: p.id,
        src: p.src,
        caption: p.caption,
        cats,
        kind: guest ? "guest" : "owner",
        w: p.w ?? 4,
        h: p.h ?? 3,
      };
    });
    // real photos of the owner's car (uploaded in the Owner area)
    const carItems: GItem[] = [];
    (["front", "side", "interior", "luggage"] as const).forEach((slot) => {
      const c = car[slot];
      if (c) {
        carItems.push({
          id: `car-${slot}`,
          src: c.src,
          caption: `${s.common.ourCar} — ${s.about.slots[slot]}`,
          cats: ["airport"],
          kind: "owner",
          w: c.w,
          h: c.h,
        });
      }
    });
    const curated: GItem[] = CURATED.map((p) => ({
      id: p.id,
      src: p.src,
      photo: p,
      caption: cap(p.key),
      cats: p.cats,
      kind: p.local ? "illustrative" : "stock",
      credit: p.credit,
      w: p.w,
      h: p.h,
    }));
    return [...uploads, ...carItems, ...curated];
  }, [photos, car, s, cap]);
}

export function GalleryTile({
  item,
  onOpen,
  sizes = "(min-width:1024px) 33vw, 50vw",
}: {
  item: GItem;
  onOpen: () => void;
  sizes?: string;
}) {
  const { t } = useI18n();
  return (
    <button
      type="button"
      onClick={onOpen}
      aria-label={t.gallery.openPhoto(item.caption)}
      className="group relative block w-full overflow-hidden bg-inkdeep text-left"
    >
      <div style={{ aspectRatio: `${item.w} / ${item.h}` }} className="w-full">
        {item.photo ? (
          <Img
            photo={item.photo}
            alt={item.caption}
            sizes={sizes}
            className="h-full w-full object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-105"
          />
        ) : (
          <img
            src={item.src}
            alt={item.caption}
            loading="lazy"
            decoding="async"
            className="h-full w-full object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-105"
          />
        )}
      </div>
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-inkdeep/85 via-inkdeep/10 to-transparent transition-opacity duration-500 md:opacity-0 md:group-hover:opacity-100 md:group-focus-visible:opacity-100" />
      <span className="pointer-events-none absolute inset-x-0 bottom-0 p-4 text-[0.9rem] leading-snug text-paper transition-all duration-500 md:translate-y-2 md:opacity-0 md:group-hover:translate-y-0 md:group-hover:opacity-100 md:group-focus-visible:translate-y-0 md:group-focus-visible:opacity-100">
        {item.caption}
      </span>
      {item.kind === "guest" && (
        <span className="eyebrow absolute left-3 top-3 bg-rouge px-2 py-1 text-paper">{t.gallery.guest}</span>
      )}
    </button>
  );
}

export function Lightbox({
  items,
  index,
  onIndex,
  onClose,
}: {
  items: GItem[];
  index: number;
  onIndex: (i: number) => void;
  onClose: () => void;
}) {
  const { t } = useI18n();
  const reduce = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);
  const startX = useRef<number | null>(null);
  useLockBody(true);
  useFocusTrap(ref, true, onClose);

  const item = items[index];
  const go = useCallback(
    (d: number) => onIndex((index + d + items.length) % items.length),
    [index, items.length, onIndex],
  );

  useEffect(() => {
    const on = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
    };
    window.addEventListener("keydown", on);
    return () => window.removeEventListener("keydown", on);
  }, [go]);

  if (!item) return null;

  const label =
    item.kind === "stock"
      ? `${t.common.stock} · ${t.common.photoBy(item.credit ?? "")}`
      : item.kind === "illustrative"
        ? t.common.illustrative
        : item.kind === "guest"
          ? t.gallery.guest
          : "";

  const round =
    "flex h-12 w-12 items-center justify-center rounded-full border border-paper/30 bg-inkdeep/50 text-paper backdrop-blur transition-colors duration-300 hover:bg-paper hover:text-ink";

  return (
    <motion.div
      ref={ref}
      role="dialog"
      aria-modal="true"
      aria-label={t.gallery.viewer}
      className="fixed inset-0 z-[80] flex flex-col bg-inkdeep/95 text-paper backdrop-blur-md"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex items-center justify-between px-5 py-4">
        <span className="eyebrow num text-paper/70">{t.gallery.count(index + 1, items.length)}</span>
        <button type="button" onClick={onClose} aria-label={t.common.close} className={round}>
          <X size={18} aria-hidden="true" />
        </button>
      </div>
      <div
        className="relative flex flex-1 touch-pan-y items-center justify-center px-4 md:px-24"
        onPointerDown={(e) => {
          startX.current = e.clientX;
        }}
        onPointerUp={(e) => {
          if (startX.current === null) return;
          const dx = e.clientX - startX.current;
          startX.current = null;
          if (Math.abs(dx) > 50) go(dx < 0 ? 1 : -1);
        }}
      >
        <motion.img
          key={item.id}
          src={item.photo ? srcOf(item.photo, 2400) : item.src}
          srcSet={item.photo ? srcSetOf(item.photo) : undefined}
          sizes="90vw"
          alt={item.caption}
          draggable={false}
          initial={reduce ? { opacity: 0 } : { opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4, ease: EASE }}
          className="max-h-[76vh] max-w-full select-none object-contain shadow-[0_40px_90px_-30px_rgba(0,0,0,0.9)]"
        />
        {items.length > 1 && (
          <>
            <button
              type="button"
              onClick={() => go(-1)}
              aria-label={t.common.prev}
              className={cx(round, "absolute left-3 top-1/2 -translate-y-1/2 md:left-8")}
            >
              <ChevronLeft size={20} aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={() => go(1)}
              aria-label={t.common.next}
              className={cx(round, "absolute right-3 top-1/2 -translate-y-1/2 md:right-8")}
            >
              <ChevronRight size={20} aria-hidden="true" />
            </button>
          </>
        )}
      </div>
      <div className="px-5 pb-7 pt-4 text-center">
        <p className="font-display text-[1.2rem]">{item.caption}</p>
        {label && <p className="eyebrow mt-2 text-paper/55">{label}</p>}
      </div>
    </motion.div>
  );
}
