import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import {
  Fragment,
  useEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
  type RefObject,
} from "react";
import { Minus, Plus } from "lucide-react";
import { srcOf, srcSetOf, type Photo } from "../photos";

export const cx = (...c: (string | false | undefined | null)[]) => c.filter(Boolean).join(" ");

export const EASE: [number, number, number, number] = [0.16, 1, 0.3, 1];

/** "Paris, at *your own pace.*" → accent italics on the starred words. */
export function rich(text: string): ReactNode {
  return text
    .split("*")
    .map((part, i) => (i % 2 === 1 ? <em key={i}>{part}</em> : <Fragment key={i}>{part}</Fragment>));
}

/* ---------------------------------------------------------------- buttons */

const BASE =
  "group inline-flex items-center justify-center gap-3 px-7 py-4 text-center transition-all duration-500 hover:-translate-y-0.5 disabled:pointer-events-none disabled:opacity-40";

export const btn = {
  navy: `${BASE} bg-navy text-ivory hover:bg-golddeep`,
  gold: `${BASE} bg-golddeep text-ivory shadow-[0_16px_34px_-20px_rgba(139,107,50,0.95)] hover:bg-navy`,
  ghost: `${BASE} border border-navy/25 text-navy hover:border-navy hover:bg-navy hover:text-ivory`,
  light: `${BASE} border border-ivory/45 text-ivory backdrop-blur-sm hover:border-ivory hover:bg-ivory hover:text-navy`,
  ivory: `${BASE} bg-ivory text-navy hover:bg-gold`,
};

export function Arrow({ className }: { className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={cx("inline-block transition-transform duration-500 group-hover:translate-x-1", className)}
    >
      →
    </span>
  );
}

/* ------------------------------------------------------------------ hooks */

export function useMedia(query: string) {
  const [match, setMatch] = useState(() => typeof window !== "undefined" && window.matchMedia(query).matches);
  useEffect(() => {
    const mq = window.matchMedia(query);
    const on = () => setMatch(mq.matches);
    on();
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, [query]);
  return match;
}

export function useLockBody(active: boolean) {
  useEffect(() => {
    if (!active) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [active]);
}

const FOCUSABLE =
  'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';

/** Keeps keyboard focus inside a dialog, closes on Escape, restores focus. */
export function useFocusTrap(ref: RefObject<HTMLElement | null>, active: boolean, onClose: () => void) {
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    if (!active) return;
    const previous = document.activeElement as HTMLElement | null;
    const node = ref.current;
    const first = node?.querySelector<HTMLElement>("[data-autofocus]") ?? node?.querySelector<HTMLElement>(FOCUSABLE);
    first?.focus({ preventScroll: true });
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        closeRef.current();
        return;
      }
      if (e.key !== "Tab" || !node) return;
      const items = Array.from(node.querySelectorAll<HTMLElement>(FOCUSABLE)).filter((el) => el.offsetParent !== null);
      if (!items.length) return;
      const firstEl = items[0];
      const lastEl = items[items.length - 1];
      if (e.shiftKey && document.activeElement === firstEl) {
        e.preventDefault();
        lastEl.focus();
      } else if (!e.shiftKey && document.activeElement === lastEl) {
        e.preventDefault();
        firstEl.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
      previous?.focus?.({ preventScroll: true });
    };
  }, [active, ref]);
}

export function useTween(target: number, duration = 650) {
  const reduce = useReducedMotion();
  const [value, setValue] = useState(target);
  const current = useRef(target);
  useEffect(() => {
    const from = current.current;
    if (reduce || Math.abs(from - target) < 0.5) {
      current.current = target;
      setValue(target);
      return;
    }
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      const e = 1 - Math.pow(1 - p, 3);
      const v = from + (target - from) * e;
      current.current = v;
      setValue(v);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration, reduce]);
  return value;
}

/** Current time in Paris, "HH:MM". */
export function useParisClock() {
  const fmt = useMemo(
    () =>
      new Intl.DateTimeFormat("en-GB", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
        timeZone: "Europe/Paris",
      }),
    [],
  );
  const read = () => fmt.format(new Date()).replace(/^24/, "00");
  const [now, setNow] = useState(read);
  useEffect(() => {
    const id = window.setInterval(() => setNow(read()), 15000);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fmt]);
  return now;
}

/* ---------------------------------------------------------------- reveals */

export function Reveal({
  children,
  className,
  delay = 0,
  y = 24,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  y?: number;
}) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={reduce ? { opacity: 0 } : { opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-8% 0px -8% 0px" }}
      transition={{ duration: 0.9, delay, ease: EASE }}
    >
      {children}
    </motion.div>
  );
}

export function Stagger({ children, className, gap = 0.09 }: { children: ReactNode; className?: string; gap?: number }) {
  return (
    <motion.div
      className={className}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-8% 0px -8% 0px" }}
      variants={{ hidden: {}, show: { transition: { staggerChildren: gap } } }}
    >
      {children}
    </motion.div>
  );
}

export function Item({ children, className }: { children: ReactNode; className?: string }) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      className={className}
      variants={{
        hidden: reduce ? { opacity: 0 } : { opacity: 0, y: 22 },
        show: { opacity: 1, y: 0, transition: { duration: 0.75, ease: EASE } },
      }}
    >
      {children}
    </motion.div>
  );
}

/** Gentle curtain reveal for photographs entering the viewport. */
export function RevealMask({ children, className }: { children: ReactNode; className?: string }) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={reduce ? { opacity: 0 } : { clipPath: "inset(12% 6% 12% 6%)", opacity: 0.4 }}
      whileInView={{ clipPath: "inset(0% 0% 0% 0%)", opacity: 1 }}
      viewport={{ once: true, margin: "-10% 0px" }}
      transition={{ duration: 1.2, ease: EASE }}
    >
      {children}
    </motion.div>
  );
}

/** Subtle vertical parallax for landscape photographs. */
export function Parallax({ children, className, amount = 8 }: { children: ReactNode; className?: string; amount?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [`-${amount}%`, `${amount}%`]);
  return (
    <div ref={ref} className={cx("relative overflow-hidden", className)}>
      <motion.div style={reduce ? undefined : { y }} className="absolute inset-x-0 -inset-y-[12%]">
        {children}
      </motion.div>
    </div>
  );
}

/* ----------------------------------------------------------------- images */

export function Img({
  photo,
  alt,
  className,
  sizes = "100vw",
  eager,
  style,
}: {
  photo: Photo;
  alt: string;
  className?: string;
  sizes?: string;
  eager?: boolean;
  style?: CSSProperties;
}) {
  const ref = useRef<HTMLImageElement>(null);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (el && el.complete && el.naturalWidth > 0) setLoaded(true);
  }, []);
  return (
    <img
      ref={ref}
      src={srcOf(photo)}
      srcSet={srcSetOf(photo)}
      sizes={sizes}
      alt={alt}
      loading={eager ? "eager" : "lazy"}
      decoding="async"
      fetchPriority={eager ? "high" : "auto"}
      onLoad={() => setLoaded(true)}
      onError={() => setFailed(true)}
      style={{ objectPosition: photo.pos, ...style }}
      className={cx("transition-opacity duration-700", loaded && !failed ? "opacity-100" : "opacity-0", className)}
    />
  );
}

/** Small label on an image: real photo of the car, or illustration. */
export function Tag({
  kind,
  label,
  title,
  className,
}: {
  kind: "real" | "ai";
  label: string;
  title?: string;
  className?: string;
}) {
  return (
    <span
      title={title}
      className={cx(
        "eyebrow inline-flex items-center gap-1.5 bg-ivory/90 px-2.5 py-1.5 text-[0.62rem] text-navy shadow-sm backdrop-blur",
        className,
      )}
    >
      <span aria-hidden="true" className={cx("h-1.5 w-1.5 rounded-full", kind === "real" ? "bg-avail" : "bg-golddeep")} />
      {label}
    </span>
  );
}

/* ----------------------------------------------------------- section bits */

export function Eyebrow({
  children,
  on = "light",
  className,
}: {
  children: ReactNode;
  on?: "light" | "dark";
  className?: string;
}) {
  return (
    <div className={cx("flex items-center gap-3", className)}>
      <span aria-hidden="true" className={cx("h-px w-9", on === "light" ? "bg-golddeep/60" : "bg-gold/70")} />
      <span className={cx("eyebrow", on === "light" ? "text-golddeep" : "text-gold")}>{children}</span>
    </div>
  );
}

/** A small French ornament — hairlines around a diamond. */
export function Fleuron({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 120 12" className={cx("h-3 w-28", className)} aria-hidden="true" fill="none">
      <path d="M0 6h47M73 6h47" stroke="currentColor" strokeWidth="0.8" />
      <path d="M60 1l5 5-5 5-5-5 5-5Z" fill="currentColor" />
      <circle cx="51" cy="6" r="1.2" fill="currentColor" />
      <circle cx="69" cy="6" r="1.2" fill="currentColor" />
    </svg>
  );
}

export function Shell({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cx("relative mx-auto w-full max-w-[1280px] px-6 md:px-10 xl:px-16", className)}>{children}</div>
  );
}

export function Heading({
  eyebrow,
  title,
  sub,
  on = "light",
  id,
  className,
  center,
  children,
}: {
  eyebrow: string;
  title: string;
  sub?: string;
  on?: "light" | "dark";
  id?: string;
  className?: string;
  center?: boolean;
  children?: ReactNode;
}) {
  const dark = on === "dark";
  const h2 = cx(
    "display [font-size:clamp(2.5rem,5.4vw,4.4rem)]",
    dark ? "text-ivory [&_em]:text-gold" : "text-navy [&_em]:text-golddeep",
  );
  const p = cx("text-[1.06rem] leading-relaxed", dark ? "text-ivory/75" : "text-stone");
  if (center) {
    return (
      <Reveal className={cx("mx-auto max-w-3xl text-center", className)}>
        <Fleuron className={cx("mx-auto", dark ? "text-gold" : "text-golddeep")} />
        <p className={cx("eyebrow mt-5", dark ? "text-gold" : "text-golddeep")}>{eyebrow}</p>
        <h2 id={id} className={cx(h2, "mt-5")}>
          {rich(title)}
        </h2>
        {sub && <p className={cx(p, "mx-auto mt-6 max-w-[56ch]")}>{sub}</p>}
        {children}
      </Reveal>
    );
  }
  return (
    <div className={cx("grid grid-cols-12 items-end gap-y-6", className)}>
      <Reveal className="col-span-12 lg:col-span-7">
        <Eyebrow on={on}>{eyebrow}</Eyebrow>
        <h2 id={id} className={cx(h2, "mt-6")}>
          {rich(title)}
        </h2>
      </Reveal>
      {(sub || children) && (
        <Reveal delay={0.12} className="col-span-12 lg:col-span-5 lg:pl-10">
          {sub && <p className={cx(p, "max-w-[46ch] lg:mt-8")}>{sub}</p>}
          {children}
        </Reveal>
      )}
    </div>
  );
}

/** Ivory passe-partout frame with an italic caption. */
export function Frame({ children, caption, className }: { children: ReactNode; caption?: string; className?: string }) {
  return (
    <figure
      className={cx(
        "bg-[#fffdf8] p-2.5 shadow-[0_40px_80px_-50px_rgba(11,18,34,0.55)] ring-1 ring-gold/30 sm:p-3",
        className,
      )}
    >
      <div className="relative overflow-hidden">{children}</div>
      {caption && (
        <figcaption className="px-1 pb-1 pt-3 font-display text-[1.02rem] italic text-stone">— {caption}</figcaption>
      )}
    </figure>
  );
}

/* ------------------------------------------------------------------ forms */

export const inputCls =
  "mt-2 w-full border border-rule bg-ivory px-4 py-3.5 text-[0.98rem] text-navy placeholder:text-stone/60 transition-colors duration-300 hover:border-navy/40 focus:border-golddeep focus:outline-none";

export function Field({
  label,
  children,
  className,
  hint,
}: {
  label: string;
  children: ReactNode;
  className?: string;
  hint?: string;
}) {
  return (
    <label className={cx("block", className)}>
      <span className="eyebrow text-stone">{label}</span>
      {children}
      {hint && <span className="mt-1.5 block text-[0.78rem] leading-snug text-stone">{hint}</span>}
    </label>
  );
}

export function Stepper({
  label,
  value,
  min,
  max,
  onChange,
  decLabel,
  incLabel,
  hint,
  warn,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (n: number) => void;
  decLabel: string;
  incLabel: string;
  hint?: string;
  warn?: boolean;
}) {
  const id = `st-${label.replace(/\W+/g, "-").toLowerCase()}`;
  const b =
    "flex h-[3.05rem] w-12 items-center justify-center text-navy transition-colors duration-300 hover:bg-cream disabled:pointer-events-none disabled:opacity-30";
  return (
    <div role="group" aria-labelledby={id}>
      <span id={id} className="eyebrow text-stone">
        {label}
      </span>
      <div
        className={cx(
          "mt-2 flex items-center justify-between border bg-ivory transition-colors duration-300",
          warn ? "border-red" : "border-rule",
        )}
      >
        <button
          type="button"
          onClick={() => onChange(Math.max(min, value - 1))}
          disabled={value <= min}
          aria-label={`${decLabel}: ${label}`}
          className={b}
        >
          <Minus size={16} aria-hidden="true" />
        </button>
        <output aria-live="polite" className="num font-display text-[1.6rem] leading-none text-navy">
          {value}
        </output>
        <button
          type="button"
          onClick={() => onChange(Math.min(max, value + 1))}
          disabled={value >= max}
          aria-label={`${incLabel}: ${label}`}
          className={b}
        >
          <Plus size={16} aria-hidden="true" />
        </button>
      </div>
      {hint && <p className={cx("mt-2 text-[0.8rem] leading-snug", warn ? "text-red" : "text-stone")}>{hint}</p>}
    </div>
  );
}

/* ------------------------------------------------------------ brand bits */

export function WhatsAppIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z" />
    </svg>
  );
}

export function Mark({ className = "h-9 w-9" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} role="img" aria-label="Bonjour Paris Ride" fill="none">
      <path d="M4 41C4 21.4 13 5 24 5s20 16.4 20 36" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
      <path
        d="M13.6 37.6v-4.1c0-2.2 1.4-4.2 3.5-4.9l3.6-1.3c1.6-.5 3.3-.5 4.9 0l3.6 1.3c2.2.7 3.5 2.7 3.5 4.9v4.1H13.6Z"
        fill="currentColor"
      />
      <circle cx="17.6" cy="38.4" r="2.7" fill="currentColor" />
      <circle cx="30.4" cy="38.4" r="2.7" fill="currentColor" />
      <path d="M2.5 41.4h43" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
      <path d="M24 5v6.5" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
    </svg>
  );
}

export function Wordmark({ className, on = "light" }: { className?: string; on?: "light" | "dark" }) {
  return (
    <span className={cx("flex items-baseline gap-2 leading-none", on === "light" ? "text-navy" : "text-ivory", className)}>
      <span className="font-display text-[1.55rem] font-semibold tracking-[-0.01em]">Bonjour Paris</span>
      <span className={cx("eyebrow", on === "light" ? "text-red" : "text-redsoft")}>Ride</span>
    </span>
  );
}
