import { useEffect, useState, type FormEvent } from "react";
import { ArrowRight, Check } from "lucide-react";
import { CAPACITY, MULTI_TOURS, PLACES, type PlaceId } from "../config";
import { useI18n } from "../i18n";
import { daysBetween, todayISO } from "../lib/availability";
import type { Req } from "../lib/store";
import { buildMessage, newRef, submitRequest } from "../lib/submit";
import { photo } from "../photos";
import { RequestDone, usePlanner } from "./Planner";
import { Eyebrow, Field, Img, Reveal, RevealMask, Shell, Stepper, cx, inputCls, rich } from "./ui";

type TourKey = "a" | "b" | "c";
const asTour = (v?: string): TourKey | undefined => (v === "a" || v === "b" || v === "c" ? v : undefined);

const EMPTY = {
  date: "",
  arrival: "",
  departure: "",
  adults: 2,
  children: 0,
  ages: "",
  hotel: "",
  places: [] as PlaceId[],
  other: "",
  pickup: "",
  large: 2,
  cabin: 2,
  requests: "",
  name: "",
  email: "",
  phone: "",
};

/** Multi-day and custom itinerary quotation form — never shows invented prices. */
export function QuoteForm({ variant, tour }: { variant: "multi" | "custom"; tour?: string }) {
  const { t, lang, date: fmtDate, price } = useI18n();
  const planner = usePlanner();
  const multi = variant === "multi";
  const [f, setF] = useState(EMPTY);
  const [err, setErr] = useState("");
  const [sending, setSending] = useState(false);
  const [result, setResult] = useState<{ req: Req; message: string; delivered: boolean } | null>(null);
  const set = (p: Partial<typeof EMPTY>) => setF((x) => ({ ...x, ...p }));
  const tourKey = asTour(tour);

  // values carried over from the planner modal (date + passengers)
  useEffect(() => {
    const s = planner.seed;
    if (!s || s.target !== (multi ? "multiday" : "custom")) return;
    setF((x) => ({
      ...x,
      ...(multi ? { arrival: s.date ?? x.arrival } : { date: s.date ?? x.date }),
      adults: s.pax ?? x.adults,
    }));
    planner.setSeed(null);
  }, [planner, multi]);

  // preselect places of the chosen itinerary idea
  useEffect(() => {
    const m = MULTI_TOURS.find((x) => x.id === tourKey);
    if (m) setF((x) => ({ ...x, places: m.places }));
  }, [tourKey]);

  const today = todayISO();
  const days = multi && f.arrival && f.departure && f.departure >= f.arrival ? daysBetween(f.arrival, f.departure) + 1 : null;
  const pax = f.adults + f.children;
  const toggle = (p: PlaceId) =>
    set({ places: f.places.includes(p) ? f.places.filter((x) => x !== p) : [...f.places, p] });

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const start = multi ? f.arrival : f.date;
    if ((start && start < today) || (multi && f.departure && f.departure < today)) {
      setErr(`${t.cal.past} — ${t.cal.instruction}`);
      return;
    }
    if (multi && f.arrival && f.departure && f.departure < f.arrival) {
      setErr(t.quote.errDates);
      return;
    }
    if (!f.email.trim() && !f.phone.trim()) {
      setErr(t.plan.errContact);
      return;
    }
    setErr("");
    setSending(true);
    const tourName = tourKey ? t.multi.tours[tourKey].t : "";
    const req: Req = {
      id: newRef(),
      createdAt: new Date().toISOString(),
      status: "pending",
      kind: "quote",
      source: "website",
      service: multi ? "multiday" : "custom",
      date: (multi ? f.arrival : f.date) || "",
      endDate: multi ? f.departure || undefined : undefined,
      days: days ?? undefined,
      pax,
      adults: f.adults,
      children: f.children || undefined,
      childAges: f.children ? f.ages.trim() || undefined : undefined,
      hotel: f.hotel.trim() || undefined,
      destinations: [...f.places.map((p) => t.places[p]), ...(f.other.trim() ? [f.other.trim()] : [])],
      pickup: f.pickup.trim() || undefined,
      bags: f.large,
      cabin: f.cabin,
      notes: [tourName ? t.multi.based(tourName) : "", f.requests.trim()].filter(Boolean).join(" — ") || undefined,
      price: null,
      name: f.name.trim() || undefined,
      email: f.email.trim() || undefined,
      phone: f.phone.trim() || undefined,
      lang,
    };
    const message = buildMessage(req, t, { date: fmtDate, price });
    const { delivered } = await submitRequest(req, message);
    setSending(false);
    setResult({ req, message, delivered });
  };

  if (result) {
    return (
      <RequestDone
        req={result.req}
        message={result.message}
        delivered={result.delivered}
        onAgain={() => {
          setResult(null);
          setF(EMPTY);
        }}
      />
    );
  }

  return (
    <form onSubmit={submit} noValidate className="grid grid-cols-1 gap-x-5 gap-y-6 sm:grid-cols-2">
      {multi ? (
        <>
          <Field label={t.quote.arrival}>
            <input type="date" min={today} value={f.arrival} onChange={(e) => set({ arrival: e.target.value })} className={inputCls} />
          </Field>
          <Field label={t.quote.departure}>
            <input
              type="date"
              min={f.arrival || today}
              value={f.departure}
              onChange={(e) => set({ departure: e.target.value })}
              className={inputCls}
            />
          </Field>
          {days !== null && (
            <p className="-mt-2 text-[0.92rem] text-ink sm:col-span-2" aria-live="polite">
              <span className="eyebrow text-stone">{t.quote.days} · </span>
              {t.multi.days(days)}
            </p>
          )}
        </>
      ) : (
        <Field label={t.quote.date} className="sm:col-span-2">
          <input type="date" min={today} value={f.date} onChange={(e) => set({ date: e.target.value })} className={inputCls} />
        </Field>
      )}

      <Stepper
        label={t.quote.adults}
        value={f.adults}
        min={1}
        max={10}
        onChange={(n) => set({ adults: n })}
        decLabel={t.common.decrease}
        incLabel={t.common.increase}
      />
      <Stepper
        label={t.quote.children}
        value={f.children}
        min={0}
        max={8}
        onChange={(n) => set({ children: n })}
        decLabel={t.common.decrease}
        incLabel={t.common.increase}
      />
      {f.children > 0 && (
        <Field label={t.quote.ages} className="sm:col-span-2">
          <input value={f.ages} onChange={(e) => set({ ages: e.target.value })} placeholder={t.quote.agesPh} className={inputCls} />
        </Field>
      )}
      {pax > CAPACITY.maxPassengers && (
        <p role="alert" className="border-l-2 border-limited bg-limited/10 px-4 py-3 text-[0.9rem] text-ink sm:col-span-2">
          {t.quote.paxWarn}
        </p>
      )}

      <Field label={t.quote.hotel} className="sm:col-span-2">
        <input value={f.hotel} onChange={(e) => set({ hotel: e.target.value })} placeholder={t.quote.hotelPh} className={inputCls} />
      </Field>

      <fieldset className="sm:col-span-2">
        <legend className="eyebrow text-stone">{t.quote.dest}</legend>
        <div className="mt-3 flex flex-wrap gap-2">
          {PLACES.map((p) => {
            const on = f.places.includes(p);
            return (
              <button
                key={p}
                type="button"
                aria-pressed={on}
                onClick={() => toggle(p)}
                className={cx(
                  "inline-flex items-center gap-1.5 border px-3.5 py-2 text-[0.88rem] transition-all duration-300",
                  on ? "border-ink bg-ink text-paper" : "border-rule bg-paper text-ink hover:border-ink/50",
                )}
              >
                {on && <Check size={12} aria-hidden="true" />}
                {t.places[p]}
              </button>
            );
          })}
        </div>
        <input
          value={f.other}
          onChange={(e) => set({ other: e.target.value })}
          placeholder={`${t.quote.other}…`}
          aria-label={`${t.quote.dest} — ${t.quote.other}`}
          className={inputCls}
        />
      </fieldset>

      {multi && (
        <Field label={t.quote.pickup} className="sm:col-span-2">
          <input value={f.pickup} onChange={(e) => set({ pickup: e.target.value })} placeholder={t.quote.pickupPh} className={inputCls} />
        </Field>
      )}

      <Stepper
        label={t.quote.large}
        value={f.large}
        min={0}
        max={10}
        onChange={(n) => set({ large: n })}
        decLabel={t.common.decrease}
        incLabel={t.common.increase}
      />
      <Stepper
        label={t.quote.cabin}
        value={f.cabin}
        min={0}
        max={10}
        onChange={(n) => set({ cabin: n })}
        decLabel={t.common.decrease}
        incLabel={t.common.increase}
      />
      {(f.large > CAPACITY.largeSuitcases || f.cabin > CAPACITY.cabinBags) && (
        <p role="status" className="border-l-2 border-limited bg-limited/10 px-4 py-3 text-[0.9rem] text-navy sm:col-span-2">
          {t.plan.bagsWarn(CAPACITY.largeSuitcases)}
        </p>
      )}

      <Field label={multi ? t.quote.requests : t.quote.ideas} className="sm:col-span-2">
        <textarea
          rows={4}
          value={f.requests}
          onChange={(e) => set({ requests: e.target.value })}
          placeholder={multi ? t.quote.requestsPh : t.quote.ideasPh}
          className={cx(inputCls, "resize-y")}
        />
      </Field>

      <Field label={t.plan.name}>
        <input value={f.name} onChange={(e) => set({ name: e.target.value })} autoComplete="name" className={inputCls} />
      </Field>
      <Field label={t.plan.email}>
        <input type="email" value={f.email} onChange={(e) => set({ email: e.target.value })} autoComplete="email" className={inputCls} />
      </Field>
      <Field label={t.plan.phone} hint={t.plan.contactHint} className="sm:col-span-2">
        <input type="tel" value={f.phone} onChange={(e) => set({ phone: e.target.value })} autoComplete="tel" className={inputCls} />
      </Field>

      {err && (
        <p role="alert" className="text-[0.92rem] text-rouge sm:col-span-2">
          {err}
        </p>
      )}

      <div className="flex flex-col gap-5 border-t border-rule pt-6 sm:col-span-2 sm:flex-row sm:items-center sm:justify-between">
        <p className="max-w-[46ch] text-[0.84rem] leading-snug text-stone">
          {t.quote.noPrice} {t.plan.privacy}
        </p>
        <button
          type="submit"
          disabled={sending}
          className="group inline-flex shrink-0 items-center justify-center gap-3 bg-rouge px-7 py-4 text-paper shadow-[0_14px_30px_-16px_rgba(200,85,43,0.9)] transition-all duration-500 hover:-translate-y-0.5 hover:bg-ink disabled:pointer-events-none disabled:opacity-50"
        >
          <span className="eyebrow">{sending ? t.plan.sending : multi ? t.quote.submitMulti : t.quote.submitCustom}</span>
          <ArrowRight size={15} className="transition-transform duration-500 group-hover:translate-x-1" aria-hidden="true" />
        </button>
      </div>
    </form>
  );
}

/** Home page section 12: custom itinerary & quotation. */
export function CustomQuote() {
  const { t } = useI18n();
  const img = photo("bistro");
  return (
    <section id="quote" aria-labelledby="quote-title" className="relative bg-paper py-24 md:py-32">
      <Shell>
        <div className="grid grid-cols-12 gap-y-12 lg:gap-x-16">
          <div className="col-span-12 lg:col-span-5">
            <Reveal>
              <Eyebrow>{t.quote.eyebrow}</Eyebrow>
              <h2 id="quote-title" className="display mt-6 text-ink [font-size:clamp(2.4rem,5vw,4rem)] [&_em]:text-rouge">
                {rich(t.quote.title)}
              </h2>
              <p className="mt-6 max-w-[42ch] text-[1.0625rem] leading-relaxed text-stone">{t.quote.sub}</p>
            </Reveal>
            <Reveal delay={0.1}>
              <RevealMask className="mt-10 hidden aspect-[4/5] overflow-hidden bg-inkdeep lg:block">
                <Img photo={img} alt={t.photos.bistro} sizes="35vw" className="h-full w-full object-cover" />
              </RevealMask>
            </Reveal>
          </div>
          <Reveal delay={0.1} className="col-span-12 lg:col-span-7">
            <div className="border border-rule bg-[#fffdf9] p-6 shadow-[0_50px_100px_-70px_rgba(11,13,34,0.6)] md:p-10">
              <QuoteForm variant="custom" />
            </div>
          </Reveal>
        </div>
      </Shell>
    </section>
  );
}
