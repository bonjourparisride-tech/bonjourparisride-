import { motion, useReducedMotion } from "framer-motion";
import type { ReactNode } from "react";
import { useI18n } from "../i18n";
import { MENU, hrefOf, type Page } from "../lib/router";
import { photo } from "../photos";
import { Arrow, EASE, Eyebrow, Fleuron, Frame, Img, Parallax, Shell, cx, rich } from "./ui";

/* Shared page furniture: each page picks a different hero layout so pages
   feel related but never duplicated. */

export type HeroVariant = "full" | "split" | "framed" | "mosaic" | "band";

export function Crumbs({ page, on }: { page: Page; on: "light" | "dark" }) {
  const { s } = useI18n();
  const key = MENU.find((m) => m.page === page)?.key;
  const dark = on === "dark";
  return (
    <nav aria-label="Breadcrumb" className={cx("eyebrow flex items-center gap-2", dark ? "text-ivory/60" : "text-stone")}>
      <a href="#/" className={cx("transition-colors", dark ? "hover:text-ivory" : "hover:text-navy")}>
        {s.nav.home}
      </a>
      <span aria-hidden="true" className={dark ? "text-gold" : "text-golddeep"}>
        ◆
      </span>
      <span aria-current="page" className={dark ? "text-ivory" : "text-navy"}>
        {key ? s.nav[key] : ""}
      </span>
    </nav>
  );
}

export function PageHero({
  page,
  variant,
  eyebrow,
  title,
  sub,
  photos,
  children,
}: {
  page: Page;
  variant: HeroVariant;
  eyebrow: string;
  title: string;
  sub?: string;
  photos: string[];
  children?: ReactNode;
}) {
  const { cap } = useI18n();
  const reduce = useReducedMotion();
  const p = photos.map(photo);
  const enter = (d = 0) => ({
    initial: reduce ? { opacity: 0 } : { opacity: 0, y: 24 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.9, delay: d, ease: EASE },
  });
  const h1Dark = "display mt-6 text-ivory [&_em]:text-gold";
  const h1Light = "display mt-6 text-navy [&_em]:text-golddeep";

  const text = (on: "light" | "dark", size: string, maxW = "max-w-[15ch]") => (
    <>
      <motion.div {...enter(0.1)}>
        <Crumbs page={page} on={on} />
      </motion.div>
      <motion.div {...enter(0.2)}>
        <Eyebrow on={on} className="mt-8">
          {eyebrow}
        </Eyebrow>
      </motion.div>
      <motion.h1 {...enter(0.3)} className={cx(on === "dark" ? h1Dark : h1Light, maxW, size)}>
        {rich(title)}
      </motion.h1>
      {sub && (
        <motion.p
          {...enter(0.45)}
          className={cx(
            "mt-6 max-w-[56ch] text-[1.06rem] leading-relaxed md:text-[1.14rem]",
            on === "dark" ? "text-ivory/85" : "text-stone",
          )}
        >
          {sub}
        </motion.p>
      )}
      {children && (
        <motion.div {...enter(0.6)} className="mt-9 flex flex-wrap items-center gap-3">
          {children}
        </motion.div>
      )}
    </>
  );

  if (variant === "full") {
    return (
      <section className="relative isolate flex min-h-[84svh] items-end overflow-hidden bg-night pb-14 pt-40 text-ivory md:pb-20">
        <Parallax className="absolute inset-0 -z-20" amount={6}>
          <Img photo={p[0]} alt="" eager sizes="100vw" className="h-full w-full object-cover" />
        </Parallax>
        <div
          aria-hidden="true"
          className="absolute inset-0 -z-10 bg-[linear-gradient(180deg,rgba(11,18,34,0.62)_0%,rgba(11,18,34,0.12)_38%,rgba(11,18,34,0.9)_100%)]"
        />
        <Shell className="w-full">
          {text("dark", "[font-size:clamp(3rem,7.4vw,6.2rem)]")}
          <p className="mt-12 flex items-center gap-3 font-display text-[1rem] italic text-ivory/70">
            <span aria-hidden="true" className="h-px w-8 bg-gold/60" />
            {cap(p[0].key)}
          </p>
        </Shell>
      </section>
    );
  }

  if (variant === "band") {
    return (
      <section className="relative isolate overflow-hidden bg-night pb-14 pt-36 text-ivory md:pb-20 md:pt-44">
        <div className="absolute inset-y-0 right-0 -z-20 w-full md:w-[62%]">
          <Img
            photo={p[0]}
            alt=""
            eager
            sizes="(min-width:768px) 62vw, 100vw"
            className="h-full w-full object-cover opacity-55 md:opacity-90"
          />
          <div className="absolute inset-0 bg-[linear-gradient(90deg,#0b1222_0%,rgba(11,18,34,0.72)_35%,rgba(11,18,34,0.12)_100%)]" />
        </div>
        <div aria-hidden="true" className="absolute inset-0 -z-10 bg-[linear-gradient(0deg,rgba(11,18,34,0.8),transparent_55%)]" />
        <Shell>{text("dark", "[font-size:clamp(2.8rem,6.4vw,5.2rem)]", "max-w-[14ch]")}</Shell>
      </section>
    );
  }

  if (variant === "split") {
    return (
      <section className="relative overflow-hidden bg-ivory pb-16 pt-32 md:pb-24 md:pt-40">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-48 top-16 h-[560px] w-[560px] rounded-full border border-gold/30"
        />
        <Shell>
          <div className="grid grid-cols-12 items-center gap-y-12 lg:gap-x-14">
            <div className="col-span-12 lg:col-span-7">{text("light", "[font-size:clamp(2.9rem,6.4vw,5.6rem)]")}</div>
            <div className="col-span-12 sm:col-span-8 sm:col-start-3 lg:col-span-5 lg:col-start-8">
              <motion.div
                initial={reduce ? { opacity: 0 } : { opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1.2, ease: EASE, delay: 0.2 }}
                className="arch relative aspect-[4/5] overflow-hidden bg-cream shadow-[0_50px_90px_-60px_rgba(11,18,34,0.8)]"
              >
                <Img photo={p[0]} alt={cap(p[0].key)} eager sizes="(min-width:1024px) 38vw, 80vw" className="h-full w-full object-cover" />
              </motion.div>
              <p className="mt-4 text-center font-display text-[1rem] italic text-stone">— {cap(p[0].key)}</p>
            </div>
          </div>
        </Shell>
      </section>
    );
  }

  if (variant === "framed") {
    return (
      <section className="relative overflow-hidden bg-cream pb-20 pt-32 md:pb-28 md:pt-40">
        <Shell>
          <div className="grid grid-cols-12 items-center gap-y-14 lg:gap-x-12">
            <div className="col-span-12 lg:col-span-6">{text("light", "[font-size:clamp(2.9rem,6vw,5.2rem)]")}</div>
            <div className="relative col-span-12 lg:col-span-6">
              <motion.div {...enter(0.25)} className="rotate-[-1.2deg]">
                <Frame caption={cap(p[0].key)}>
                  <div className="aspect-[4/3]">
                    <Img photo={p[0]} alt={cap(p[0].key)} eager sizes="(min-width:1024px) 45vw, 100vw" className="h-full w-full object-cover" />
                  </div>
                </Frame>
              </motion.div>
              {p[1] && (
                <motion.div {...enter(0.5)} className="absolute -bottom-12 -left-6 hidden w-[36%] rotate-[3deg] md:block">
                  <Frame>
                    <div className="aspect-[4/5]">
                      <Img photo={p[1]} alt={cap(p[1].key)} sizes="16vw" className="h-full w-full object-cover" />
                    </div>
                  </Frame>
                </motion.div>
              )}
            </div>
          </div>
        </Shell>
      </section>
    );
  }

  // mosaic
  return (
    <section className="relative overflow-hidden bg-ivory pb-16 pt-32 md:pb-20 md:pt-40">
      <Shell>
        <div className="mx-auto max-w-3xl text-center">
          <motion.div {...enter(0.1)} className="flex justify-center">
            <Crumbs page={page} on="light" />
          </motion.div>
          <Fleuron className="mx-auto mt-8 text-golddeep" />
          <motion.p {...enter(0.2)} className="eyebrow mt-5 text-golddeep">
            {eyebrow}
          </motion.p>
          <motion.h1 {...enter(0.3)} className={cx(h1Light, "mx-auto [font-size:clamp(3rem,7vw,5.8rem)]")}>
            {rich(title)}
          </motion.h1>
          {sub && (
            <motion.p {...enter(0.45)} className="mx-auto mt-6 max-w-[56ch] text-[1.06rem] leading-relaxed text-stone">
              {sub}
            </motion.p>
          )}
          {children && (
            <motion.div {...enter(0.6)} className="mt-9 flex flex-wrap justify-center gap-3">
              {children}
            </motion.div>
          )}
        </div>
        <div className="mt-14 grid grid-cols-12 items-end gap-3 md:mt-20 md:gap-5">
          {[0, 1, 2].map((i) =>
            p[i] ? (
              <motion.div
                key={i}
                {...enter(0.3 + i * 0.12)}
                className={cx(
                  "relative overflow-hidden bg-cream",
                  i === 0 && "arch col-span-4 aspect-[3/4] md:col-span-3",
                  i === 1 && "col-span-8 aspect-[4/3] md:col-span-6 md:aspect-[16/10]",
                  i === 2 && "arch hidden aspect-[3/4] md:col-span-3 md:block",
                )}
              >
                <Img photo={p[i]} alt={cap(p[i].key)} eager sizes="(min-width:768px) 40vw, 60vw" className="h-full w-full object-cover" />
              </motion.div>
            ) : null,
          )}
        </div>
      </Shell>
    </section>
  );
}

/** Magazine-style "next article" link that ties the pages together. */
export function NextPage({ current }: { current: Page }) {
  const { s, cap } = useI18n();
  const cycle = MENU.filter((m) => m.page !== "home");
  const idx = cycle.findIndex((m) => m.page === current);
  const next = cycle[(idx + 1) % cycle.length];
  const p = photo(next.photo);
  return (
    <section aria-label={s.common.next} className="bg-ivory pb-16 pt-10 md:pb-24">
      <Shell>
        <a href={hrefOf(next.page)} className="group relative block overflow-hidden bg-night text-ivory">
          <div className="relative h-[40vh] min-h-[260px] md:h-[50vh]">
            <Img
              photo={p}
              alt=""
              sizes="100vw"
              className="h-full w-full object-cover opacity-80 transition-transform duration-[1600ms] ease-out group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(11,18,34,0.92),rgba(11,18,34,0.2))]" />
          </div>
          <div className="absolute inset-0 flex flex-col justify-end p-7 md:p-12">
            <span className="eyebrow text-gold">{s.common.next}</span>
            <span className="display mt-3 flex items-baseline gap-4 [font-size:clamp(2.4rem,6vw,4.8rem)]">
              {s.nav[next.key]}
              <Arrow className="text-gold" />
            </span>
            <span className="mt-3 font-display text-[1rem] italic text-ivory/70">— {cap(p.key)}</span>
          </div>
        </a>
      </Shell>
    </section>
  );
}
