import { AnimatePresence, motion, useMotionValue, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { useEffect, useMemo, useRef, useState } from "react";
import { Baby, Briefcase, CalendarDays, Luggage, Pause, Play, Users } from "lucide-react";
import { CAPACITY, SERVICES, fromPrice, waLink, type ServiceId } from "../config";
import { useI18n } from "../i18n";
import { hrefOf, navigate, type Page } from "../lib/router";
import { usePublicContent } from "../lib/store";
import { HERO_SLIDES, REEL, photo, srcOf, srcSetOf, type ReelTarget } from "../photos";
import { CarImage } from "./Car";
import { usePlanner } from "./Planner";
import { ReviewCard, StoriesInvite } from "./Stories";
import {
  Arrow,
  EASE,
  Eyebrow,
  Heading,
  Img,
  Item,
  Parallax,
  Reveal,
  Shell,
  Stagger,
  WhatsAppIcon,
  btn,
  cx,
  rich,
  useMedia,
} from "./ui";

/* Home — a short, curated overview. Every topic has its own page;
   here each block simply opens the door to it. */

const SLIDE_MS = 7000;
const ROMAN = ["I", "II", "III", "IV", "V", "VI"];

function QuickBar({ on }: { on: "dark" | "light" }) {
  const { t, date } = useI18n();
  const planner = usePlanner();
  const [service, setService] = useState<ServiceId>("airport");
  const [pax, setPax] = useState(2);
  const go = () => planner.open({ service, pax });
  const dark = on === "dark";
  const cell = cx("flex flex-col gap-1.5 px-5 py-4", dark ? "border-white/15" : "border-rule");
  const label = cx("eyebrow", dark ? "text-ivory/60" : "text-stone");
  const value = cx(
    "w-full cursor-pointer bg-transparent font-display text-[1.2rem] focus:outline-none",
    dark ? "text-ivory" : "text-navy",
  );
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        go();
      }}
      aria-label={t.quick.label}
      className={cx(
        "grid grid-cols-2 md:grid-cols-[1.35fr_1.1fr_0.8fr_auto]",
        dark
          ? "border border-white/25 bg-night/45 backdrop-blur-xl"
          : "bg-ivory shadow-[0_40px_90px_-40px_rgba(11,18,34,0.55)] ring-1 ring-rule",
      )}
    >
      <label className={cx(cell, "col-span-2 border-b md:col-span-1 md:border-b-0 md:border-r")}>
        <span className={label}>{t.quick.service}</span>
        <select value={service} onChange={(e) => setService(e.target.value as ServiceId)} className={value}>
          {SERVICES.map((sv) => (
            <option key={sv} value={sv}>
              {t.services[sv]}
            </option>
          ))}
        </select>
      </label>
      <button
        type="button"
        onClick={go}
        className={cx(cell, "items-start border-b border-r text-left transition-colors md:border-b-0", dark ? "hover:bg-white/5" : "hover:bg-cream")}
      >
        <span className={label}>{t.quick.date}</span>
        <span className={cx("flex items-center gap-2 font-display text-[1.2rem]", dark ? "text-ivory" : "text-navy")}>
          <CalendarDays size={16} className={dark ? "text-gold" : "text-golddeep"} aria-hidden="true" />
          {planner.draft.date ? date(planner.draft.date, "short") : t.quick.choose}
        </span>
      </button>
      <label className={cx(cell, "border-b md:border-b-0 md:border-r")}>
        <span className={label}>{t.common.passengers}</span>
        <select value={pax} onChange={(e) => setPax(Number(e.target.value))} className={value}>
          {Array.from({ length: CAPACITY.maxPassengers }, (_, n) => n + 1).map((n) => (
            <option key={n} value={n}>
              {n}
            </option>
          ))}
        </select>
      </label>
      <button
        type="submit"
        className="group col-span-2 flex items-center justify-center gap-3 bg-golddeep px-8 py-5 text-ivory transition-colors duration-500 hover:bg-navy md:col-span-1"
      >
        <span className="eyebrow">{t.quick.submit}</span>
        <Arrow />
      </button>
    </form>
  );
}

function HomeHero() {
  const { t, price, cap } = useI18n();
  const planner = usePlanner();
  const reduce = useReducedMotion();
  const slides = useMemo(() => HERO_SLIDES.map(photo), []);
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const ref = useRef<HTMLElement>(null);

  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const yImg = useTransform(scrollYProgress, [0, 1], ["0%", "14%"]);
  const yText = useTransform(scrollYProgress, [0, 1], ["0%", "18%"]);
  const fade = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  useEffect(() => {
    if (reduce || paused) return;
    const id = window.setTimeout(() => setI((v) => (v + 1) % slides.length), SLIDE_MS);
    return () => window.clearTimeout(id);
  }, [i, reduce, paused, slides.length]);

  // warm the next slide so the cross-fade never shows a blank frame
  useEffect(() => {
    const next = slides[(i + 1) % slides.length];
    const img = new Image();
    img.sizes = "100vw";
    const set = srcSetOf(next);
    if (set) img.srcset = set;
    img.src = srcOf(next);
  }, [i, slides]);

  const cur = slides[i];
  const enter = (d: number) => ({
    initial: reduce ? { opacity: 0 } : { opacity: 0, y: 22 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 1, delay: d, ease: EASE },
  });

  return (
    <>
      <section ref={ref} aria-labelledby="hero-title" className="relative isolate flex min-h-[100svh] flex-col overflow-hidden bg-night text-ivory">
        <motion.div style={reduce ? undefined : { y: yImg }} className="absolute inset-0 -z-20">
          <AnimatePresence initial={false}>
            <motion.div
              key={cur.id}
              className="absolute inset-0"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.8, ease: "easeInOut" }}
            >
              <motion.div
                className="h-full w-full"
                initial={{ scale: reduce ? 1.02 : 1.12 }}
                animate={{ scale: 1.02 }}
                transition={{ duration: reduce ? 0 : 9, ease: "linear" }}
              >
                <Img photo={cur} alt={cap(cur.key)} eager={i === 0} sizes="100vw" className="h-full w-full object-cover" />
              </motion.div>
            </motion.div>
          </AnimatePresence>
        </motion.div>
        <div
          aria-hidden="true"
          className="absolute inset-0 -z-10 bg-[linear-gradient(180deg,rgba(11,18,34,0.66)_0%,rgba(11,18,34,0.1)_30%,rgba(11,18,34,0.35)_62%,rgba(11,18,34,0.92)_100%)]"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 -z-10 bg-[linear-gradient(90deg,rgba(11,18,34,0.7)_0%,rgba(11,18,34,0.2)_55%,transparent_100%)]"
        />
        <p aria-hidden="true" className="eyebrow absolute right-6 top-1/2 hidden -translate-y-1/2 text-ivory/50 [writing-mode:vertical-rl] xl:block">
          48°51′24″ N · 2°21′07″ E
        </p>

        <motion.div
          style={reduce ? undefined : { y: yText, opacity: fade }}
          className="mx-auto flex w-full max-w-[1280px] flex-1 flex-col justify-end px-6 pb-10 pt-36 md:px-10 lg:pb-32 xl:px-16"
        >
          <motion.div {...enter(0.15)}>
            <Eyebrow on="dark">{t.hero.eyebrow}</Eyebrow>
          </motion.div>
          <h1 id="hero-title" className="display mt-6 [font-size:clamp(3.2rem,9vw,7.6rem)] [&_em]:text-gold">
            {[t.hero.title1, t.hero.title2].map((line, idx) => (
              <span key={idx} className="-mb-[0.08em] block overflow-hidden pb-[0.12em]">
                <motion.span
                  className="block"
                  initial={reduce ? { opacity: 0 } : { y: "110%" }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ duration: 1.15, delay: 0.25 + idx * 0.15, ease: EASE }}
                >
                  {idx === 1 ? <em>{line}</em> : line}
                </motion.span>
              </span>
            ))}
          </h1>
          <motion.p {...enter(0.6)} className="mt-6 max-w-[50ch] text-[1.06rem] leading-relaxed text-ivory/88 md:text-[1.22rem]">
            {t.hero.sub}
          </motion.p>
          <motion.div {...enter(0.75)} className="mt-9 flex flex-wrap items-center gap-3">
            <button type="button" onClick={() => planner.open({ service: "airport" })} className={btn.ivory}>
              <span className="eyebrow">{t.hero.ctaTransfer}</span>
              <Arrow />
            </button>
            <a href={hrefOf("tours")} className={btn.light}>
              <span className="eyebrow">{t.hero.ctaTours}</span>
            </a>
            <button type="button" onClick={() => planner.open()} className="group inline-flex items-center gap-2 px-3 py-4 text-ivory">
              <span className="eyebrow border-b border-gold/60 pb-1 transition-colors group-hover:border-ivory">{t.hero.ctaPlan}</span>
              <Arrow className="text-gold" />
            </button>
          </motion.div>
          <motion.div {...enter(0.9)} className="mt-9 lg:hidden">
            <QuickBar on="dark" />
          </motion.div>
          <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
            <p className="eyebrow num text-ivory/75">{t.quick.note(price(fromPrice("airport")))}</p>
            <div className="flex items-center gap-3">
              <span className="hidden max-w-[34ch] truncate font-display text-[0.98rem] italic text-ivory/75 md:inline">— {cap(cur.key)}</span>
              <div className="flex">
                {slides.map((sl, idx) => (
                  <button
                    key={sl.id}
                    type="button"
                    onClick={() => setI(idx)}
                    aria-label={t.hero.slide(idx + 1)}
                    aria-current={idx === i}
                    className="group px-1 py-3"
                  >
                    <span className="relative block h-[2px] w-9 overflow-hidden bg-ivory/25 transition-colors group-hover:bg-ivory/45">
                      {idx === i && (
                        <span
                          key={`${i}-${paused}`}
                          className={cx("absolute inset-0 bg-gold", !reduce && !paused && "slide-progress")}
                          style={{ animationDuration: `${SLIDE_MS}ms` }}
                        />
                      )}
                    </span>
                  </button>
                ))}
              </div>
              <button
                type="button"
                onClick={() => setPaused((p) => !p)}
                aria-label={paused ? t.hero.play : t.hero.pause}
                className="flex h-8 w-8 items-center justify-center rounded-full border border-ivory/30 text-ivory/80 transition-colors hover:bg-ivory/10"
              >
                {paused ? <Play size={12} aria-hidden="true" /> : <Pause size={12} aria-hidden="true" />}
              </button>
            </div>
          </div>
        </motion.div>
      </section>
      <div className="relative z-20 hidden lg:block">
        <Shell>
          <div className="-mt-[54px]">
            <QuickBar on="light" />
          </div>
        </Shell>
      </div>
    </>
  );
}

function Manifesto() {
  const { t, s } = useI18n();
  return (
    <section aria-labelledby="manifesto-title" className="relative bg-ivory pb-24 pt-28 md:pb-32 md:pt-40">
      <Shell>
        <Heading center id="manifesto-title" eyebrow={t.trust.eyebrow} title={t.trust.title} sub={t.trust.sub} />
        <Stagger className="mt-16 grid grid-cols-1 gap-x-14 gap-y-12 sm:grid-cols-2 md:mt-20 lg:grid-cols-3">
          {t.trust.items.map((it, i) => (
            <Item key={it.t} className="border-t border-rule pt-6">
              <span className="font-display text-[1.7rem] italic leading-none text-golddeep">{ROMAN[i]}.</span>
              <h3 className="mt-3 font-display text-[1.6rem] leading-tight text-navy">{it.t}</h3>
              <p className="mt-2.5 text-[0.98rem] leading-relaxed text-stone">{it.d}</p>
            </Item>
          ))}
        </Stagger>
        <Reveal className="mt-16 flex flex-col items-center justify-center gap-4 border-y border-rule py-6 text-center sm:flex-row sm:flex-wrap sm:gap-10">
          <span className="inline-flex items-center gap-2.5 text-[0.98rem] text-navy">
            <Users size={17} className="text-golddeep" aria-hidden="true" />
            {t.trust.limits[0]}
          </span>
          <span className="inline-flex items-center gap-2.5 text-[0.98rem] text-navy">
            <Luggage size={17} className="text-golddeep" aria-hidden="true" />
            {t.trust.limits[1]}
          </span>
          <a href={hrefOf("about", "s=car")} className="group inline-flex items-center gap-2 eyebrow text-golddeep">
            {s.home.carCta}
            <Arrow />
          </a>
        </Reveal>
      </Shell>
    </section>
  );
}

function Doors() {
  const { t, s, price, cap } = useI18n();
  const tourFrom = Math.min(fromPrice("tour") ?? Infinity, fromPrice("versailles") ?? Infinity);
  const doors: { page: Page; key: "transfers" | "tours" | "multiday"; photo: string; from: number | null }[] = [
    { page: "transfers", key: "transfers", photo: "cdg", from: fromPrice("airport") },
    { page: "tours", key: "tours", photo: "louvre", from: Number.isFinite(tourFrom) ? tourFrom : null },
    { page: "multi-day", key: "multiday", photo: "versaillesGardens", from: null },
  ];
  return (
    <section aria-labelledby="doors-title" className="relative bg-cream py-24 md:py-32">
      <Shell>
        <Heading id="doors-title" eyebrow={s.home.doorsEyebrow} title={s.home.doorsTitle} />
        <div className="mt-14 grid grid-cols-1 gap-x-8 gap-y-16 md:mt-20 md:grid-cols-3">
          {doors.map((d, i) => {
            const p = photo(d.photo);
            return (
              <Reveal key={d.page} delay={i * 0.1} className={cx(i === 1 && "md:mt-20")}>
                <a href={hrefOf(d.page)} className="group block">
                  <div className="arch relative aspect-[3/4] overflow-hidden bg-night">
                    <Img
                      photo={p}
                      alt={cap(p.key)}
                      sizes="(min-width:768px) 32vw, 100vw"
                      className="h-full w-full object-cover transition-transform duration-[1600ms] ease-out group-hover:scale-[1.06]"
                    />
                    <div className="absolute inset-0 bg-[linear-gradient(0deg,rgba(11,18,34,0.55),transparent_45%)]" />
                    <span className="eyebrow num absolute bottom-5 left-1/2 -translate-x-1/2 text-ivory/90">N° 0{i + 1}</span>
                  </div>
                  <div className="mt-6 text-center">
                    <h3 className="display text-[2.1rem] text-navy">{s.nav[d.key]}</h3>
                    <p className="mx-auto mt-3 max-w-[34ch] text-[0.98rem] leading-relaxed text-stone">{s.home.doors[d.key]}</p>
                    <p className="num mt-4 font-display text-[1.25rem] text-golddeep">
                      {d.from !== null ? `${t.common.fromP(price(d.from))} · ${t.common.perCar}` : t.serviceHints.multiday}
                    </p>
                    <span className="mt-5 inline-flex items-center gap-2 border-b border-navy/25 pb-1 eyebrow text-navy transition-colors group-hover:border-golddeep group-hover:text-golddeep">
                      {s.common.discover}
                      <Arrow />
                    </span>
                  </div>
                </a>
              </Reveal>
            );
          })}
        </div>
      </Shell>
    </section>
  );
}

/** Destination photography: a pinned horizontal journey on desktop. */
function Reel() {
  const { t, s, cap } = useI18n();
  const planner = usePlanner();
  const reduce = useReducedMotion();
  const desktop = useMedia("(min-width: 1024px)");
  const enabled = desktop && !reduce;
  const section = useRef<HTMLElement>(null);
  const track = useRef<HTMLDivElement>(null);
  const [dist, setDist] = useState(0);
  const distMV = useMotionValue(0);

  useEffect(() => {
    if (!enabled) return;
    const el = track.current;
    if (!el) return;
    const measure = () => {
      const d = Math.max(0, el.scrollWidth - window.innerWidth);
      distMV.set(d);
      setDist(d);
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    window.addEventListener("resize", measure);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, [enabled, distMV]);

  const { scrollYProgress } = useScroll({ target: section, offset: ["start start", "end end"] });
  const x = useTransform([scrollYProgress, distMV], ([p, d]: number[]) => -p * d);
  const go = (target: ReelTarget) => (target === "custom" ? navigate(hrefOf("custom")) : planner.open({ service: target }));

  const cards = REEL.map((r, i) => {
    const p = photo(r.id);
    const portrait = p.h > p.w;
    return (
      <figure
        key={r.id}
        className={cx(
          "group relative shrink-0 snap-start overflow-hidden bg-navy",
          enabled ? (portrait ? "h-[64vh] w-[44vh]" : "h-[64vh] w-[88vh]") : portrait ? "h-[420px] w-[280px]" : "h-[420px] w-[560px] max-w-[85vw]",
          portrait && "arch",
        )}
      >
        <Img
          photo={p}
          alt={cap(p.key)}
          sizes={portrait ? "(min-width:1024px) 45vh, 280px" : "(min-width:1024px) 90vh, 85vw"}
          className="h-full w-full object-cover transition-transform duration-[1600ms] ease-out group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-[linear-gradient(0deg,rgba(11,18,34,0.85),transparent_55%)]" />
        <figcaption className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-5 md:p-6">
          <div className="min-w-0">
            <span className="eyebrow num text-gold">{String(i + 1).padStart(2, "0")}</span>
            <p className="mt-2 font-display text-[1.35rem] italic leading-tight text-ivory md:text-[1.6rem]">{cap(p.key)}</p>
          </div>
          <button
            type="button"
            onClick={() => go(r.target)}
            className="shrink-0 border border-ivory/40 px-3 py-2 eyebrow text-ivory transition-all duration-500 hover:bg-ivory hover:text-navy focus:translate-y-0 focus:opacity-100 lg:translate-y-2 lg:opacity-0 lg:group-hover:translate-y-0 lg:group-hover:opacity-100"
          >
            {t.dest.plan}
          </button>
        </figcaption>
      </figure>
    );
  });

  const guideLink = (
    <a href={hrefOf("guide")} className="group mt-8 inline-flex w-fit items-center gap-2 border-b border-gold/60 pb-1 eyebrow text-ivory transition-colors hover:text-gold">
      {s.common.readGuide}
      <Arrow />
    </a>
  );

  return (
    <section
      ref={section}
      aria-labelledby="reel-title"
      className="relative bg-night text-ivory"
      style={enabled ? { height: `calc(100vh + ${dist}px)` } : undefined}
    >
      <div className={enabled ? "sticky top-0 flex h-screen flex-col justify-center overflow-hidden" : "overflow-hidden py-24"}>
        {!enabled && (
          <Shell>
            <Heading on="dark" id="reel-title" eyebrow={t.dest.eyebrow} title={t.dest.title} sub={t.dest.sub}>
              {guideLink}
            </Heading>
          </Shell>
        )}
        <motion.div
          ref={track}
          style={enabled ? { x } : undefined}
          className={
            enabled
              ? "flex w-max items-center gap-6 pl-10 pr-[10vw] xl:pl-[max(4rem,calc((100vw-1280px)/2+4rem))]"
              : "no-scrollbar mt-12 flex snap-x snap-mandatory gap-4 overflow-x-auto px-6 pb-4 md:px-10"
          }
        >
          {enabled && (
            <div className="flex h-[64vh] w-[36vw] max-w-[520px] shrink-0 flex-col justify-end pr-8">
              <Eyebrow on="dark">{t.dest.eyebrow}</Eyebrow>
              <h2 id="reel-title" className="display mt-6 text-ivory [font-size:clamp(2.6rem,4.4vw,4.3rem)] [&_em]:text-gold">
                {rich(t.dest.title)}
              </h2>
              <p className="mt-6 max-w-[36ch] text-[1.05rem] leading-relaxed text-ivory/70">{t.dest.sub}</p>
              {guideLink}
              <p className="eyebrow mt-10 flex items-center gap-3 text-ivory/50">
                <span className="h-px w-10 bg-ivory/40" />
                {t.dest.hint} →
              </p>
            </div>
          )}
          {cards}
        </motion.div>
        {enabled && (
          <div aria-hidden="true" className="absolute bottom-10 left-1/2 h-px w-48 -translate-x-1/2 bg-ivory/20">
            <motion.span style={{ scaleX: scrollYProgress }} className="block h-full origin-left bg-gold" />
          </div>
        )}
      </div>
    </section>
  );
}

function CarTeaser() {
  const { t, s } = useI18n();
  const chips = [
    { icon: Users, label: t.common.upTo(CAPACITY.maxPassengers) },
    { icon: Luggage, label: `${CAPACITY.largeSuitcases} ${s.car.large}` },
    { icon: Briefcase, label: `${CAPACITY.cabinBags} ${s.car.cabin}` },
    { icon: Baby, label: t.transfers.perks[3] },
  ];
  return (
    <section aria-labelledby="car-teaser-title" className="relative overflow-hidden bg-ivory py-24 md:py-32">
      <div aria-hidden="true" className="pointer-events-none absolute -left-40 top-24 h-[480px] w-[480px] rounded-full border border-gold/25" />
      <Shell>
        <div className="grid grid-cols-12 items-center gap-y-12 lg:gap-x-16">
          <Reveal className="col-span-12 lg:col-span-6">
            <div className="arch relative mx-auto aspect-[4/5] max-w-[480px] overflow-hidden shadow-[0_50px_100px_-60px_rgba(11,18,34,0.8)]">
              <CarImage slot="front" tag="bottom" sizes="(min-width:1024px) 40vw, 90vw" />
            </div>
          </Reveal>
          <div className="col-span-12 lg:col-span-6">
            <Reveal>
              <Eyebrow>{s.home.carEyebrow}</Eyebrow>
              <h2 id="car-teaser-title" className="display mt-6 text-navy [font-size:clamp(2.5rem,5vw,4.2rem)] [&_em]:text-golddeep">
                {rich(s.home.carTitle)}
              </h2>
              <p className="mt-6 max-w-[46ch] text-[1.06rem] leading-relaxed text-stone">{s.home.carText}</p>
            </Reveal>
            <Stagger className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {chips.map(({ icon: Icon, label }) => (
                <Item key={label} className="flex items-center gap-3 border border-rule bg-[#fffdf8] px-4 py-3.5 text-[0.94rem] text-navy">
                  <Icon size={18} className="shrink-0 text-golddeep" aria-hidden="true" />
                  {label}
                </Item>
              ))}
            </Stagger>
            <Reveal className="mt-9">
              <a href={hrefOf("about", "s=car")} className={btn.navy}>
                <span className="eyebrow">{s.home.carCta}</span>
                <Arrow />
              </a>
            </Reveal>
          </div>
        </div>
      </Shell>
    </section>
  );
}

function StoriesTeaser() {
  const { t } = useI18n();
  const { reviews } = usePublicContent();
  return (
    <section aria-labelledby="stories-title" className="relative bg-cream py-24 md:py-32">
      <Shell>
        <Heading id="stories-title" eyebrow={t.stories.eyebrow} title={t.stories.title}>
          <a
            href={hrefOf("reviews")}
            className="group inline-flex items-center gap-2 border-b border-navy/25 pb-1 eyebrow text-navy transition-colors hover:border-golddeep hover:text-golddeep lg:mt-8"
          >
            {t.stories.readMore}
            <Arrow />
          </a>
        </Heading>
        <Reveal className="mt-14 md:mt-16">
          {reviews.length ? (
            <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
              {reviews.slice(0, 3).map((r) => (
                <ReviewCard key={r.id} r={r} />
              ))}
            </div>
          ) : (
            <StoriesInvite placeholders={2} />
          )}
        </Reveal>
      </Shell>
    </section>
  );
}

function AvailBand() {
  const { t, s } = useI18n();
  const p = photo("eiffelLights");
  return (
    <section aria-labelledby="avail-band-title" className="relative isolate overflow-hidden bg-night py-28 text-ivory md:py-40">
      <Parallax className="absolute inset-0 -z-20" amount={8}>
        <Img photo={p} alt="" sizes="100vw" className="h-full w-full object-cover opacity-60" />
      </Parallax>
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-[radial-gradient(80%_70%_at_50%_50%,rgba(11,18,34,0.5),rgba(11,18,34,0.92))]" />
      <Shell>
        <Heading center on="dark" id="avail-band-title" eyebrow={t.cal.eyebrow} title={s.home.availTitle} sub={s.home.availText}>
          <div className="mt-10 flex flex-wrap justify-center gap-3">
            <a href={hrefOf("availability")} className={btn.ivory}>
              <span className="eyebrow">{t.cal.title}</span>
              <Arrow />
            </a>
            <a href={waLink(t.contact.waMsg)} target="_blank" rel="noopener noreferrer" className={btn.light}>
              <WhatsAppIcon className="h-4 w-4" />
              <span className="eyebrow">{t.common.whatsapp}</span>
            </a>
          </div>
        </Heading>
      </Shell>
    </section>
  );
}

export default function Home() {
  return (
    <>
      <HomeHero />
      <Manifesto />
      <Doors />
      <Reel />
      <CarTeaser />
      <StoriesTeaser />
      <AvailBand />
    </>
  );
}
