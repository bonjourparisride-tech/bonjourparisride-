import { CONTACT, mailLink, telLink, waLink } from "../config";
import { useI18n } from "../i18n";
import { MENU, hrefOf, type NavKey, type Page } from "../lib/router";
import { LangSelect } from "./Nav";
import { usePlanner } from "./Planner";
import { Arrow, Mark, Shell, WhatsAppIcon, Wordmark, btn } from "./ui";

const SERVICES: Page[] = ["transfers", "tours", "multi-day", "custom", "availability"];
const DISCOVER: Page[] = ["gallery", "reviews", "guide", "about", "faq", "contact"];

export default function Footer() {
  const { t, s } = useI18n();
  const planner = usePlanner();
  const keyOf = (p: Page): NavKey => MENU.find((m) => m.page === p)?.key ?? "home";
  const link = "text-[0.95rem] text-ivory/70 transition-colors duration-300 hover:text-gold";

  return (
    <footer className="relative bg-night text-ivory">
      <div
        aria-hidden="true"
        className="h-[3px] w-full bg-[linear-gradient(90deg,#2b4a9b_0_33.33%,#faf6ee_33.33%_66.66%,#c8323a_66.66%)]"
      />
      <Shell className="pb-28 pt-20 md:pb-12 md:pt-24">
        <div className="flex flex-col items-start justify-between gap-10 border-b border-ivory/10 pb-14 lg:flex-row lg:items-end">
          <div>
            <p className="eyebrow text-gold">{s.nav.tagline}</p>
            <p className="display mt-4 text-[clamp(3.4rem,9vw,7.4rem)] italic leading-none">{s.common.closingLine}</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <button type="button" onClick={() => planner.open()} className={btn.ivory}>
              <span className="eyebrow">{t.nav.book}</span>
              <Arrow />
            </button>
            <a href={waLink(t.contact.waMsg)} target="_blank" rel="noopener noreferrer" className={btn.light}>
              <WhatsAppIcon className="h-4 w-4" />
              <span className="eyebrow">{t.common.whatsapp}</span>
            </a>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-x-6 gap-y-12 pt-14 md:grid-cols-4 lg:grid-cols-12">
          <div className="col-span-2 md:col-span-4 lg:col-span-4">
            <div className="flex items-center gap-3">
              <span className="text-gold">
                <Mark className="h-10 w-10" />
              </span>
              <Wordmark on="dark" />
            </div>
            <p className="mt-6 max-w-[36ch] text-[0.95rem] leading-relaxed text-ivory/65">{t.footer.tagline}</p>
            <div className="mt-6">
              <LangSelect on="dark" full />
            </div>
          </div>

          <nav aria-label={t.footer.services} className="lg:col-span-2">
            <h2 className="eyebrow text-gold">{t.footer.services}</h2>
            <ul className="mt-5 space-y-3">
              {SERVICES.map((p) => (
                <li key={p}>
                  <a href={hrefOf(p)} className={link}>
                    {s.nav[keyOf(p)]}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label={t.footer.explore} className="lg:col-span-2">
            <h2 className="eyebrow text-gold">{t.footer.explore}</h2>
            <ul className="mt-5 space-y-3">
              {DISCOVER.map((p) => (
                <li key={p}>
                  <a href={hrefOf(p)} className={link}>
                    {s.nav[keyOf(p)]}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div className="lg:col-span-2">
            <h2 className="eyebrow text-gold">{t.contact.eyebrow}</h2>
            <ul className="mt-5 space-y-3">
              <li>
                <a href={waLink(t.contact.waMsg)} target="_blank" rel="noopener noreferrer" className={`${link} inline-flex items-center gap-2`}>
                  <WhatsAppIcon className="h-3.5 w-3.5" /> {t.common.whatsapp}
                </a>
              </li>
              <li>
                <a href={telLink} className={`${link} num`}>
                  {CONTACT.phoneDisplay}
                </a>
              </li>
              <li>
                <a href={mailLink()} className={`${link} break-all`}>
                  {CONTACT.email}
                </a>
              </li>
              <li className="text-[0.88rem] leading-relaxed text-ivory/50">{t.contact.hours}</li>
            </ul>
          </div>

          <div className="lg:col-span-2">
            <h2 className="eyebrow text-gold">{t.footer.legal}</h2>
            <ul className="mt-5 space-y-3">
              {(["notice", "privacy", "terms"] as const).map((k) => (
                <li key={k}>
                  <a href={`#/legal/${k}`} className={link}>
                    {t.footer[k]}
                  </a>
                </li>
              ))}
              <li>
                <a href="#/admin" className="text-[0.85rem] text-ivory/40 transition-colors hover:text-ivory">
                  {t.footer.owner}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 space-y-2 border-t border-ivory/10 pt-7 text-[0.78rem] leading-relaxed text-ivory/45">
          <p>{t.footer.disney}</p>
          <p>{t.footer.credits}</p>
          <div className="flex flex-col gap-3 pt-3 md:flex-row md:items-center md:justify-between">
            <p className="eyebrow">
              © {new Date().getFullYear()} Bonjour Paris Ride · {t.footer.rights}
            </p>
            <button
              type="button"
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="eyebrow w-fit transition-colors hover:text-gold"
            >
              {t.footer.top} ↑
            </button>
          </div>
        </div>
      </Shell>
    </footer>
  );
}
