import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type Dispatch,
  type ReactNode,
  type SetStateAction,
} from "react";
import {
  ArrowRight,
  CalendarDays,
  CalendarRange,
  Castle,
  Check,
  Info,
  Landmark,
  Mail,
  Map as MapIcon,
  Plane,
  Sparkles,
  X,
  type LucideIcon,
} from "lucide-react";
import {
  CAPACITY,
  DEFAULT_OPTION,
  SERVICES,
  findOption,
  isPriced,
  optionsOf,
  type ServiceId,
} from "../config";
import { optText, useI18n } from "../i18n";
import { isValidISO, todayISO } from "../lib/availability";
import { navigate } from "../lib/router";
import type { Req } from "../lib/store";
import { buildMessage, newRef, requestLinks, submitRequest } from "../lib/submit";
import { CalendarPanel } from "./Calendar";
import {
  EASE,
  Field,
  Stepper,
  WhatsAppIcon,
  cx,
  inputCls,
  useFocusTrap,
  useLockBody,
  useTween,
} from "./ui";

/* ── state shared across the site ────────────────────────────────────────── */

export interface Draft {
  service: ServiceId;
  optionId: string;
  direction: "from" | "to";
  date: string | null;
  time: string;
  pax: number;
  bags: number;
  pickup: string;
  dropoff: string;
  flight: string;
  notes: string;
  childSeat: boolean;
  name: string;
  email: string;
  phone: string;
}

export interface QuoteSeed {
  target: "multiday" | "custom";
  date?: string | null;
  pax?: number;
  tour?: string;
}

interface OpenArgs {
  service?: ServiceId;
  optionId?: string;
  date?: string | null;
  pax?: number;
  step?: number;
}

interface Ctx {
  open: (a?: OpenArgs) => void;
  close: () => void;
  isOpen: boolean;
  draft: Draft;
  setDate: (iso: string) => void;
  seed: QuoteSeed | null;
  setSeed: (s: QuoteSeed | null) => void;
}

const PlannerCtx = createContext<Ctx | null>(null);

export function usePlanner() {
  const c = useContext(PlannerCtx);
  if (!c) throw new Error("usePlanner must be used inside <PlannerProvider>");
  return c;
}

const INITIAL: Draft = {
  service: "airport",
  optionId: "cdg",
  direction: "from",
  date: null,
  time: "",
  pax: 2,
  bags: 2,
  pickup: "",
  dropoff: "",
  flight: "",
  notes: "",
  childSeat: false,
  name: "",
  email: "",
  phone: "",
};

const defaultOpt = (s: ServiceId) => (isPriced(s) ? DEFAULT_OPTION[s] : "");

const ICONS: Record<ServiceId, LucideIcon> = {
  airport: Plane,
  tour: MapIcon,
  versailles: Landmark,
  disney: Castle,
  multiday: CalendarRange,
  custom: Sparkles,
};

export function PlannerProvider({ children }: { children: ReactNode }) {
  const [isOpen, setOpen] = useState(false);
  const [step, setStep] = useState(0);
  const [draft, setDraft] = useState<Draft>(INITIAL);
  const [seed, setSeed] = useState<QuoteSeed | null>(null);

  const open = useCallback((a: OpenArgs = {}) => {
    setDraft((d) => {
      const service = a.service ?? d.service;
      const optionId =
        a.optionId ?? (service !== d.service || !d.optionId ? defaultOpt(service) : d.optionId);
      let date = a.date !== undefined ? a.date : d.date;
      if (date && (!isValidISO(date) || date < todayISO())) date = null;
      const pax = a.pax ?? d.pax;
      return { ...d, service, optionId, date, pax, bags: Math.min(d.bags, CAPACITY.maxSuitcases) };
    });
    setStep(a.step ?? 0);
    setOpen(true);
  }, []);

  const close = useCallback(() => setOpen(false), []);
  const setDate = useCallback((iso: string) => setDraft((d) => ({ ...d, date: iso })), []);

  const value = useMemo(
    () => ({ open, close, isOpen, draft, setDate, seed, setSeed }),
    [open, close, isOpen, draft, setDate, seed],
  );

  return (
    <PlannerCtx.Provider value={value}>
      {children}
      <AnimatePresence>
        {isOpen && (
          <PlannerModal
            step={step}
            setStep={setStep}
            draft={draft}
            setDraft={setDraft}
            onClose={close}
            setSeed={setSeed}
          />
        )}
      </AnimatePresence>
    </PlannerCtx.Provider>
  );
}

/* ── confirmation, shared with the quote forms ───────────────────────────── */

export function RequestDone({
  req,
  message,
  delivered,
  onAgain,
}: {
  req: Req;
  message: string;
  delivered: boolean;
  onAgain?: () => void;
}) {
  const { t } = useI18n();
  const reduce = useReducedMotion();
  const links = requestLinks(req, message, t);
  return (
    <div role="status" aria-live="polite">
      <motion.div
        initial={reduce ? { opacity: 0 } : { scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 260, damping: 18 }}
        className="flex h-14 w-14 items-center justify-center rounded-full bg-avail text-paper"
      >
        <Check size={26} strokeWidth={2.5} aria-hidden="true" />
      </motion.div>
      <h3 className="display mt-6 text-[2.2rem] text-ink">{t.plan.doneT}</h3>
      <p className="mt-3 max-w-[50ch] text-[1rem] leading-relaxed text-stone">
        {delivered ? t.plan.doneSent : t.plan.doneLocal}
      </p>
      <p className="mt-5 inline-flex items-center gap-3 border border-rule bg-paper px-4 py-2">
        <span className="eyebrow text-stone">{t.plan.ref}</span>
        <span className="num font-display text-[1.05rem] text-ink">{req.id}</span>
      </p>
      <p className="mt-4 flex items-start gap-2 text-[0.92rem] text-rouge">
        <Info size={15} className="mt-0.5 shrink-0" aria-hidden="true" />
        {t.plan.pending}
      </p>
      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
        <a
          href={links.wa}
          target="_blank"
          rel="noopener noreferrer"
          className={cx(
            "inline-flex items-center justify-center gap-2.5 px-6 py-4 transition-all duration-500 hover:-translate-y-0.5",
            delivered
              ? "border border-ink/20 text-ink hover:border-ink hover:bg-ink hover:text-paper"
              : "bg-rouge text-paper shadow-[0_14px_30px_-16px_rgba(200,85,43,0.9)] hover:bg-ink",
          )}
        >
          <WhatsAppIcon className="h-4 w-4" />
          <span className="eyebrow">{t.plan.sendWa}</span>
        </a>
        <a
          href={links.mail}
          className="inline-flex items-center justify-center gap-2.5 border border-ink/20 px-6 py-4 text-ink transition-all duration-500 hover:-translate-y-0.5 hover:border-ink hover:bg-ink hover:text-paper"
        >
          <Mail size={15} aria-hidden="true" />
          <span className="eyebrow">{t.plan.sendEmail}</span>
        </a>
      </div>
      {onAgain && (
        <button
          type="button"
          onClick={onAgain}
          className="mt-6 eyebrow text-stone underline-offset-4 transition-colors hover:text-ink hover:underline"
        >
          {t.plan.again}
        </button>
      )}
    </div>
  );
}

/* ── the modal ───────────────────────────────────────────────────────────── */

function PlannerModal({
  step,
  setStep,
  draft,
  setDraft,
  onClose,
  setSeed,
}: {
  step: number;
  setStep: (n: number) => void;
  draft: Draft;
  setDraft: Dispatch<SetStateAction<Draft>>;
  onClose: () => void;
  setSeed: (s: QuoteSeed | null) => void;
}) {
  const { t, price, date: fmtDate, lang } = useI18n();
  const reduce = useReducedMotion();
  const panel = useRef<HTMLDivElement>(null);
  const body = useRef<HTMLDivElement>(null);
  const [sending, setSending] = useState(false);
  const [err, setErr] = useState("");
  const [result, setResult] = useState<{ req: Req; message: string; delivered: boolean } | null>(null);

  useLockBody(true);
  useFocusTrap(panel, true, onClose);

  useEffect(() => {
    if (step > 0 && step < 3 && !draft.date) setStep(0);
  }, [step, draft.date, setStep]);

  useEffect(() => {
    body.current?.scrollTo({ top: 0 });
  }, [step]);

  const upd = (p: Partial<Draft>) => setDraft((d) => ({ ...d, ...p }));

  const priced = isPriced(draft.service);
  const option = findOption(draft.service, draft.optionId);
  const priceVal = priced ? option?.price ?? null : null;
  const shown = useTween(priceVal ?? 0);
  const airport = draft.service === "airport";
  const fromAirport = airport && draft.direction === "from";
  const maxBags = CAPACITY.suitcasesFor(draft.pax);
  const quoteOnly = draft.service === "multiday" || draft.service === "custom";
  const optLabel = priced && option ? optText(t, draft.service as never, option.id)?.l : undefined;

  const goQuote = () => {
    const target = draft.service === "multiday" ? "multiday" : "custom";
    setSeed({ target, date: draft.date, pax: draft.pax });
    onClose();
    navigate(target === "multiday" ? "#/multi-day?form=1" : "#/custom?form=1");
  };

  const submit = async () => {
    if (!draft.email.trim() && !draft.phone.trim()) {
      setErr(t.plan.errContact);
      return;
    }
    if (!draft.date) return;
    setErr("");
    setSending(true);
    const req: Req = {
      id: newRef(),
      createdAt: new Date().toISOString(),
      status: "pending",
      kind: "booking",
      source: "website",
      service: draft.service,
      optionId: priced ? option?.id : undefined,
      direction: airport ? draft.direction : undefined,
      date: draft.date,
      time: draft.time || undefined,
      pax: draft.pax,
      bags: draft.bags,
      pickup: draft.pickup.trim() || undefined,
      dropoff: draft.dropoff.trim() || undefined,
      flight: fromAirport ? draft.flight.trim().toUpperCase() || undefined : undefined,
      notes: draft.notes.trim() || undefined,
      childSeat: draft.childSeat || undefined,
      price: priceVal,
      name: draft.name.trim() || undefined,
      email: draft.email.trim() || undefined,
      phone: draft.phone.trim() || undefined,
      lang,
    };
    const message = buildMessage(req, t, { date: fmtDate, price });
    const { delivered } = await submitRequest(req, message);
    setSending(false);
    setResult({ req, message, delivered });
    setStep(3);
  };

  const primaryBtn =
    "group inline-flex items-center justify-center gap-3 bg-rouge px-6 py-4 text-paper shadow-[0_14px_30px_-16px_rgba(200,85,43,0.9)] transition-all duration-500 hover:-translate-y-0.5 hover:bg-ink disabled:pointer-events-none disabled:opacity-40";
  const backBtn = "eyebrow text-stone transition-colors duration-300 hover:text-ink";

  const dateChip = draft.date && (
    <button
      type="button"
      onClick={() => setStep(0)}
      className="mb-6 inline-flex items-center gap-2 border border-rule bg-paper px-4 py-2 text-[0.88rem] text-ink transition-colors hover:border-ink lg:hidden"
    >
      <CalendarDays size={14} className="text-rouge" aria-hidden="true" />
      {fmtDate(draft.date, "medium")}
      <span className="text-rouge">· {t.plan.change}</span>
    </button>
  );

  return (
    <motion.div
      className="fixed inset-0 z-[70] flex items-stretch justify-center sm:items-center sm:p-4 lg:p-8"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="absolute inset-0 bg-inkdeep/75 backdrop-blur-sm" onClick={onClose} aria-hidden="true" />
      <motion.div
        ref={panel}
        role="dialog"
        aria-modal="true"
        aria-labelledby="planner-title"
        initial={reduce ? { opacity: 0 } : { opacity: 0, y: 40, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={reduce ? { opacity: 0 } : { opacity: 0, y: 30, scale: 0.98 }}
        transition={{ duration: 0.5, ease: EASE }}
        className="relative flex h-full w-full max-w-6xl flex-col overflow-hidden bg-paper shadow-[0_60px_120px_-40px_rgba(0,0,0,0.85)] sm:h-auto sm:max-h-[94svh]"
      >
        <div className="flex items-center justify-between gap-4 border-b border-rule px-5 py-4 md:px-8">
          <div className="flex min-w-0 items-baseline gap-4">
            <p id="planner-title" className="truncate font-display text-[1.35rem] tracking-[-0.02em] text-ink">
              {t.plan.title}
            </p>
            <span className="eyebrow num hidden text-stone sm:inline">
              {t.plan.step(step + 1, 4)} · {t.plan.steps[step]}
            </span>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden gap-1.5 md:flex" aria-hidden="true">
              {t.plan.steps.map((s, i) => (
                <span
                  key={s}
                  className={cx("h-1 w-8 rounded-full transition-colors duration-500", i <= step ? "bg-rouge" : "bg-rule")}
                />
              ))}
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label={t.common.close}
              className="flex h-11 w-11 items-center justify-center rounded-full border border-rule text-ink transition-all duration-300 hover:rotate-90 hover:border-ink hover:bg-ink hover:text-paper"
            >
              <X size={18} aria-hidden="true" />
            </button>
          </div>
        </div>

        <div ref={body} className="flex-1 overflow-y-auto overscroll-contain">
          <div className="grid lg:grid-cols-[minmax(0,1.05fr)_minmax(0,1fr)]">
            <section
              aria-labelledby="planner-cal-title"
              className={cx("p-5 md:p-8 lg:border-r lg:border-rule", step > 0 && "hidden lg:block")}
            >
              <CalendarPanel
                titleId="planner-cal-title"
                selected={draft.date}
                onSelect={(iso) => upd({ date: iso })}
                onPlan={() => setStep(1)}
              />
            </section>

            <section className={cx("bg-paper2/70 p-5 md:p-8", step === 0 && "hidden lg:block")}>
              <AnimatePresence mode="wait" initial={false}>
                <motion.div
                  key={step}
                  initial={reduce ? { opacity: 0 } : { opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={reduce ? { opacity: 0 } : { opacity: 0, y: -12 }}
                  transition={{ duration: 0.35, ease: EASE }}
                >
                  {step === 0 && (
                    <div>
                      <p className="eyebrow text-rouge">{t.plan.yourJourney}</p>
                      <h3 className="display mt-3 text-[2.1rem] text-ink">{t.services[draft.service]}</h3>
                      {optLabel && <p className="mt-2 text-[0.95rem] text-stone">{optLabel}</p>}
                      <div className="mt-6 border border-rule bg-paper p-5">
                        <p className="eyebrow text-stone">{t.plan.date}</p>
                        <p className="mt-2 font-display text-[1.35rem] text-ink">
                          {draft.date ? fmtDate(draft.date) : t.cal.none}
                        </p>
                        <p className="mt-3 text-[0.9rem] text-stone">{t.cal.instruction}</p>
                      </div>
                      <button
                        type="button"
                        disabled={!draft.date}
                        onClick={() => setStep(1)}
                        className={cx(primaryBtn, "mt-6 w-full")}
                      >
                        <span className="eyebrow">{t.hero.ctaPlan}</span>
                        <ArrowRight size={15} aria-hidden="true" />
                      </button>
                      <ul className="mt-8 space-y-2.5 text-[0.88rem] text-stone">
                        {[t.plan.notBooking, t.plan.included, t.common.upTo(CAPACITY.maxPassengers)].map((x) => (
                          <li key={x} className="flex items-start gap-2.5">
                            <Check size={15} className="mt-0.5 shrink-0 text-avail" aria-hidden="true" />
                            {x}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {step === 1 && (
                    <div>
                      {dateChip}
                      <p id="svc-label" className="eyebrow text-stone">
                        {t.plan.service}
                      </p>
                      <div role="radiogroup" aria-labelledby="svc-label" className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
                        {SERVICES.map((s) => {
                          const Icon = ICONS[s];
                          const on = draft.service === s;
                          return (
                            <button
                              key={s}
                              type="button"
                              role="radio"
                              aria-checked={on}
                              onClick={() => upd({ service: s, optionId: defaultOpt(s) })}
                              className={cx(
                                "flex flex-col items-start gap-2 border p-3 text-left transition-all duration-300",
                                on
                                  ? "border-ink bg-ink text-paper shadow-[0_16px_30px_-20px_rgba(11,13,34,0.9)]"
                                  : "border-rule bg-paper text-ink hover:-translate-y-0.5 hover:border-ink/50",
                              )}
                            >
                              <Icon size={17} className={on ? "text-rouge" : "text-stone"} aria-hidden="true" />
                              <span className="font-display text-[1rem] leading-tight">{t.services[s]}</span>
                              <span className={cx("text-[0.74rem] leading-snug", on ? "text-paper/65" : "text-stone")}>
                                {t.serviceHints[s]}
                              </span>
                            </button>
                          );
                        })}
                      </div>

                      {quoteOnly ? (
                        <div className="mt-6 border border-rule bg-paper p-5">
                          <p className="font-display text-[1.25rem] text-ink">{t.plan.toQuote}</p>
                          <p className="mt-2 text-[0.9rem] leading-relaxed text-stone">{t.quote.noPrice}</p>
                          <div className="mt-5 flex flex-wrap items-center justify-between gap-4">
                            <button type="button" onClick={() => setStep(0)} className={backBtn}>
                              ← {t.common.back}
                            </button>
                            <button type="button" onClick={goQuote} className={primaryBtn}>
                              <span className="eyebrow">{t.plan.toQuoteBtn}</span>
                              <ArrowRight size={15} aria-hidden="true" />
                            </button>
                          </div>
                        </div>
                      ) : (
                        <>
                          {airport && (
                            <div className="mt-6">
                              <p id="dir-label" className="eyebrow text-stone">
                                {t.plan.direction}
                              </p>
                              <div role="radiogroup" aria-labelledby="dir-label" className="mt-2 inline-flex border border-rule bg-paper p-1">
                                {(["from", "to"] as const).map((d) => {
                                  const on = draft.direction === d;
                                  return (
                                    <button
                                      key={d}
                                      type="button"
                                      role="radio"
                                      aria-checked={on}
                                      onClick={() => upd({ direction: d })}
                                      className={cx(
                                        "relative px-4 py-2.5 eyebrow transition-colors duration-300",
                                        on ? "text-paper" : "text-stone hover:text-ink",
                                      )}
                                    >
                                      {on && (
                                        <motion.span
                                          layoutId="dir-pill"
                                          className="absolute inset-0 bg-ink"
                                          transition={{ duration: reduce ? 0 : 0.4, ease: EASE }}
                                        />
                                      )}
                                      <span className="relative">{d === "from" ? t.plan.fromAirport : t.plan.toAirport}</span>
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          )}

                          <p id="opt-label" className="eyebrow mt-6 text-stone">
                            {t.plan.option}
                          </p>
                          <div role="radiogroup" aria-labelledby="opt-label" className="mt-1">
                            {optionsOf(draft.service).map((o) => {
                              const on = o.id === option?.id;
                              const txt = optText(t, draft.service as never, o.id);
                              return (
                                <button
                                  key={o.id}
                                  type="button"
                                  role="radio"
                                  aria-checked={on}
                                  onClick={() => upd({ optionId: o.id })}
                                  className={cx(
                                    "flex w-full items-center justify-between gap-4 border-b border-rule py-3.5 text-left transition-colors duration-300",
                                    on ? "text-ink" : "text-stone hover:text-ink",
                                  )}
                                >
                                  <span className="flex items-center gap-3.5">
                                    <span
                                      className={cx(
                                        "flex h-5 w-5 shrink-0 items-center justify-center rounded-full border transition-colors duration-300",
                                        on ? "border-rouge bg-rouge" : "border-rule bg-paper",
                                      )}
                                    >
                                      {on && <span className="h-1.5 w-1.5 rounded-full bg-paper" />}
                                    </span>
                                    <span>
                                      <span className="block font-display text-[1.05rem] tracking-[-0.01em]">{txt?.l}</span>
                                      <span className="mt-0.5 block text-[0.82rem] text-stone">{txt?.d}</span>
                                    </span>
                                  </span>
                                  <span className="num shrink-0 font-display text-[1.05rem]">{price(o.price)}</span>
                                </button>
                              );
                            })}
                          </div>

                          <div className="mt-6 grid grid-cols-1 gap-x-4 gap-y-5 sm:grid-cols-2">
                            <Field label={fromAirport ? t.plan.landing : t.plan.time}>
                              <input
                                type="time"
                                value={draft.time}
                                onChange={(e) => upd({ time: e.target.value })}
                                className={inputCls}
                              />
                            </Field>
                            {fromAirport ? (
                              <Field label={t.plan.flight}>
                                <input
                                  value={draft.flight}
                                  onChange={(e) => upd({ flight: e.target.value })}
                                  placeholder={t.plan.flightPh}
                                  autoCapitalize="characters"
                                  autoComplete="off"
                                  className={inputCls}
                                />
                              </Field>
                            ) : (
                              <span className="hidden sm:block" />
                            )}
                            <Stepper
                              label={t.common.passengers}
                              value={draft.pax}
                              min={1}
                              max={CAPACITY.maxPassengers}
                              onChange={(n) => upd({ pax: n })}
                              decLabel={t.common.decrease}
                              incLabel={t.common.increase}
                            />
                            <Stepper
                              label={t.common.suitcases}
                              value={draft.bags}
                              min={0}
                              max={CAPACITY.maxSuitcases}
                              onChange={(n) => upd({ bags: n })}
                              decLabel={t.common.decrease}
                              incLabel={t.common.increase}
                              warn={draft.bags > maxBags}
                              hint={draft.bags > maxBags ? t.plan.bagsWarn(maxBags) : t.trust.limits[1]}
                            />
                            <Field label={fromAirport ? t.plan.terminal : t.plan.pickup}>
                              <input
                                value={draft.pickup}
                                onChange={(e) => upd({ pickup: e.target.value })}
                                placeholder={fromAirport ? t.plan.terminalPh : t.plan.pickupPh}
                                autoComplete="off"
                                className={inputCls}
                              />
                            </Field>
                            <Field label={airport && !fromAirport ? t.plan.depTerminal : t.plan.dropoff}>
                              <input
                                value={draft.dropoff}
                                onChange={(e) => upd({ dropoff: e.target.value })}
                                placeholder={airport && !fromAirport ? t.plan.depTerminalPh : t.plan.dropoffPh}
                                autoComplete="off"
                                className={inputCls}
                              />
                            </Field>
                            <Field label={t.plan.details} className="sm:col-span-2">
                              <textarea
                                value={draft.notes}
                                onChange={(e) => upd({ notes: e.target.value })}
                                placeholder={t.plan.detailsPh}
                                rows={3}
                                className={cx(inputCls, "resize-y")}
                              />
                            </Field>
                            <label className="flex cursor-pointer items-center gap-3 sm:col-span-2">
                              <input
                                type="checkbox"
                                checked={draft.childSeat}
                                onChange={(e) => upd({ childSeat: e.target.checked })}
                                className="h-5 w-5 accent-[#c8552b]"
                              />
                              <span className="text-[0.95rem] text-ink">{t.plan.childSeat}</span>
                            </label>
                          </div>

                          <div className="mt-6 flex items-end justify-between gap-4 bg-ink p-5 text-paper">
                            <div>
                              <p className="eyebrow text-paper/60">{priceVal !== null ? t.plan.fixed : t.common.onRequest}</p>
                              <p className="mt-1.5 max-w-[30ch] text-[0.82rem] leading-snug text-paper/70">
                                {priceVal !== null ? t.plan.included : t.plan.quoteNote}
                              </p>
                            </div>
                            {priceVal !== null && (
                              <p className="display num text-[2.4rem] leading-none">{price(Math.round(shown))}</p>
                            )}
                          </div>

                          <div className="mt-6 flex items-center justify-between gap-4">
                            <button type="button" onClick={() => setStep(0)} className={backBtn}>
                              ← {t.common.back}
                            </button>
                            <button type="button" onClick={() => setStep(2)} className={primaryBtn}>
                              <span className="eyebrow">{t.common.continue}</span>
                              <ArrowRight size={15} aria-hidden="true" />
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  )}

                  {step === 2 && (
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        void submit();
                      }}
                      noValidate
                    >
                      {dateChip}
                      <p className="eyebrow text-rouge">{t.plan.contactT}</p>
                      <div className="mt-4 border border-rule bg-paper p-4 text-[0.9rem] text-ink">
                        <p className="font-display text-[1.1rem]">
                          {t.services[draft.service]}
                          {optLabel ? ` · ${optLabel}` : ""}
                        </p>
                        <p className="mt-1 text-stone">
                          {draft.date ? fmtDate(draft.date, "medium") : ""}
                          {draft.time ? ` · ${draft.time}` : ""} · {t.common.passengers}: {draft.pax}
                        </p>
                        <p className="mt-1 num text-ink">
                          {priceVal !== null ? `${t.plan.fixed}: ${price(priceVal)}` : t.plan.quoteNote}
                        </p>
                      </div>
                      <div className="mt-5 grid grid-cols-1 gap-5">
                        <Field label={t.plan.name}>
                          <input
                            value={draft.name}
                            onChange={(e) => upd({ name: e.target.value })}
                            autoComplete="name"
                            className={inputCls}
                          />
                        </Field>
                        <Field label={t.plan.email}>
                          <input
                            type="email"
                            value={draft.email}
                            onChange={(e) => upd({ email: e.target.value })}
                            autoComplete="email"
                            className={inputCls}
                          />
                        </Field>
                        <Field label={t.plan.phone} hint={t.plan.contactHint}>
                          <input
                            type="tel"
                            value={draft.phone}
                            onChange={(e) => upd({ phone: e.target.value })}
                            autoComplete="tel"
                            className={inputCls}
                          />
                        </Field>
                      </div>
                      {err && (
                        <p role="alert" className="mt-4 text-[0.9rem] text-rouge">
                          {err}
                        </p>
                      )}
                      <p className="mt-4 text-[0.82rem] leading-snug text-stone">{t.plan.privacy}</p>
                      <p className="mt-1 text-[0.82rem] leading-snug text-stone">{t.plan.notBooking}</p>
                      <div className="mt-6 flex items-center justify-between gap-4">
                        <button type="button" onClick={() => setStep(1)} className={backBtn}>
                          ← {t.common.back}
                        </button>
                        <button type="submit" disabled={sending} className={primaryBtn}>
                          <span className="eyebrow">{sending ? t.plan.sending : t.plan.submit}</span>
                          <ArrowRight size={15} aria-hidden="true" />
                        </button>
                      </div>
                    </form>
                  )}

                  {step === 3 && result && (
                    <RequestDone
                      req={result.req}
                      message={result.message}
                      delivered={result.delivered}
                      onAgain={() => {
                        setResult(null);
                        setStep(0);
                      }}
                    />
                  )}
                </motion.div>
              </AnimatePresence>
            </section>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
