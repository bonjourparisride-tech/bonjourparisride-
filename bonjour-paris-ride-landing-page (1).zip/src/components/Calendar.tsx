import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useEffect, useMemo, useRef, useState, type KeyboardEvent } from "react";
import { ArrowRight, ChevronLeft, ChevronRight, Info, Mail, Phone } from "lucide-react";
import { CALENDAR, mailLink, telLink, waLink } from "../config";
import { useI18n } from "../i18n";
import {
  isSelectable,
  parseISO,
  toISO,
  todayISO,
  useAvailability,
  type PublicStatus,
} from "../lib/availability";
import { EASE, WhatsAppIcon, cx } from "./ui";

const CELL: Record<PublicStatus, string> = {
  available:
    "border-avail/25 bg-avail/[0.08] text-ink hover:-translate-y-0.5 hover:border-avail/70 hover:bg-avail/[0.16] hover:shadow-[0_12px_22px_-16px_rgba(61,122,84,0.9)]",
  limited:
    "border-limited/30 bg-limited/[0.12] text-ink hover:-translate-y-0.5 hover:border-limited/70 hover:bg-limited/[0.2] hover:shadow-[0_12px_22px_-16px_rgba(196,132,28,0.9)]",
  booked: "cursor-not-allowed border-transparent bg-booked/[0.18] text-stone/60 line-through decoration-stone/40",
  blocked: "cursor-not-allowed border-transparent bg-booked/[0.18] text-stone/60 line-through decoration-stone/40",
  past: "cursor-not-allowed border-transparent text-stone/30",
  closed: "cursor-not-allowed border-transparent text-stone/30",
};

const DOT: Record<PublicStatus, string> = {
  available: "bg-avail",
  limited: "bg-limited",
  booked: "bg-booked",
  blocked: "bg-booked",
  past: "bg-transparent",
  closed: "bg-transparent",
};

/** Public availability calendar — shows only day colours, never booking details. */
export function CalendarPanel({
  selected,
  onSelect,
  onPlan,
  titleId = "cal-title",
  actions = true,
}: {
  selected: string | null;
  onSelect: (iso: string) => void;
  onPlan?: () => void;
  titleId?: string;
  actions?: boolean;
}) {
  const { t, month, weekdays, date } = useI18n();
  const { statusOf, live, loading, error } = useAvailability();
  const reduce = useReducedMotion();
  const today = todayISO();

  const now = new Date();
  const minIdx = now.getFullYear() * 12 + now.getMonth();
  const maxIdx = minIdx + CALENDAR.horizonMonths;
  const clamp = (i: number) => Math.min(maxIdx, Math.max(minIdx, i));

  const [view, setView] = useState(() => {
    const base = selected ? parseISO(selected) : now;
    return clamp(base.getFullYear() * 12 + base.getMonth());
  });
  const [dir, setDir] = useState(1);
  const [warn, setWarn] = useState(false);
  const btns = useRef<(HTMLButtonElement | null)[]>([]);

  // follow a date chosen elsewhere (e.g. in the planner modal)
  useEffect(() => {
    if (!selected) return;
    const d = parseISO(selected);
    setView(clamp(d.getFullYear() * 12 + d.getMonth()));
    setWarn(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected]);

  const y = Math.floor(view / 12);
  const m = view % 12;

  const cells = useMemo(() => {
    const lead = new Date(y, m, 1).getDay();
    const count = new Date(y, m + 1, 0).getDate();
    return [
      ...Array.from({ length: lead }, () => null),
      ...Array.from({ length: count }, (_, i) => toISO(new Date(y, m, i + 1, 12))),
    ];
  }, [y, m]);

  const shift = (n: number) => {
    setDir(n);
    setView((v) => clamp(v + n));
  };

  const labelOf = (s: PublicStatus) =>
    ({
      available: t.cal.available,
      limited: t.cal.limited,
      booked: t.cal.booked,
      blocked: t.cal.unavailable,
      past: t.cal.past,
      closed: t.cal.closed,
    })[s];

  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    const step = ({ ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 } as Record<string, number>)[e.key];
    if (!step) return;
    const idx = btns.current.findIndex((b) => b === document.activeElement);
    if (idx < 0) return;
    e.preventDefault();
    for (let i = idx + step; i >= 0 && i < btns.current.length; i += step) {
      const b = btns.current[i];
      if (b && !b.disabled) {
        b.focus();
        break;
      }
    }
  };

  const plan = () => {
    if (!selected) {
      setWarn(true);
      return;
    }
    onPlan?.();
  };

  const msg = selected ? t.cal.ask(date(selected)) : t.cal.askAny;
  const secondary =
    "flex items-center justify-center gap-2 border border-ink/15 bg-paper px-3 py-3.5 text-ink transition-all duration-300 hover:-translate-y-0.5 hover:border-ink hover:bg-ink hover:text-paper";

  return (
    <div>
      <p className="eyebrow text-rouge">{t.cal.eyebrow}</p>
      <h2 id={titleId} className="display mt-3 text-ink [font-size:clamp(2rem,4vw,2.9rem)]">
        {t.cal.title}
      </h2>

      <div className="mt-6 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={() => shift(-1)}
          disabled={view <= minIdx}
          aria-label={t.cal.prev}
          className="flex h-11 w-11 items-center justify-center rounded-full border border-rule text-ink transition-all duration-300 hover:border-ink hover:bg-ink hover:text-paper disabled:pointer-events-none disabled:opacity-30"
        >
          <ChevronLeft size={18} aria-hidden="true" />
        </button>
        <p aria-live="polite" className="display text-center text-ink [font-size:clamp(1.45rem,3vw,1.95rem)]">
          {month(y, m)}
        </p>
        <button
          type="button"
          onClick={() => shift(1)}
          disabled={view >= maxIdx}
          aria-label={t.cal.next}
          className="flex h-11 w-11 items-center justify-center rounded-full border border-rule text-ink transition-all duration-300 hover:border-ink hover:bg-ink hover:text-paper disabled:pointer-events-none disabled:opacity-30"
        >
          <ChevronRight size={18} aria-hidden="true" />
        </button>
      </div>

      <div className="mt-5 grid grid-cols-7 gap-1.5" aria-hidden="true">
        {weekdays.map((w) => (
          <span key={w} className="eyebrow truncate py-1.5 text-center text-stone">
            {w}
          </span>
        ))}
      </div>

      <div className="relative">
        <AnimatePresence mode="popLayout" initial={false}>
          <motion.div
            key={view}
            role="group"
            aria-label={month(y, m)}
            onKeyDown={onKey}
            initial={reduce ? { opacity: 0 } : { opacity: 0, x: dir * 28 }}
            animate={{ opacity: 1, x: 0 }}
            exit={reduce ? { opacity: 0 } : { opacity: 0, x: dir * -28 }}
            transition={{ duration: 0.35, ease: EASE }}
            className="grid grid-cols-7 gap-1.5"
          >
            {cells.map((iso, i) => {
              if (!iso) return <span key={`e${i}`} aria-hidden="true" />;
              const st = statusOf(iso);
              const sel = iso === selected;
              const day = Number(iso.slice(8));
              return (
                <button
                  key={iso}
                  ref={(el) => {
                    btns.current[day - 1] = el;
                  }}
                  type="button"
                  disabled={!isSelectable(st)}
                  aria-pressed={sel}
                  aria-label={`${date(iso)} — ${labelOf(st)}`}
                  onClick={() => {
                    setWarn(false);
                    onSelect(iso);
                  }}
                  className={cx(
                    "relative flex h-12 flex-col items-center justify-center gap-1 rounded-md border transition-all duration-300 sm:h-14",
                    sel
                      ? "border-ink bg-ink text-paper shadow-[0_14px_26px_-14px_rgba(11,13,34,0.9)] ring-2 ring-rouge ring-offset-2 ring-offset-paper"
                      : CELL[st],
                  )}
                >
                  <span
                    className={cx(
                      "num font-display text-[1rem] leading-none sm:text-[1.1rem]",
                      iso === today && !sel && "underline decoration-rouge decoration-2 underline-offset-4",
                    )}
                  >
                    {day}
                  </span>
                  <span className={cx("h-1.5 w-1.5 rounded-full", sel ? "bg-paper" : DOT[st])} />
                </button>
              );
            })}
          </motion.div>
        </AnimatePresence>
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center bg-paper/75 backdrop-blur-[2px]">
            <p className="eyebrow text-stone">{t.cal.loading}</p>
          </div>
        )}
      </div>

      <ul aria-label={t.cal.legend} className="mt-5 flex flex-wrap gap-x-5 gap-y-2">
        <li className="flex items-center gap-2 text-[0.82rem] text-stone">
          <span className="h-2.5 w-2.5 rounded-full bg-avail" />
          {t.cal.available}
        </li>
        <li className="flex items-center gap-2 text-[0.82rem] text-stone">
          <span className="h-2.5 w-2.5 rounded-full bg-limited" />
          {t.cal.limited}
        </li>
        <li className="flex items-center gap-2 text-[0.82rem] text-stone">
          <span className="h-2.5 w-2.5 rounded-full bg-booked" />
          {t.cal.booked}
        </li>
      </ul>

      <div className="mt-5 border-t border-rule pt-4">
        <p className="text-[0.95rem] text-ink">{t.cal.instruction}</p>
        <p aria-live="polite" className={cx("mt-1 text-[0.88rem]", warn ? "text-red" : "text-stone")}>
          {warn ? t.plan.pickFirst : selected ? t.cal.selected(date(selected)) : t.cal.none}
        </p>
      </div>

      <p className="mt-3 flex items-start gap-2 bg-paper2 px-3 py-2.5 text-[0.78rem] leading-snug text-stone">
        <Info size={14} className="mt-0.5 shrink-0 text-rouge" aria-hidden="true" />
        {error ? t.cal.error : live ? t.cal.live : t.cal.demo}
      </p>

      {actions && (
        <div className="mt-5 grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={plan}
            className="group col-span-3 flex items-center justify-center gap-3 bg-rouge px-5 py-4 text-paper shadow-[0_14px_30px_-16px_rgba(200,85,43,0.9)] transition-all duration-500 hover:-translate-y-0.5 hover:bg-ink"
          >
            <span className="eyebrow">{t.hero.ctaPlan}</span>
            <ArrowRight size={15} className="transition-transform duration-500 group-hover:translate-x-1" aria-hidden="true" />
          </button>
          <a href={waLink(msg)} target="_blank" rel="noopener noreferrer" className={secondary}>
            <WhatsAppIcon className="h-4 w-4" />
            <span className="eyebrow">{t.common.whatsapp}</span>
          </a>
          <a href={mailLink(t.cal.subject, msg)} className={secondary}>
            <Mail size={15} aria-hidden="true" />
            <span className="eyebrow">{t.common.email}</span>
          </a>
          <a href={telLink} className={secondary}>
            <Phone size={15} aria-hidden="true" />
            <span className="eyebrow">{t.common.call}</span>
          </a>
        </div>
      )}
    </div>
  );
}
