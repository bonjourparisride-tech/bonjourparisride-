import { Quote } from "lucide-react";
import { LINKS, waLink } from "../config";
import { useI18n } from "../i18n";
import { isValidISO } from "../lib/availability";
import type { Review } from "../lib/store";
import { Arrow, btn, cx } from "./ui";

/** A genuine guest review (added by the owner, with the guest's consent). */
export function ReviewCard({ r }: { r: Review }) {
  const { t, date } = useI18n();
  const rating = Math.max(1, Math.min(5, Math.round(r.rating || 5)));
  const initials = r.name
    .split(/[\s&]+/)
    .filter(Boolean)
    .map((w) => w[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
  const meta = [r.country, r.service ? t.services[r.service] : "", r.date && isValidISO(r.date) ? date(r.date, "short") : ""]
    .filter(Boolean)
    .join(" · ");
  return (
    <figure className="flex h-full flex-col border-t-2 border-golddeep bg-[#fffdf8] p-7 shadow-[0_40px_80px_-60px_rgba(11,18,34,0.5)]">
      <div className="flex items-center justify-between">
        <span aria-hidden="true" className="font-display text-[3.4rem] leading-[0.6] text-golddeep">
          “
        </span>
        <span role="img" aria-label={t.stories.rated(rating)} className="text-[0.95rem] tracking-[0.15em] text-gold">
          {"★".repeat(rating)}
          <span className="text-rule">{"★".repeat(5 - rating)}</span>
        </span>
      </div>
      <blockquote className="mt-5 font-display text-[1.28rem] italic leading-[1.5] text-navy">{r.text}</blockquote>
      <figcaption className="mt-auto flex items-center gap-4 pt-7">
        {r.photo && r.consent ? (
          <img src={r.photo} alt="" loading="lazy" className="h-12 w-12 shrink-0 rounded-full object-cover" />
        ) : (
          <span
            aria-hidden="true"
            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-gold/50 bg-cream font-display text-navy"
          >
            {initials}
          </span>
        )}
        <span className="min-w-0">
          <span className="block font-display text-[1.1rem] text-navy">{r.name}</span>
          {meta && <span className="eyebrow mt-1 block text-stone">{meta}</span>}
          {r.sourceUrl && (
            <a
              href={r.sourceUrl}
              target="_blank"
              rel="noopener noreferrer nofollow"
              className="mt-1.5 inline-flex items-center gap-1 text-[0.82rem] text-golddeep hover:underline"
            >
              {t.stories.source}
              {r.sourceName ? ` · ${r.sourceName}` : ""} ↗
            </a>
          )}
        </span>
      </figcaption>
    </figure>
  );
}

/** Honest empty state: an invitation plus clearly labelled placeholders. */
export function StoriesInvite({ placeholders = 2, on = "light" }: { placeholders?: number; on?: "light" | "dark" }) {
  const { t } = useI18n();
  const leave = LINKS.writeReview || waLink(t.stories.waMsg);
  const dark = on === "dark";
  return (
    <div className={cx("grid grid-cols-1 gap-5", placeholders > 0 && "md:grid-cols-3")}>
      <div className={cx("flex flex-col justify-between p-8", dark ? "border border-gold/40 bg-white/5" : "border border-golddeep/40 bg-[#fffdf8]")}>
        <div>
          <Quote size={28} className={dark ? "text-gold" : "text-golddeep"} aria-hidden="true" />
          <p className={cx("mt-5 font-display text-[1.65rem] leading-tight", dark ? "text-ivory" : "text-navy")}>{t.stories.emptyT}</p>
          <p className={cx("mt-3 text-[0.98rem] leading-relaxed", dark ? "text-ivory/70" : "text-stone")}>{t.stories.emptyD}</p>
        </div>
        <a href={leave} target="_blank" rel="noopener noreferrer" className={cx(dark ? btn.ivory : btn.gold, "mt-8")}>
          <span className="eyebrow">{t.stories.leave}</span>
          <Arrow />
        </a>
      </div>
      {Array.from({ length: placeholders }, (_, i) => (
        <div key={i} className="relative hidden flex-col border border-dashed border-booked/70 p-8 md:flex">
          <span className="eyebrow self-start bg-cream px-2 py-1 text-stone">{t.stories.placeholder}</span>
          <span aria-hidden="true" className="mt-6 text-[0.95rem] tracking-[0.15em] text-rule">
            ★★★★★
          </span>
          <div aria-hidden="true" className="mt-5 space-y-2.5">
            <span className="block h-3 w-full bg-cream" />
            <span className="block h-3 w-11/12 bg-cream" />
            <span className="block h-3 w-4/5 bg-cream" />
          </div>
          <p className="mt-auto pt-8 font-display text-[1rem] italic text-stone">{t.stories.placeholderD}</p>
        </div>
      ))}
    </div>
  );
}
