import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { ChevronDown, Globe, Phone, X } from "lucide-react";
import { CONTACT, telLink, waLink } from "../config";
import { LANGS, useI18n, type Lang } from "../i18n";
import { MENU, hrefOf, toneOf, type Page } from "../lib/router";
import { photo } from "../photos";
import { usePlanner } from "./Planner";
import { Arrow, EASE, Img, Mark, WhatsAppIcon, Wordmark, cx, useFocusTrap, useLockBody } from "./ui";

const PRIMARY: Page[] = ["transfers", "tours", "multi-day", "availability", "gallery", "guide"];

export function LangSelect({ on = "light", full }: { on?: "light" | "dark"; full?: boolean }) {
  const { lang, setLang, t } = useI18n();
  const cur = LANGS.find((l) => l.code === lang) ?? LANGS[0];
  return (
    <label
      className={cx(
        "relative inline-flex cursor-pointer items-center gap-1.5 border px-3 py-2.5 transition-colors duration-300 focus-within:ring-2 focus-within:ring-gold",
        on === "light" ? "border-navy/15 text-navy hover:border-navy" : "border-ivory/30 text-ivory hover:border-ivory",
      )}
    >
      <Globe size={14} aria-hidden="true" />
      <span aria-hidden="true" className="eyebrow">
        {full ? cur.label : cur.short}
      </span>
      <ChevronDown size={12} aria-hidden="true" />
      <select
        aria-label={t.nav.language}
        value={lang}
        onChange={(e) => setLang(e.target.value as Lang)}
        className="absolute inset-0 cursor-pointer opacity-0"
      >
        {LANGS.map((l) => (
          <option key={l.code} value={l.code} lang={l.locale}>
            {l.label}
          </option>
        ))}
      </select>
    </label>
  );
}

export default function Nav({ page }: { page: Page }) {
  const { t, s, lang, setLang, cap } = useI18n();
  const planner = usePlanner();
  const reduce = useReducedMotion();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [preview, setPreview] = useState(0);
  const panel = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 24);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  useEffect(() => {
    setOpen(false);
    const i = MENU.findIndex((m) => m.page === page);
    setPreview(i < 0 ? 0 : i);
  }, [page]);

  useLockBody(open);
  useFocusTrap(panel, open, () => setOpen(false));

  const solid = scrolled || page === "admin";
  const onDark = !solid && toneOf(page) === "dark";
  const pv = photo(MENU[preview]?.photo ?? MENU[0].photo);

  const skip = () => {
    const main = document.getElementById("main");
    main?.focus();
    main?.scrollIntoView();
  };

  return (
    <>
      <button
        type="button"
        onClick={skip}
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:bg-golddeep focus:px-4 focus:py-3 focus:text-ivory"
      >
        {t.nav.skip}
      </button>

      <header
        className={cx(
          "fixed inset-x-0 top-0 z-50 transition-[background-color,border-color,box-shadow] duration-700",
          solid
            ? "border-b border-rule/70 bg-ivory/88 shadow-[0_18px_40px_-40px_rgba(11,18,34,0.9)] backdrop-blur-xl"
            : onDark
              ? "border-b border-transparent bg-gradient-to-b from-night/60 to-transparent"
              : "border-b border-transparent bg-transparent",
        )}
      >
        <div className="mx-auto flex h-[72px] w-full max-w-[1440px] items-center justify-between gap-4 px-5 md:h-[84px] md:px-10">
          <a href="#/" className="flex shrink-0 items-center gap-3 transition-opacity hover:opacity-80" aria-label="Bonjour Paris Ride">
            <span className={onDark ? "text-gold" : "text-golddeep"}>
              <Mark className="h-9 w-9" />
            </span>
            <span className="hidden sm:block">
              <Wordmark on={onDark ? "dark" : "light"} />
            </span>
          </a>

          <nav aria-label="Primary" className="hidden items-center gap-7 xl:flex">
            {PRIMARY.map((pg, i) => {
              const m = MENU.find((x) => x.page === pg);
              if (!m) return null;
              const active = pg === page;
              return (
                <a
                  key={pg}
                  href={hrefOf(pg)}
                  aria-current={active ? "page" : undefined}
                  className={cx(
                    "group relative eyebrow whitespace-nowrap tracking-[0.18em] transition-colors duration-300",
                    i >= 4 && "hidden 2xl:inline",
                    onDark ? "text-ivory/85 hover:text-ivory" : "text-navy/70 hover:text-navy",
                    active && (onDark ? "text-ivory" : "text-navy"),
                  )}
                >
                  {s.nav[m.key]}
                  <span
                    aria-hidden="true"
                    className={cx(
                      "absolute -bottom-2 left-0 h-px w-full origin-left bg-gold transition-transform duration-500 group-hover:scale-x-100",
                      active ? "scale-x-100" : "scale-x-0",
                    )}
                  />
                </a>
              );
            })}
          </nav>

          <div className="flex items-center gap-2.5 md:gap-3">
            <span className="hidden md:inline-flex">
              <LangSelect on={onDark ? "dark" : "light"} />
            </span>
            <button
              type="button"
              onClick={() => planner.open()}
              className={cx(
                "group hidden items-center gap-2.5 px-5 py-3 transition-all duration-500 hover:-translate-y-0.5 sm:inline-flex",
                onDark ? "bg-ivory text-navy hover:bg-gold" : "bg-navy text-ivory hover:bg-golddeep",
              )}
            >
              <span className="eyebrow">{t.nav.book}</span>
              <Arrow />
            </button>
            <button
              type="button"
              onClick={() => setOpen(true)}
              aria-expanded={open}
              aria-controls="site-menu"
              className={cx(
                "group inline-flex h-11 items-center gap-3 border px-3.5 transition-colors",
                onDark ? "border-ivory/40 text-ivory hover:bg-ivory/10" : "border-navy/20 text-navy hover:border-navy",
              )}
            >
              <span className="flex flex-col gap-[5px]" aria-hidden="true">
                <span className="block h-px w-5 bg-current" />
                <span className="block h-px w-3.5 bg-current transition-all duration-300 group-hover:w-5" />
              </span>
              <span className="eyebrow">{s.nav.menu}</span>
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            ref={panel}
            id="site-menu"
            role="dialog"
            aria-modal="true"
            aria-label={s.nav.menu}
            className="fixed inset-0 z-[60] flex bg-night text-ivory"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35 }}
          >
            <div className="flex w-full flex-col overflow-y-auto lg:w-[56%]">
              <div className="flex items-center justify-between px-6 py-5 md:px-12 md:py-6">
                <a href="#/" onClick={() => setOpen(false)} className="flex items-center gap-3">
                  <span className="text-gold">
                    <Mark className="h-9 w-9" />
                  </span>
                  <Wordmark on="dark" />
                </a>
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  aria-label={s.nav.close}
                  className="flex h-11 w-11 items-center justify-center rounded-full border border-ivory/25 transition-all duration-300 hover:rotate-90 hover:bg-ivory hover:text-navy"
                >
                  <X size={18} aria-hidden="true" />
                </button>
              </div>

              <nav aria-label={s.nav.menu} className="flex-1 px-6 md:px-12">
                <p className="eyebrow mb-4 text-gold/80">{s.nav.tagline}</p>
                <ol className="grid grid-cols-1 gap-x-10 sm:grid-cols-2 lg:grid-cols-1">
                  {MENU.map((m, i) => (
                    <motion.li
                      key={m.page}
                      initial={reduce ? { opacity: 0 } : { opacity: 0, x: -16 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.05 + i * 0.035, duration: 0.5, ease: EASE }}
                    >
                      <a
                        href={hrefOf(m.page)}
                        onClick={() => setOpen(false)}
                        onMouseEnter={() => setPreview(i)}
                        onFocus={() => setPreview(i)}
                        aria-current={m.page === page ? "page" : undefined}
                        className="group flex items-baseline gap-5 border-b border-ivory/10 py-3 md:py-3.5"
                      >
                        <span className="eyebrow num w-6 shrink-0 text-gold/70">{String(i + 1).padStart(2, "0")}</span>
                        <span
                          className={cx(
                            "display text-[1.7rem] leading-tight transition-colors duration-300 group-hover:text-gold md:text-[2.1rem]",
                            m.page === page && "italic text-gold",
                          )}
                        >
                          {s.nav[m.key]}
                        </span>
                        <span
                          aria-hidden="true"
                          className="ml-auto -translate-x-1.5 text-gold opacity-0 transition-all duration-300 group-hover:translate-x-0 group-hover:opacity-100"
                        >
                          →
                        </span>
                      </a>
                    </motion.li>
                  ))}
                </ol>
              </nav>

              <div className="mt-8 grid gap-6 border-t border-ivory/10 px-6 py-7 md:grid-cols-2 md:px-12">
                <div>
                  <p className="eyebrow text-ivory/50">{t.nav.language}</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {LANGS.map((l) => (
                      <button
                        key={l.code}
                        type="button"
                        lang={l.locale}
                        aria-pressed={lang === l.code}
                        onClick={() => setLang(l.code)}
                        className={cx(
                          "border px-3 py-2 text-[0.82rem] transition-colors",
                          lang === l.code ? "border-gold bg-gold text-night" : "border-ivory/20 text-ivory hover:border-ivory",
                        )}
                      >
                        {l.short}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex flex-col gap-2.5">
                  <a
                    href={waLink(t.contact.waMsg)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2.5 text-ivory transition-colors hover:text-gold"
                  >
                    <WhatsAppIcon className="h-4 w-4" />
                    <span className="num">{CONTACT.phoneDisplay}</span>
                  </a>
                  <a href={telLink} className="inline-flex items-center gap-2.5 text-ivory/80 transition-colors hover:text-gold">
                    <Phone size={15} aria-hidden="true" />
                    <span className="eyebrow">{t.common.call}</span>
                  </a>
                  <button
                    type="button"
                    onClick={() => {
                      setOpen(false);
                      planner.open();
                    }}
                    className="group mt-2 inline-flex w-fit items-center gap-3 bg-gold px-5 py-3 text-night transition-colors hover:bg-ivory"
                  >
                    <span className="eyebrow">{t.nav.book}</span>
                    <Arrow />
                  </button>
                </div>
              </div>
            </div>

            <div className="relative hidden flex-1 overflow-hidden lg:block">
              <AnimatePresence initial={false}>
                <motion.div
                  key={pv.id}
                  className="absolute inset-0"
                  initial={reduce ? { opacity: 0 } : { opacity: 0, scale: 1.06 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.8, ease: EASE }}
                >
                  <Img photo={pv} alt="" sizes="44vw" className="h-full w-full object-cover" />
                </motion.div>
              </AnimatePresence>
              <div className="absolute inset-0 bg-[linear-gradient(90deg,#0b1222,rgba(11,18,34,0.1)_40%)]" />
              <p className="absolute bottom-8 left-10 right-10 font-display text-[1.15rem] italic text-ivory/85">— {cap(pv.key)}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
