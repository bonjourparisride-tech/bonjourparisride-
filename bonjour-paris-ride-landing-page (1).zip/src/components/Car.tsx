import { CAR_FILES_ARE_REAL_PHOTOS } from "../assets";
import { useI18n } from "../i18n";
import { CAR_GRADE, usePublicContent, type CarSlot } from "../lib/store";
import { photo } from "../photos";
import { Img, Tag, cx } from "./ui";

/* Your Toyota C-HR: real photos uploaded in the Owner area are shown first
   ("Photo of our car"); otherwise a clearly labelled illustration of the model. */

const FALLBACK: Record<CarSlot, string> = {
  front: "chr",
  side: "carSide",
  interior: "interior",
  luggage: "carLuggage",
};

export function CarImage({
  slot,
  className,
  sizes = "(min-width:1024px) 50vw, 100vw",
  eager,
  tag = "top",
}: {
  slot: CarSlot;
  className?: string;
  sizes?: string;
  eager?: boolean;
  tag?: "top" | "bottom" | false;
}) {
  const { s, cap } = useI18n();
  const { car } = usePublicContent();
  const upload = car[slot];
  const fb = photo(FALLBACK[slot]);
  const isReal = Boolean(upload) || CAR_FILES_ARE_REAL_PHOTOS;
  return (
    <div className={cx("relative h-full w-full overflow-hidden bg-cream", className)}>
      {upload ? (
        <>
          <img
            src={upload.src}
            alt={`${s.common.ourCar} — ${s.about.slots[slot]}`}
            loading={eager ? "eager" : "lazy"}
            decoding="async"
            style={{ objectPosition: upload.pos, filter: upload.grade ? CAR_GRADE : undefined }}
            className="h-full w-full object-cover"
          />
          {upload.grade && (
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 bg-[radial-gradient(120%_90%_at_50%_35%,transparent_55%,rgba(11,18,34,0.28))]"
            />
          )}
        </>
      ) : (
        <Img
          photo={fb}
          alt={isReal ? `${s.common.ourCar} — ${s.about.slots[slot]}` : `${cap(fb.key)} — ${s.common.illustrationLong}`}
          sizes={sizes}
          eager={eager}
          className="h-full w-full object-cover"
        />
      )}
      {tag && (
        <span className={cx("absolute left-3 z-10", tag === "top" ? "top-3" : "bottom-3")}>
          <Tag
            kind={isReal ? "real" : "ai"}
            label={isReal ? s.common.ourCar : s.common.illustration}
            title={isReal ? undefined : s.common.illustrationLong}
          />
        </span>
      )}
    </div>
  );
}

/** Boot diagram: exactly 2 large suitcases + 2 cabin bags. */
export function LuggageDiagram({ className, on = "light" }: { className?: string; on?: "light" | "dark" }) {
  const { s } = useI18n();
  const dark = on === "dark";
  return (
    <figure className={className}>
      <svg viewBox="0 0 320 206" role="img" aria-label={s.car.capacity} className="w-full">
        <path
          d="M28 46c0-16 10-26 26-26h212c16 0 26 10 26 26v122c0 12-9 20-21 20H49c-12 0-21-8-21-20Z"
          className={dark ? "fill-white/5 stroke-gold/70" : "fill-ivory stroke-navy"}
          strokeWidth="2"
        />
        <path d="M46 32h228" className={dark ? "stroke-gold/40" : "stroke-rule"} strokeWidth="5" strokeLinecap="round" />
        {[46, 162].map((x) => (
          <g key={`l${x}`}>
            <rect x={x + 41} y={110} width={30} height={10} rx={4} className="fill-none stroke-golddeep" strokeWidth="3" />
            <rect x={x} y={118} width={112} height={58} rx={9} className="fill-golddeep" />
            <path d={`M${x + 16} 118v58M${x + 96} 118v58`} className="stroke-ivory/35" strokeWidth="2" />
          </g>
        ))}
        {[68, 170].map((x) => (
          <g key={`c${x}`}>
            <rect x={x + 29} y={62} width={24} height={9} rx={4} className={cx("fill-none", dark ? "stroke-ivory" : "stroke-navy")} strokeWidth="3" />
            <rect x={x} y={69} width={82} height={40} rx={8} className={dark ? "fill-ivory" : "fill-navy"} />
            <path d={`M${x + 12} 69v40M${x + 70} 69v40`} className={dark ? "stroke-navy/20" : "stroke-ivory/25"} strokeWidth="2" />
          </g>
        ))}
      </svg>
      <figcaption className="mt-5 grid grid-cols-2 gap-4 text-center">
        <span>
          <span className="display num block text-[2.6rem] leading-none text-golddeep">2</span>
          <span className={cx("eyebrow mt-2 block", dark ? "text-ivory/70" : "text-stone")}>{s.car.large}</span>
        </span>
        <span>
          <span className={cx("display num block text-[2.6rem] leading-none", dark ? "text-ivory" : "text-navy")}>2</span>
          <span className={cx("eyebrow mt-2 block", dark ? "text-ivory/70" : "text-stone")}>{s.car.cabin}</span>
        </span>
      </figcaption>
    </figure>
  );
}
