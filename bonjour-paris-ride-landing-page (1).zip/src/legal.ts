import { CONTACT, POLICIES } from "./config";

/* Legal page templates (English + French). Items in [brackets] must be
   completed by the business owner — ideally reviewed by a professional. */

export type LegalDoc = "notice" | "privacy" | "terms";
export interface Doc {
  title: string;
  intro?: string;
  sections: { h: string; p: string[] }[];
}

const W = POLICIES.freeWaitingMinutes;
const C = POLICIES.freeCancellationHours;
const T = "[to complete]";
const F = "[à compléter]";

export const LEGAL: Record<"en" | "fr", Record<LegalDoc, Doc>> = {
  en: {
    notice: {
      title: "Legal notice",
      intro: "Template — complete the bracketed items before publishing.",
      sections: [
        {
          h: "Publisher",
          p: [
            `Bonjour Paris Ride — ${T} (legal name and company form).`,
            `Registered address: ${T}. SIRET: ${T}. VAT number: ${T}.`,
            `VTC operator registration number: ${T}.`,
            `Contact: ${CONTACT.email} · ${CONTACT.phoneDisplay}. Publication director: ${T}.`,
          ],
        },
        { h: "Hosting", p: [`${T} (host name, address and phone number).`] },
        {
          h: "Photography and trademarks",
          p: [
            "Paris photographs come from Pexels and are used under the Pexels licence. Images of the car are illustrative.",
            "Disneyland® Paris is a trademark of its owner. Bonjour Paris Ride is an independent transport service and is not affiliated with Disney.",
          ],
        },
      ],
    },
    privacy: {
      title: "Privacy policy",
      sections: [
        { h: "Who is responsible", p: ["Bonjour Paris Ride (see the legal notice) is responsible for the personal data you send through this website."] },
        { h: "What we collect", p: ["Only what you choose to send: your name, email address, phone or WhatsApp number, and the details of your journey (dates, addresses, flight number, passengers, luggage and requests)."] },
        { h: "Why", p: ["To answer your request, prepare a quotation and carry out the journey you book (pre-contractual and contractual measures — Article 6(1)(b) GDPR)."] },
        { h: "Who receives it", p: ["Only us. If you send your request by WhatsApp or email, those providers carry the message. If an online form service is configured, it processes your request on our behalf. We never sell your data."] },
        { h: "How long we keep it", p: ["Requests that do not lead to a booking are deleted within 12 months. Booking and invoicing records are kept for the period required by French accounting law."] },
        { h: "Your rights", p: [`You can access, correct, delete or export your data, or object to its use, by writing to ${CONTACT.email}. You may also lodge a complaint with the CNIL (www.cnil.fr).`] },
        { h: "Cookies and local storage", p: ["We use no advertising or tracking cookies. Your browser remembers your language choice. In demonstration mode, a request you prepare may be kept in your own browser until you send it."] },
      ],
    },
    terms: {
      title: "Terms of service",
      intro: "Template — complete and review before publishing.",
      sections: [
        { h: "Requests and confirmation", p: ["A request sent through this website, by WhatsApp or by email is not a booking. A journey is confirmed only when we reply in writing. Availability shown in the calendar is indicative."] },
        { h: "Prices", p: ["Published prices are in euros, per vehicle, for up to 4 passengers, and include tolls, parking and waiting time as described. Other journeys, full days, Disneyland Paris and multi-day tours are priced by personalized quotation."] },
        { h: "Payment", p: ["Payment is made at the end of the journey by card or cash, unless otherwise agreed in the quotation."] },
        { h: "Cancellation and changes", p: [`Free of charge up to ${C} hours before pickup. Later cancellations: ${T}.`] },
        { h: "Waiting time", p: [`Airport pickups include ${W} minutes of free waiting after landing. Beyond that: ${T}.`] },
        { h: "Passengers and luggage", p: ["Maximum 4 passengers. Luggage capacity depends on the number of passengers (see FAQ). Children travel in a suitable child seat, provided free of charge on request."] },
        { h: "Multi-day tours", p: ["Each quotation lists exactly what is included. Accommodation, attraction tickets, meals, parking and other expenses are not included unless explicitly agreed. Itineraries respect driving-time and rest rules."] },
        { h: "Applicable law", p: [`French law applies. Consumer mediation: ${T}.`] },
      ],
    },
  },
  fr: {
    notice: {
      title: "Mentions légales",
      intro: "Modèle — complétez les éléments entre crochets avant publication.",
      sections: [
        {
          h: "Éditeur",
          p: [
            `Bonjour Paris Ride — ${F} (dénomination et forme juridique).`,
            `Adresse : ${F}. SIRET : ${F}. N° de TVA : ${F}.`,
            `N° d'inscription au registre des exploitants VTC : ${F}.`,
            `Contact : ${CONTACT.email} · ${CONTACT.phoneDisplay}. Directeur de la publication : ${F}.`,
          ],
        },
        { h: "Hébergement", p: [`${F} (nom, adresse et téléphone de l'hébergeur).`] },
        {
          h: "Photographies et marques",
          p: [
            "Les photographies de Paris proviennent de Pexels et sont utilisées selon la licence Pexels. Les images de la voiture sont des illustrations.",
            "Disneyland® Paris est une marque de son propriétaire. Bonjour Paris Ride est un service de transport indépendant, sans lien avec Disney.",
          ],
        },
      ],
    },
    privacy: {
      title: "Politique de confidentialité",
      sections: [
        { h: "Responsable du traitement", p: ["Bonjour Paris Ride (voir les mentions légales) est responsable des données personnelles que vous transmettez via ce site."] },
        { h: "Données collectées", p: ["Uniquement ce que vous choisissez d'envoyer : nom, adresse e-mail, numéro de téléphone ou WhatsApp, et les détails de votre trajet (dates, adresses, numéro de vol, passagers, bagages et demandes)."] },
        { h: "Finalités", p: ["Répondre à votre demande, établir un devis et réaliser le trajet réservé (mesures précontractuelles et contractuelles — article 6.1.b du RGPD)."] },
        { h: "Destinataires", p: ["Nous seuls. Si vous envoyez votre demande par WhatsApp ou par e-mail, ces prestataires acheminent le message. Si un service de formulaire en ligne est configuré, il traite votre demande pour notre compte. Vos données ne sont jamais vendues."] },
        { h: "Durée de conservation", p: ["Les demandes non suivies de réservation sont supprimées sous 12 mois. Les éléments de réservation et de facturation sont conservés pendant la durée imposée par la loi comptable française."] },
        { h: "Vos droits", p: [`Vous pouvez accéder à vos données, les rectifier, les supprimer, les exporter ou vous opposer à leur utilisation en écrivant à ${CONTACT.email}. Vous pouvez aussi saisir la CNIL (www.cnil.fr).`] },
        { h: "Cookies et stockage local", p: ["Aucun cookie publicitaire ni de suivi. Votre navigateur mémorise votre choix de langue. En mode démonstration, une demande préparée peut être conservée dans votre propre navigateur jusqu'à son envoi."] },
      ],
    },
    terms: {
      title: "Conditions générales",
      intro: "Modèle — à compléter et à faire relire avant publication.",
      sections: [
        { h: "Demandes et confirmation", p: ["Une demande envoyée via ce site, par WhatsApp ou par e-mail n'est pas une réservation. Un trajet n'est confirmé qu'après notre réponse écrite. Les disponibilités du calendrier sont indicatives."] },
        { h: "Prix", p: ["Les prix publiés s'entendent en euros, par véhicule, jusqu'à 4 passagers, péages, stationnement et temps d'attente inclus selon la description. Les autres trajets, journées complètes, Disneyland Paris et circuits multi-jours font l'objet d'un devis personnalisé."] },
        { h: "Paiement", p: ["Le paiement s'effectue en fin de trajet, par carte ou en espèces, sauf accord différent dans le devis."] },
        { h: "Annulation et modification", p: [`Gratuites jusqu'à ${C} heures avant la prise en charge. Annulations plus tardives : ${F}.`] },
        { h: "Temps d'attente", p: [`Les prises en charge à l'aéroport incluent ${W} minutes d'attente offertes après l'atterrissage. Au-delà : ${F}.`] },
        { h: "Passagers et bagages", p: ["4 passagers maximum. La capacité de bagages dépend du nombre de passagers (voir la FAQ). Les enfants voyagent dans un siège adapté, fourni gratuitement sur demande."] },
        { h: "Circuits multi-jours", p: ["Chaque devis précise exactement ce qui est inclus. L'hébergement, les billets, les repas, le stationnement et les autres frais ne sont pas inclus sauf accord explicite. Les itinéraires respectent les temps de conduite et de repos."] },
        { h: "Droit applicable", p: [`Droit français. Médiation de la consommation : ${F}.`] },
      ],
    },
  },
};
