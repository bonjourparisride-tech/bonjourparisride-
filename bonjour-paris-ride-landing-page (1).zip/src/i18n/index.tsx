import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import en, { type Dict } from "./en";
import fr from "./fr";
import es from "./es";
import pt from "./pt";
import de from "./de";
import it from "./it";
import zh from "./zh";
import siteEn, { type Site } from "./site/en";
import siteFr from "./site/fr";
import siteEs from "./site/es";
import sitePt from "./site/pt";
import siteDe from "./site/de";
import siteIt from "./site/it";
import siteZh from "./site/zh";
import { parseISO } from "../lib/availability";
import type { PricedService } from "../config";

export const LANGS = [
  { code: "en", label: "English", short: "EN", locale: "en-GB" },
  { code: "fr", label: "Français", short: "FR", locale: "fr-FR" },
  { code: "es", label: "Español", short: "ES", locale: "es-ES" },
  { code: "pt", label: "Português", short: "PT", locale: "pt-BR" },
  { code: "de", label: "Deutsch", short: "DE", locale: "de-DE" },
  { code: "it", label: "Italiano", short: "IT", locale: "it-IT" },
  { code: "zh", label: "简体中文", short: "中文", locale: "zh-CN" },
] as const;

export type Lang = (typeof LANGS)[number]["code"];

/** t — interface, booking & legacy texts · s — page and brand texts */
export const DICTS: Record<Lang, Dict> = { en, fr, es, pt, de, it, zh };
export const SITES: Record<Lang, Site> = {
  en: siteEn,
  fr: siteFr,
  es: siteEs,
  pt: sitePt,
  de: siteDe,
  it: siteIt,
  zh: siteZh,
};

const KEY = "bpr-lang";
const isLang = (v: unknown): v is Lang => LANGS.some((l) => l.code === v);

function detect(): Lang {
  try {
    const q = new URLSearchParams(window.location.search).get("lang");
    if (isLang(q)) return q;
    const saved = window.localStorage.getItem(KEY);
    if (isLang(saved)) return saved;
  } catch {
    /* storage unavailable */
  }
  const prefs = navigator.languages?.length ? navigator.languages : [navigator.language];
  for (const p of prefs) {
    const code = (p || "").toLowerCase().slice(0, 2);
    if (isLang(code)) return code;
  }
  return "en";
}

export type DateStyle = "long" | "medium" | "short";

interface I18n {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: Dict;
  s: Site;
  /** photo caption in the current language */
  cap: (key: string) => string;
  locale: string;
  price: (n: number | null) => string;
  date: (iso: string, style?: DateStyle) => string;
  month: (year: number, month: number) => string;
  weekdays: string[];
}

const Ctx = createContext<I18n | null>(null);

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(detect);
  const meta = LANGS.find((l) => l.code === lang) ?? LANGS[0];
  const t = DICTS[lang];
  const s = SITES[lang];

  useEffect(() => {
    document.documentElement.lang = meta.locale;
    document.querySelector('meta[name="description"]')?.setAttribute("content", t.meta.description);
  }, [meta.locale, t]);

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    try {
      window.localStorage.setItem(KEY, l);
    } catch {
      /* ignore */
    }
    try {
      // keep the current page (hash) and make the language shareable
      const url = new URL(window.location.href);
      url.searchParams.set("lang", l);
      window.history.replaceState(window.history.state, "", url.toString());
    } catch {
      /* ignore */
    }
  }, []);

  const value = useMemo<I18n>(() => {
    const loc = meta.locale;
    const nf = new Intl.NumberFormat(loc, {
      style: "currency",
      currency: "EUR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    });
    const dfs: Record<DateStyle, Intl.DateTimeFormat> = {
      long: new Intl.DateTimeFormat(loc, { weekday: "long", day: "numeric", month: "long", year: "numeric" }),
      medium: new Intl.DateTimeFormat(loc, { weekday: "short", day: "numeric", month: "short", year: "numeric" }),
      short: new Intl.DateTimeFormat(loc, { day: "numeric", month: "short" }),
    };
    const mf = new Intl.DateTimeFormat(loc, { month: "long", year: "numeric" });
    const wf = new Intl.DateTimeFormat(loc, { weekday: "short" });
    const capFirst = (x: string) => x.charAt(0).toLocaleUpperCase(loc) + x.slice(1);
    const sitePhotos = s.photos as Record<string, string>;
    const uiPhotos = t.photos as Record<string, string>;
    return {
      lang,
      setLang,
      t,
      s,
      cap: (key) => sitePhotos[key] ?? uiPhotos[key] ?? "",
      locale: loc,
      price: (n) => (n === null ? t.common.onRequest : nf.format(n)),
      date: (iso, style = "long") => capFirst(dfs[style].format(parseISO(iso))),
      month: (y, m) => capFirst(mf.format(new Date(y, m, 1, 12))),
      // 1 January 2023 was a Sunday → Sunday-first week
      weekdays: Array.from({ length: 7 }, (_, i) => wf.format(new Date(2023, 0, 1 + i, 12))),
    };
  }, [lang, meta.locale, setLang, t, s]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useI18n() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useI18n must be used inside <LangProvider>");
  return v;
}

/** Label + detail of a priced option, in the current language. */
export function optText(t: Dict, service: PricedService, id?: string) {
  const group = t.opt[service] as Record<string, { l: string; d: string }>;
  return id ? group[id] : undefined;
}
