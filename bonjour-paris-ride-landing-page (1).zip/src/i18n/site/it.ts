import type { Site } from "./en";

const site: Site = {
  nav: {
    home: "Home",
    transfers: "Transfer aeroportuali",
    tours: "Tour giornalieri",
    multiday: "Tour di più giorni",
    availability: "Disponibilità",
    custom: "Tour su misura",
    gallery: "Galleria",
    reviews: "Recensioni",
    guide: "Guida di viaggio",
    about: "Chi siamo",
    faq: "FAQ",
    contact: "Contatti",
    menu: "Menu",
    close: "Chiudi",
    tagline: "Autista privato · Parigi e dintorni",
  },
  common: {
    next: "Pagina successiva",
    discover: "Scopri",
    readGuide: "Leggi la guida di viaggio",
    illustration: "Illustrazione",
    illustrationLong: "Illustrazione — non è una foto della nostra auto",
    ourCar: "Foto della nostra auto",
    chapter: (n: string) => `Capitolo ${n}`,
    closingLine: "Bon voyage.",
  },
  photos: {
    eiffelLights: "La Torre Eiffel al crepuscolo",
    giverny: "I giardini di Claude Monet a Giverny",
    fontainebleau: "Il castello di Fontainebleau",
    village: "Un villaggio francese fiorito",
    rooftops: "I tetti di Parigi",
    arc: "L'Arco di Trionfo al crepuscolo",
    versaillesGold: "Statue dorate nei giardini di Versailles",
    croissant: "Caffè e croissant in un caffè parigino",
    terrace: "La terrazza di un caffè parigino",
    chr: "La Toyota C-HR in una strada di Parigi",
    chrAirport: "La Toyota C-HR durante un prelievo in aeroporto",
    interior: "L'interno della Toyota C-HR",
    carSide: "La Toyota C-HR di profilo",
    carLuggage: "Il bagagliaio della Toyota C-HR",
  },
  home: {
    doorsEyebrow: "I nostri viaggi",
    doorsTitle: "Tre modi per *viaggiare bene.*",
    doors: {
      transfers: "Da CDG, Orly e Beauvais fino alla tua porta, a prezzo fisso a veicolo.",
      tours: "Visite private a Parigi, a Versailles e a Disneyland Paris.",
      multiday: "Soggiorni lunghi e itinerari personali, con un preventivo fatto per te.",
    },
    carEyebrow: "La tua auto",
    carTitle: "Una *Toyota C-HR* moderna e silenziosa.",
    carText:
      "Un'ibrida del 2024 impeccabile per un massimo di 4 passeggeri, con spazio per 2 valigie grandi e 2 bagagli a mano.",
    carCta: "Scopri l'auto",
    availTitle: "Le tue date, *confermate di persona.*",
    availText:
      "Consulta il calendario, scegli una data e raccontaci il tuo viaggio. Rispondiamo su WhatsApp o via email.",
  },
  transfers: {
    board: "Partenze",
    cols: ["Aeroporto", "Durata", "Prezzo a veicolo"],
    stepsEyebrow: "Come funziona",
    stepsTitle: "Il tuo arrivo, *passo dopo passo.*",
    steps: [
      { t: "Prenoti in pochi minuti", d: "Inviaci i dati del volo: confermiamo su WhatsApp o via email." },
      { t: "Seguiamo il tuo volo", d: "Monitoriamo i ritardi e adattiamo l'orario di prelievo per te." },
      { t: "Accoglienza agli arrivi", d: "Il tuo autista ti aspetta con un cartello con il tuo nome e ti aiuta con i bagagli." },
      { t: "Fino alla tua porta", d: "Un tragitto privato e tranquillo fino al tuo hotel, al prezzo concordato." },
    ],
    luggageEyebrow: "Spazio a bordo",
    luggageTitle: "Spazio per te *e i tuoi bagagli.*",
    luggageText:
      "La nostra Toyota C-HR ospita fino a 4 passeggeri con 2 valigie grandi e 2 bagagli a mano. Viaggi con più bagagli? Chiedici prima: ti diremo con sincerità cosa entra.",
  },
  tours: {
    stops: "Le tappe del percorso",
    fullT: "Parigi a modo tuo",
    fullD:
      "Una giornata intera costruita sui tuoi desideri: musei, mercati, belvedere o un lungo pranzo. Preventivo personalizzato.",
  },
  custom: {
    ideasEyebrow: "Idee per ispirarti",
    ideasTitle: "Oltre i *percorsi classici.*",
    ideas: [
      { t: "La Giverny di Monet", d: "La casa e i giardini del pittore, a circa 75 minuti da Parigi, aperti dalla primavera all'autunno." },
      { t: "Fontainebleau", d: "Un castello reale e la sua grande foresta, a circa 70 minuti a sud di Parigi." },
      { t: "Belvedere e soste fotografiche", d: "Le inquadrature più belle della Torre Eiffel, della Senna e di Montmartre." },
      { t: "Una serata romantica", d: "La città illuminata per un anniversario o un'occasione speciale." },
    ],
  },
  about: {
    eyebrow: "Chi siamo",
    title: "Un piccolo servizio parigino, *fatto con cura.*",
    sub: "Bonjour Paris Ride è un servizio personale: un'auto comoda e un autista, dal tuo primo messaggio all'ultima tappa.",
    storyT: "Personale per scelta",
    story: [
      "Quando ci scrivi, parli direttamente con la persona che ti accompagnerà: niente call center, niente app, nessuna sorpresa.",
      "Facciamo le cose in modo semplice: prezzi chiari sui percorsi pubblicati, consigli onesti su orari e bagagli e un'auto pulita e silenziosa.",
    ],
    values: [
      { t: "Puntuale", d: "I voli vengono monitorati e i prelievi pianificati con margine." },
      { t: "Trasparente", d: "Prezzi fissi a veicolo sui percorsi pubblicati, confermati per iscritto." },
      { t: "Attento", d: "Acqua, caricatori, seggiolino su richiesta e aiuto con i bagagli." },
      { t: "Flessibile", d: "Soste fotografiche e deviazioni, al ritmo che preferisci." },
    ],
    carEyebrow: "L'auto",
    carTitle: "Ecco la nostra *Toyota C-HR.*",
    carSub: "Un'ibrida autoricaricabile del 2024: silenziosa, comoda e pulita prima di ogni tragitto.",
    slots: { front: "Anteriore", side: "Profilo", interior: "Interni", luggage: "Bagagliaio" },
    note: "Le immagini contrassegnate come «Illustrazione» sono rappresentazioni artistiche del modello, non foto della nostra auto.",
  },
  car: {
    capacity: "Fino a 4 passeggeri · 2 valigie grandi + 2 bagagli a mano",
    large: "valigie grandi",
    cabin: "bagagli a mano",
  },
  contact: {
    formT: "Inviaci un *messaggio*",
    message: "Il tuo messaggio",
    messagePh: "Date, luoghi, domande…",
    send: "Invia il messaggio",
    sentT: "Grazie!",
    sentD: "Il tuo messaggio è stato inviato. Ti risponderemo il prima possibile.",
    readyD: "Il tuo messaggio è pronto: inviacelo su WhatsApp o via email.",
    subject: "Messaggio dal sito",
  },
  guide: {
    eyebrow: "Guida di viaggio",
    title: "La *guida* di Parigi.",
    sub: "Consigli pratici dalla strada, per organizzarti, evitare le code e goderti ogni ora a Parigi.",
    edition: (y: number) => `Edizione ${y}`,
    contents: "Sommario",
    chapters: [
      {
        t: "Arrivare a Parigi",
        d: "Tre aeroporti servono la città. Ecco cosa aspettarti.",
        tips: [
          "Charles de Gaulle (CDG) dista circa 45–60 minuti in auto dal centro; Orly (ORY) circa 30–45 minuti.",
          "Beauvais (BVA), usato dalle compagnie low cost, dista circa 85 km: calcola 75–90 minuti.",
          "Tieni l'indirizzo dell'hotel per iscritto e il telefono carico per WhatsApp.",
        ],
      },
      {
        t: "La Torre Eiffel",
        d: "Il simbolo di Parigi, più bello visto da un po' di distanza.",
        tips: [
          "Per la vista classica, attraversa la Senna fino ai giardini del Trocadéro.",
          "Dopo il tramonto, la torre scintilla per cinque minuti all'inizio di ogni ora.",
          "Lo Champ-de-Mars e il ponte di Bir-Hakeim offrono scorci più tranquilli.",
        ],
      },
      {
        t: "Montmartre e il Sacré-Cœur",
        d: "Viuzze da villaggio e il panorama più bello sulla città.",
        tips: [
          "Vieni la mattina presto per goderti scalinate e vista in tranquillità.",
          "L'ingresso alla basilica del Sacré-Cœur è gratuito; la cupola è a pagamento.",
          "Le strade sono ripide e strette: ti lasciamo il più vicino possibile alla cima.",
        ],
      },
      {
        t: "Il Louvre",
        d: "Il museo più visitato al mondo merita un piano.",
        tips: [
          "Il museo è chiuso il martedì.",
          "Prenota online un biglietto con orario per evitare le code più lunghe.",
          "La piramide di vetro dà il meglio di sé al tramonto.",
        ],
      },
      {
        t: "Versailles",
        d: "Una giornata da re, a 40 minuti da Parigi.",
        tips: [
          "La reggia è chiusa il lunedì.",
          "Prevedi almeno mezza giornata: i giardini da soli meritano una lunga passeggiata.",
          "In alcuni giorni della stagione, i giardini ospitano spettacoli di fontane.",
        ],
      },
      {
        t: "Disneyland Paris",
        d: "Un classico per famiglie, a est della città.",
        tips: [
          "I parchi distano circa 50 minuti in auto dal centro di Parigi.",
          "Arriva prima dell'apertura per sfruttare al meglio la giornata.",
          "I seggiolini per bambini sono gratuiti su richiesta: indicaci solo l'età dei bambini.",
        ],
      },
      {
        t: "Oltre Parigi",
        d: "Villaggi, giardini e castelli a portata di mano.",
        tips: [
          "Giverny: la casa e i giardini di Claude Monet sono aperti dalla primavera all'autunno.",
          "Fontainebleau: un castello reale circondato da una vasta foresta.",
          "Le gite fuori città hanno un preventivo dedicato, con il tempo di attesa concordato in anticipo.",
        ],
      },
      {
        t: "Buono a sapersi",
        d: "Piccole abitudini che fanno una grande differenza.",
        tips: [
          "Saluta con un «Bonjour» quando entri in un negozio o in un caffè: è importante.",
          "Il servizio è incluso nel conto del ristorante; una piccola mancia è un gesto gentile, mai un obbligo.",
          "Molti musei chiudono un giorno alla settimana: controlla prima di andare.",
        ],
      },
    ],
    distT: "Distanze dal *centro di Parigi*",
    distNote: "Distanze stradali approssimative e tempi di percorrenza abituali fuori dalle ore di punta.",
  },
  faq: {
    groups: ["Prenotazione e pagamento", "Aeroporti e auto", "Tour e gruppi"],
    search: "Cerca tra le domande",
    none: "Nessuna domanda corrisponde alla tua ricerca.",
    stillT: "Hai ancora una domanda?",
    stillD: "Scrivici: rispondiamo in inglese e francese.",
  },
  avail: {
    how: [
      "Scegli una data disponibile nel calendario.",
      "Raccontaci il tragitto e i passeggeri.",
      "Confermiamo di persona, su WhatsApp o via email.",
    ],
    legend: {
      available: "Libera per nuovi tragitti.",
      limited: "Alcuni tragitti sono già previsti: chiedi per il tuo orario.",
      booked: "Al completo o non disponibile.",
    },
  },
};

export default site;
