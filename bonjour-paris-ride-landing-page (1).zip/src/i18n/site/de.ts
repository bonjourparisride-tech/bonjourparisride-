import type { Site } from "./en";

const site: Site = {
  nav: {
    home: "Start",
    transfers: "Flughafentransfers",
    tours: "Tagestouren",
    multiday: "Mehrtagestouren",
    availability: "Verfügbarkeit",
    custom: "Individuelle Touren",
    gallery: "Galerie",
    reviews: "Bewertungen",
    guide: "Reiseführer",
    about: "Über uns",
    faq: "FAQ",
    contact: "Kontakt",
    menu: "Menü",
    close: "Schließen",
    tagline: "Privatfahrer · Paris und Umgebung",
  },
  common: {
    next: "Nächste Seite",
    discover: "Entdecken",
    readGuide: "Zum Reiseführer",
    illustration: "Illustration",
    illustrationLong: "Illustration — kein Foto unseres Autos",
    ourCar: "Foto unseres Autos",
    chapter: (n: string) => `Kapitel ${n}`,
    closingLine: "Bon voyage.",
  },
  photos: {
    eiffelLights: "Der Eiffelturm in der Abenddämmerung",
    giverny: "Claude Monets Gärten in Giverny",
    fontainebleau: "Das Schloss Fontainebleau",
    village: "Ein blumengeschmücktes französisches Dorf",
    rooftops: "Die Dächer von Paris",
    arc: "Der Arc de Triomphe in der Abenddämmerung",
    versaillesGold: "Goldene Statuen in den Gärten von Versailles",
    croissant: "Kaffee und Croissants in einem Pariser Café",
    terrace: "Eine Pariser Caféterrasse",
    chr: "Der Toyota C-HR in einer Pariser Straße",
    chrAirport: "Der Toyota C-HR bei einer Abholung am Flughafen",
    interior: "Im Innenraum des Toyota C-HR",
    carSide: "Der Toyota C-HR im Profil",
    carLuggage: "Der Kofferraum des Toyota C-HR",
  },
  home: {
    doorsEyebrow: "Unsere Reisen",
    doorsTitle: "Drei Arten, *gut zu reisen.*",
    doors: {
      transfers: "Von CDG, Orly und Beauvais bis vor Ihre Tür — zum Festpreis pro Fahrzeug.",
      tours: "Private Besichtigungen in Paris, in Versailles und im Disneyland Paris.",
      multiday: "Längere Aufenthalte und persönliche Routen, mit einem Angebot nur für Sie.",
    },
    carEyebrow: "Ihr Auto",
    carTitle: "Ein leiser, moderner *Toyota C-HR.*",
    carText:
      "Ein gepflegter Hybrid von 2024 für bis zu 4 Fahrgäste, mit Platz für 2 große Koffer und 2 Handgepäckstücke.",
    carCta: "Das Auto entdecken",
    availTitle: "Ihre Termine, *persönlich bestätigt.*",
    availText:
      "Sehen Sie in den Kalender, wählen Sie ein Datum und erzählen Sie uns von Ihrer Reise. Wir antworten per WhatsApp oder E-Mail.",
  },
  transfers: {
    board: "Abfahrten",
    cols: ["Flughafen", "Fahrzeit", "Preis pro Fahrzeug"],
    stepsEyebrow: "So funktioniert es",
    stepsTitle: "Ihre Ankunft, *Schritt für Schritt.*",
    steps: [
      { t: "In Minuten gebucht", d: "Senden Sie uns Ihre Flugdaten — wir bestätigen per WhatsApp oder E-Mail." },
      { t: "Wir verfolgen Ihren Flug", d: "Verspätungen werden verfolgt und die Abholzeit wird für Sie angepasst." },
      { t: "Empfang in der Ankunftshalle", d: "Ihr Fahrer wartet mit einem Namensschild und hilft mit dem Gepäck." },
      { t: "Direkt bis vor die Tür", d: "Eine ruhige, private Fahrt zu Ihrem Hotel — zum vereinbarten Preis." },
    ],
    luggageEyebrow: "Platz an Bord",
    luggageTitle: "Platz für Sie *und Ihr Gepäck.*",
    luggageText:
      "Unser Toyota C-HR bietet Platz für bis zu 4 Fahrgäste mit 2 großen Koffern und 2 Handgepäckstücken. Mehr Gepäck? Fragen Sie uns vorher — wir sagen Ihnen ehrlich, was passt.",
  },
  tours: {
    stops: "Stationen unterwegs",
    fullT: "Paris nach Ihren Wünschen",
    fullD:
      "Ein ganzer Tag nach Ihren Wünschen — Museen, Märkte, Aussichtspunkte oder ein langes Mittagessen. Individuelles Angebot.",
  },
  custom: {
    ideasEyebrow: "Ideen zur Inspiration",
    ideasTitle: "Abseits der *klassischen Routen.*",
    ideas: [
      { t: "Monets Giverny", d: "Haus und Gärten des Malers, etwa 75 Minuten von Paris — vom Frühling bis zum Herbst geöffnet." },
      { t: "Fontainebleau", d: "Ein Königsschloss und sein großer Wald, etwa 70 Minuten südlich von Paris." },
      { t: "Aussichtspunkte & Fotostopps", d: "Die schönsten Blicke auf den Eiffelturm, die Seine und Montmartre." },
      { t: "Ein romantischer Abend", d: "Die beleuchtete Stadt zum Jahrestag oder zu einem besonderen Anlass." },
    ],
  },
  about: {
    eyebrow: "Über uns",
    title: "Ein kleiner Pariser Service, *mit Sorgfalt.*",
    sub: "Bonjour Paris Ride ist ein persönlicher Service: ein komfortables Auto und ein Fahrer — von Ihrer ersten Nachricht bis zum letzten Halt.",
    storyT: "Persönlich aus Prinzip",
    story: [
      "Wenn Sie uns schreiben, sprechen Sie direkt mit der Person, die Sie fährt — kein Callcenter, keine App, keine Überraschungen.",
      "Wir halten es einfach: klare Preise für unsere veröffentlichten Strecken, ehrliche Beratung zu Zeiten und Gepäck und ein ruhiges, sauberes Auto.",
    ],
    values: [
      { t: "Pünktlich", d: "Flüge werden verfolgt und Abholungen mit Zeitpuffer geplant." },
      { t: "Transparent", d: "Festpreise pro Fahrzeug auf veröffentlichten Strecken, schriftlich bestätigt." },
      { t: "Aufmerksam", d: "Wasser, Ladekabel, Kindersitz auf Anfrage und Hilfe mit dem Gepäck." },
      { t: "Flexibel", d: "Fotostopps und Umwege, in dem Tempo, das Ihnen passt." },
    ],
    carEyebrow: "Das Auto",
    carTitle: "Unser *Toyota C-HR.*",
    carSub: "Ein selbstladender Hybrid von 2024: leise, komfortabel und vor jeder Fahrt gereinigt.",
    slots: { front: "Front", side: "Profil", interior: "Innenraum", luggage: "Kofferraum" },
    note: "Mit „Illustration“ gekennzeichnete Bilder sind künstlerische Darstellungen des Modells, keine Fotos unseres Autos.",
  },
  car: {
    capacity: "Bis zu 4 Fahrgäste · 2 große Koffer + 2 Handgepäckstücke",
    large: "große Koffer",
    cabin: "Handgepäckstücke",
  },
  contact: {
    formT: "Schreiben Sie uns eine *Nachricht*",
    message: "Ihre Nachricht",
    messagePh: "Daten, Orte, Fragen …",
    send: "Nachricht senden",
    sentT: "Vielen Dank!",
    sentD: "Ihre Nachricht wurde gesendet. Wir antworten so bald wie möglich.",
    readyD: "Ihre Nachricht ist bereit — senden Sie sie uns per WhatsApp oder E-Mail.",
    subject: "Nachricht über die Website",
  },
  guide: {
    eyebrow: "Reiseführer",
    title: "Der Paris-*Reiseführer.*",
    sub: "Praktische Tipps von unterwegs — damit Sie gut planen, Warteschlangen vermeiden und jede Stunde in Paris genießen.",
    edition: (y: number) => `Ausgabe ${y}`,
    contents: "Inhalt",
    chapters: [
      {
        t: "Ankunft in Paris",
        d: "Drei Flughäfen bedienen die Stadt. Das erwartet Sie.",
        tips: [
          "Charles de Gaulle (CDG) liegt mit dem Auto etwa 45–60 Minuten vom Zentrum entfernt, Orly (ORY) etwa 30–45 Minuten.",
          "Beauvais (BVA), genutzt von Billigfluglinien, ist etwa 85 km entfernt — rechnen Sie mit 75–90 Minuten.",
          "Halten Sie die Hoteladresse schriftlich bereit und Ihr Handy für WhatsApp geladen.",
        ],
      },
      {
        t: "Der Eiffelturm",
        d: "Das Wahrzeichen von Paris — am schönsten mit etwas Abstand.",
        tips: [
          "Für den klassischen Blick überqueren Sie die Seine zu den Trocadéro-Gärten.",
          "Nach Einbruch der Dunkelheit funkelt der Turm zu Beginn jeder Stunde fünf Minuten lang.",
          "Das Marsfeld und die Bir-Hakeim-Brücke bieten ruhigere Perspektiven.",
        ],
      },
      {
        t: "Montmartre & Sacré-Cœur",
        d: "Dorfgassen und das schönste Panorama der Stadt.",
        tips: [
          "Kommen Sie früh am Morgen, um Treppen und Aussicht in Ruhe zu genießen.",
          "Der Eintritt in die Basilika Sacré-Cœur ist frei; die Kuppel kostet Eintritt.",
          "Die Straßen sind steil und eng — wir bringen Sie so nah wie möglich nach oben.",
        ],
      },
      {
        t: "Der Louvre",
        d: "Das meistbesuchte Museum der Welt verdient einen Plan.",
        tips: [
          "Das Museum ist dienstags geschlossen.",
          "Buchen Sie online ein Zeitfenster-Ticket, um die längsten Schlangen zu vermeiden.",
          "Die Glaspyramide ist bei Sonnenuntergang am schönsten.",
        ],
      },
      {
        t: "Versailles",
        d: "Ein königlicher Tag, 40 Minuten von Paris.",
        tips: [
          "Das Schloss ist montags geschlossen.",
          "Planen Sie mindestens einen halben Tag ein — allein die Gärten lohnen einen langen Spaziergang.",
          "An ausgewählten Tagen der Saison finden in den Gärten Wasserspiele statt.",
        ],
      },
      {
        t: "Disneyland Paris",
        d: "Ein Familienliebling östlich der Stadt.",
        tips: [
          "Die Parks liegen etwa 50 Autominuten vom Pariser Zentrum entfernt.",
          "Seien Sie vor der Öffnung da, um den Tag voll auszunutzen.",
          "Kindersitze sind auf Anfrage kostenlos — nennen Sie uns einfach das Alter der Kinder.",
        ],
      },
      {
        t: "Rund um Paris",
        d: "Dörfer, Gärten und Schlösser in bequemer Reichweite.",
        tips: [
          "Giverny: Claude Monets Haus und Gärten sind vom Frühling bis zum Herbst geöffnet.",
          "Fontainebleau: ein Königsschloss inmitten eines riesigen Waldes.",
          "Tagesausflüge werden individuell angeboten, mit vorab vereinbarter Wartezeit.",
        ],
      },
      {
        t: "Gut zu wissen",
        d: "Kleine Gewohnheiten, die viel bewirken.",
        tips: [
          "Sagen Sie „Bonjour“, wenn Sie ein Geschäft oder Café betreten — das ist wichtig.",
          "Der Service ist im Restaurant im Preis enthalten; ein kleines Trinkgeld ist eine nette Geste, nie eine Pflicht.",
          "Viele Museen schließen an einem Tag pro Woche — prüfen Sie das vorher.",
        ],
      },
    ],
    distT: "Entfernungen vom *Pariser Zentrum*",
    distNote: "Ungefähre Straßenentfernungen und übliche Fahrzeiten außerhalb der Stoßzeiten.",
  },
  faq: {
    groups: ["Buchung & Zahlung", "Flughäfen & Auto", "Touren & Gruppen"],
    search: "Fragen durchsuchen",
    none: "Keine Frage passt zu Ihrer Suche.",
    stillT: "Noch eine Frage?",
    stillD: "Schreiben Sie uns — wir antworten auf Englisch und Französisch.",
  },
  avail: {
    how: [
      "Wählen Sie einen verfügbaren Tag im Kalender.",
      "Erzählen Sie uns von Fahrt und Fahrgästen.",
      "Wir bestätigen persönlich per WhatsApp oder E-Mail.",
    ],
    legend: {
      available: "Frei für neue Fahrten.",
      limited: "Einige Fahrten sind schon geplant — fragen Sie nach Ihrer Uhrzeit.",
      booked: "Ausgebucht oder nicht verfügbar.",
    },
  },
};

export default site;
