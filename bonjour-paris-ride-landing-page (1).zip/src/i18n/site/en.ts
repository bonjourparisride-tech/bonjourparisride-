/* Page & brand texts of the multi-page site.
   Titles may contain *words* — rendered in the italic accent style.
   Every other language file must keep exactly the same structure. */

const site = {
  nav: {
    home: "Home",
    transfers: "Airport Transfers",
    tours: "Day Tours",
    multiday: "Multi-Day Tours",
    availability: "Availability",
    custom: "Custom Tours",
    gallery: "Gallery",
    reviews: "Reviews",
    guide: "Travel Guide",
    about: "About",
    faq: "FAQ",
    contact: "Contact",
    menu: "Menu",
    close: "Close",
    tagline: "Private driver · Paris & beyond",
  },
  common: {
    next: "Next page",
    discover: "Discover",
    readGuide: "Read the travel guide",
    illustration: "Illustration",
    illustrationLong: "Illustration — not a photograph of our car",
    ourCar: "Photo of our car",
    chapter: (n: string) => `Chapter ${n}`,
    closingLine: "Bon voyage.",
  },
  photos: {
    eiffelLights: "The Eiffel Tower at twilight",
    giverny: "Claude Monet's gardens in Giverny",
    fontainebleau: "The Château de Fontainebleau",
    village: "A flower-filled French village",
    rooftops: "The rooftops of Paris",
    arc: "The Arc de Triomphe at twilight",
    versaillesGold: "Golden statues in the gardens of Versailles",
    croissant: "Coffee and croissants in a Paris café",
    terrace: "A Parisian café terrace",
    chr: "The Toyota C-HR on a Paris street",
    chrAirport: "The Toyota C-HR at an airport pickup",
    interior: "Inside the Toyota C-HR",
    carSide: "The Toyota C-HR in profile",
    carLuggage: "The luggage space of the Toyota C-HR",
  },
  home: {
    doorsEyebrow: "Our journeys",
    doorsTitle: "Three ways to *travel well.*",
    doors: {
      transfers: "CDG, Orly and Beauvais to your door, at a fixed price per car.",
      tours: "Private sightseeing in Paris, at Versailles and Disneyland Paris.",
      multiday: "Longer stays and personal itineraries, with a quotation made for you.",
    },
    carEyebrow: "Your car",
    carTitle: "A quiet, modern *Toyota C-HR.*",
    carText:
      "A clean 2024 hybrid for up to 4 passengers, with room for 2 large suitcases and 2 cabin bags.",
    carCta: "Discover the car",
    availTitle: "Your dates, *confirmed personally.*",
    availText:
      "Check the calendar, choose a date and tell us about your journey. We reply by WhatsApp or email.",
  },
  transfers: {
    board: "Departures",
    cols: ["Airport", "Journey time", "Fare per car"],
    stepsEyebrow: "How it works",
    stepsTitle: "Your arrival, *step by step.*",
    steps: [
      { t: "Book in minutes", d: "Send your flight details — we confirm by WhatsApp or email." },
      { t: "We follow your flight", d: "Delays are tracked and the pickup time is adjusted for you." },
      { t: "Welcome in arrivals", d: "Your driver waits with your name on a sign and helps with your bags." },
      { t: "Straight to your door", d: "A quiet, private ride to your hotel, at the agreed price." },
    ],
    luggageEyebrow: "Space on board",
    luggageTitle: "Room for you *and your luggage.*",
    luggageText:
      "Our Toyota C-HR takes up to 4 passengers with 2 large suitcases and 2 cabin bags. Travelling with more? Ask us first — we will tell you honestly what fits.",
  },
  tours: {
    stops: "Stops along the way",
    fullT: "Paris, your way",
    fullD:
      "A full day shaped around your wishes — museums, markets, viewpoints or a long lunch. Personalized quote.",
  },
  custom: {
    ideasEyebrow: "Ideas to inspire you",
    ideasTitle: "Beyond the *classic routes.*",
    ideas: [
      { t: "Monet's Giverny", d: "The painter's house and gardens, about 75 minutes from Paris — open from spring to autumn." },
      { t: "Fontainebleau", d: "A royal château and its great forest, about 70 minutes south of Paris." },
      { t: "Viewpoints & photo stops", d: "The finest angles on the Eiffel Tower, the Seine and Montmartre." },
      { t: "A romantic evening", d: "The illuminated city for an anniversary or a special occasion." },
    ],
  },
  about: {
    eyebrow: "About",
    title: "A small Paris service, *done with care.*",
    sub: "Bonjour Paris Ride is a personal service: one comfortable car and one driver, from your first message to your last stop.",
    storyT: "Personal, by design",
    story: [
      "When you write to us, you talk directly to the person who will drive you — no call centre, no app, no surprises.",
      "We keep things simple: clear prices for our published routes, honest advice about time and luggage, and a calm, clean car.",
    ],
    values: [
      { t: "Punctual", d: "Flights are followed and pickups planned with time to spare." },
      { t: "Transparent", d: "Fixed prices per car on published routes, confirmed in writing." },
      { t: "Attentive", d: "Water, chargers, a child seat on request and help with your bags." },
      { t: "Flexible", d: "Photo stops and detours, at the pace that suits you." },
    ],
    carEyebrow: "The car",
    carTitle: "Meet our *Toyota C-HR.*",
    carSub: "A 2024 self-charging hybrid: quiet, comfortable and cleaned before every journey.",
    slots: { front: "Front", side: "Profile", interior: "Interior", luggage: "Luggage space" },
    note: "Images marked “Illustration” are artistic renderings of the model, not photographs of our car.",
  },
  car: {
    capacity: "Up to 4 passengers · 2 large suitcases + 2 cabin bags",
    large: "large suitcases",
    cabin: "cabin bags",
  },
  contact: {
    formT: "Send us a *message*",
    message: "Your message",
    messagePh: "Dates, places, questions…",
    send: "Send my message",
    sentT: "Thank you!",
    sentD: "Your message has been sent. We will reply as soon as possible.",
    readyD: "Your message is ready — send it to us on WhatsApp or by email.",
    subject: "Message from the website",
  },
  guide: {
    eyebrow: "Travel guide",
    title: "The Paris *travel guide.*",
    sub: "Practical tips from the road, to help you plan, skip the queues and enjoy every hour in Paris.",
    edition: (y: number) => `Edition ${y}`,
    contents: "Contents",
    chapters: [
      {
        t: "Arriving in Paris",
        d: "Three airports serve the city. Here is what to expect.",
        tips: [
          "Charles de Gaulle (CDG) is about 45–60 minutes from the centre by car; Orly (ORY) about 30–45 minutes.",
          "Beauvais (BVA), used by low-cost airlines, is about 85 km away — allow 75–90 minutes.",
          "Keep your hotel's address written down and your phone charged for WhatsApp.",
        ],
      },
      {
        t: "The Eiffel Tower",
        d: "The icon of Paris, best seen from a little distance.",
        tips: [
          "For the classic view, cross the Seine to the Trocadéro gardens.",
          "After dark, the tower sparkles for five minutes at the start of every hour.",
          "The Champ de Mars and the Bir-Hakeim bridge offer quieter angles.",
        ],
      },
      {
        t: "Montmartre & Sacré-Cœur",
        d: "Village streets and the best panorama over the city.",
        tips: [
          "Come early in the morning to enjoy the steps and the view in calm.",
          "Entry to the Sacré-Cœur basilica is free; the dome has a fee.",
          "The streets are steep and narrow — we drop you as close to the top as possible.",
        ],
      },
      {
        t: "The Louvre",
        d: "The world's most visited museum deserves a plan.",
        tips: [
          "The museum is closed on Tuesdays.",
          "Book a timed ticket online to avoid the longest queues.",
          "The glass pyramid is at its most beautiful at sunset.",
        ],
      },
      {
        t: "Versailles",
        d: "A royal day out, 40 minutes from Paris.",
        tips: [
          "The palace is closed on Mondays.",
          "Plan at least half a day — the gardens alone deserve a long walk.",
          "On selected days in season, the gardens host fountain shows.",
        ],
      },
      {
        t: "Disneyland Paris",
        d: "A family favourite, east of the city.",
        tips: [
          "The parks are about 50 minutes from central Paris by car.",
          "Arrive before opening time to make the most of the day.",
          "Child seats are free on request — just tell us the children's ages.",
        ],
      },
      {
        t: "Beyond Paris",
        d: "Villages, gardens and châteaux within easy reach.",
        tips: [
          "Giverny: Claude Monet's house and gardens open from spring to autumn.",
          "Fontainebleau: a royal château surrounded by a vast forest.",
          "Day trips are quoted individually, with waiting time agreed in advance.",
        ],
      },
      {
        t: "Good to know",
        d: "Little habits that make a big difference.",
        tips: [
          "Say “Bonjour” when you enter a shop or a café — it matters.",
          "Service is included in restaurant bills; a small tip is a kind extra, never an obligation.",
          "Many museums close one day a week — check before you go.",
        ],
      },
    ],
    distT: "Distances from *central Paris*",
    distNote: "Approximate road distances and typical driving times outside rush hour.",
  },
  faq: {
    groups: ["Booking & payment", "Airports & the car", "Tours & groups"],
    search: "Search the questions",
    none: "No question matches your search.",
    stillT: "Still have a question?",
    stillD: "Write to us — we answer in English and French.",
  },
  avail: {
    how: [
      "Choose an available date in the calendar.",
      "Tell us about your journey and passengers.",
      "We confirm personally, by WhatsApp or email.",
    ],
    legend: {
      available: "Free for new journeys.",
      limited: "Some journeys are already planned — ask for your time.",
      booked: "Fully booked or unavailable.",
    },
  },
};

export default site;
export type Site = typeof site;
