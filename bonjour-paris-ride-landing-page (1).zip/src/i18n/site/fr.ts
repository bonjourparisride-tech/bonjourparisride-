import type { Site } from "./en";

const site: Site = {
  nav: {
    home: "Accueil",
    transfers: "Transferts aéroport",
    tours: "Visites à la journée",
    multiday: "Circuits multi-jours",
    availability: "Disponibilités",
    custom: "Circuits sur mesure",
    gallery: "Galerie",
    reviews: "Avis",
    guide: "Guide de voyage",
    about: "À propos",
    faq: "FAQ",
    contact: "Contact",
    menu: "Menu",
    close: "Fermer",
    tagline: "Chauffeur privé · Paris et alentours",
  },
  common: {
    next: "Page suivante",
    discover: "Découvrir",
    readGuide: "Lire le guide de voyage",
    illustration: "Illustration",
    illustrationLong: "Illustration — pas une photo de notre voiture",
    ourCar: "Photo de notre voiture",
    chapter: (n: string) => `Chapitre ${n}`,
    closingLine: "Bon voyage.",
  },
  photos: {
    eiffelLights: "La tour Eiffel au crépuscule",
    giverny: "Les jardins de Claude Monet à Giverny",
    fontainebleau: "Le château de Fontainebleau",
    village: "Un village français fleuri",
    rooftops: "Les toits de Paris",
    arc: "L'Arc de Triomphe au crépuscule",
    versaillesGold: "Statues dorées dans les jardins de Versailles",
    croissant: "Café et croissants dans un café parisien",
    terrace: "Une terrasse de café parisien",
    chr: "La Toyota C-HR dans une rue de Paris",
    chrAirport: "La Toyota C-HR lors d'une prise en charge à l'aéroport",
    interior: "À bord de la Toyota C-HR",
    carSide: "La Toyota C-HR de profil",
    carLuggage: "Le coffre de la Toyota C-HR",
  },
  home: {
    doorsEyebrow: "Nos voyages",
    doorsTitle: "Trois façons de *bien voyager.*",
    doors: {
      transfers: "CDG, Orly et Beauvais jusqu'à votre porte, à prix fixe par véhicule.",
      tours: "Visites privées de Paris, de Versailles et de Disneyland Paris.",
      multiday: "Séjours prolongés et itinéraires personnels, avec un devis rien que pour vous.",
    },
    carEyebrow: "Votre voiture",
    carTitle: "Une *Toyota C-HR* moderne et silencieuse.",
    carText:
      "Une hybride 2024 impeccable pour 4 passagers maximum, avec de la place pour 2 grandes valises et 2 bagages cabine.",
    carCta: "Découvrir la voiture",
    availTitle: "Vos dates, *confirmées personnellement.*",
    availText:
      "Consultez le calendrier, choisissez une date et parlez-nous de votre voyage. Nous répondons par WhatsApp ou par e-mail.",
  },
  transfers: {
    board: "Départs",
    cols: ["Aéroport", "Durée du trajet", "Prix par véhicule"],
    stepsEyebrow: "Comment ça marche",
    stepsTitle: "Votre arrivée, *étape par étape.*",
    steps: [
      { t: "Réservez en quelques minutes", d: "Envoyez les détails de votre vol — nous confirmons par WhatsApp ou par e-mail." },
      { t: "Nous suivons votre vol", d: "Les retards sont suivis et l'heure de prise en charge est ajustée pour vous." },
      { t: "Accueil dans le hall d'arrivée", d: "Votre chauffeur vous attend avec une pancarte à votre nom et s'occupe de vos bagages." },
      { t: "Directement à votre porte", d: "Un trajet privé et calme jusqu'à votre hôtel, au prix convenu." },
    ],
    luggageEyebrow: "L'espace à bord",
    luggageTitle: "De la place pour vous *et vos bagages.*",
    luggageText:
      "Notre Toyota C-HR accueille jusqu'à 4 passagers avec 2 grandes valises et 2 bagages cabine. Vous voyagez plus chargé ? Demandez-nous d'abord — nous vous dirons honnêtement ce qui tient.",
  },
  tours: {
    stops: "Les étapes du parcours",
    fullT: "Paris, à votre façon",
    fullD:
      "Une journée entière construite selon vos envies — musées, marchés, points de vue ou long déjeuner. Devis personnalisé.",
  },
  custom: {
    ideasEyebrow: "Des idées pour vous inspirer",
    ideasTitle: "Au-delà des *circuits classiques.*",
    ideas: [
      { t: "Le Giverny de Monet", d: "La maison et les jardins du peintre, à environ 75 minutes de Paris — ouverts du printemps à l'automne." },
      { t: "Fontainebleau", d: "Un château royal et sa grande forêt, à environ 70 minutes au sud de Paris." },
      { t: "Points de vue et arrêts photo", d: "Les plus beaux angles sur la tour Eiffel, la Seine et Montmartre." },
      { t: "Une soirée romantique", d: "La ville illuminée pour un anniversaire ou une occasion spéciale." },
    ],
  },
  about: {
    eyebrow: "À propos",
    title: "Un petit service parisien, *fait avec soin.*",
    sub: "Bonjour Paris Ride est un service personnel : une voiture confortable et un chauffeur, de votre premier message à votre dernier arrêt.",
    storyT: "Personnel, par nature",
    story: [
      "Lorsque vous nous écrivez, vous parlez directement à la personne qui vous conduira — ni centre d'appels, ni application, ni surprise.",
      "Nous faisons simple : des prix clairs pour nos trajets publiés, des conseils honnêtes sur les horaires et les bagages, et une voiture calme et propre.",
    ],
    values: [
      { t: "Ponctuel", d: "Les vols sont suivis et les prises en charge prévues avec de la marge." },
      { t: "Transparent", d: "Des prix fixes par véhicule sur les trajets publiés, confirmés par écrit." },
      { t: "Attentionné", d: "Eau, chargeurs, siège enfant sur demande et aide avec vos bagages." },
      { t: "Flexible", d: "Arrêts photo et détours, au rythme qui vous convient." },
    ],
    carEyebrow: "La voiture",
    carTitle: "Découvrez notre *Toyota C-HR.*",
    carSub: "Une hybride autorechargeable de 2024 : silencieuse, confortable et nettoyée avant chaque trajet.",
    slots: { front: "Avant", side: "Profil", interior: "Intérieur", luggage: "Coffre" },
    note: "Les images signalées « Illustration » sont des représentations artistiques du modèle, et non des photos de notre voiture.",
  },
  car: {
    capacity: "Jusqu'à 4 passagers · 2 grandes valises + 2 bagages cabine",
    large: "grandes valises",
    cabin: "bagages cabine",
  },
  contact: {
    formT: "Envoyez-nous un *message*",
    message: "Votre message",
    messagePh: "Dates, lieux, questions…",
    send: "Envoyer mon message",
    sentT: "Merci !",
    sentD: "Votre message a bien été envoyé. Nous vous répondrons dès que possible.",
    readyD: "Votre message est prêt — envoyez-le-nous par WhatsApp ou par e-mail.",
    subject: "Message depuis le site",
  },
  guide: {
    eyebrow: "Guide de voyage",
    title: "Le *guide* de Paris.",
    sub: "Des conseils pratiques venus de la route, pour bien préparer votre séjour, éviter les files d'attente et profiter de chaque heure à Paris.",
    edition: (y: number) => `Édition ${y}`,
    contents: "Sommaire",
    chapters: [
      {
        t: "Arriver à Paris",
        d: "Trois aéroports desservent la ville. Voici à quoi vous attendre.",
        tips: [
          "Charles-de-Gaulle (CDG) est à environ 45–60 minutes du centre en voiture ; Orly (ORY) à environ 30–45 minutes.",
          "Beauvais (BVA), utilisé par les compagnies low-cost, est à environ 85 km — prévoyez 75 à 90 minutes.",
          "Gardez l'adresse de votre hôtel par écrit et votre téléphone chargé pour WhatsApp.",
        ],
      },
      {
        t: "La tour Eiffel",
        d: "Le symbole de Paris, à admirer avec un peu de recul.",
        tips: [
          "Pour la vue classique, traversez la Seine jusqu'aux jardins du Trocadéro.",
          "À la nuit tombée, la tour scintille pendant cinq minutes au début de chaque heure.",
          "Le Champ-de-Mars et le pont de Bir-Hakeim offrent des angles plus calmes.",
        ],
      },
      {
        t: "Montmartre et le Sacré-Cœur",
        d: "Des ruelles de village et le plus beau panorama sur la ville.",
        tips: [
          "Venez tôt le matin pour profiter des marches et de la vue au calme.",
          "L'entrée de la basilique du Sacré-Cœur est gratuite ; l'accès au dôme est payant.",
          "Les rues sont raides et étroites — nous vous déposons au plus près du sommet.",
        ],
      },
      {
        t: "Le Louvre",
        d: "Le musée le plus visité au monde mérite un peu de préparation.",
        tips: [
          "Le musée est fermé le mardi.",
          "Réservez un billet horodaté en ligne pour éviter les plus longues files.",
          "La pyramide de verre est au plus beau au coucher du soleil.",
        ],
      },
      {
        t: "Versailles",
        d: "Une journée royale, à 40 minutes de Paris.",
        tips: [
          "Le château est fermé le lundi.",
          "Prévoyez au moins une demi-journée — les jardins méritent à eux seuls une longue promenade.",
          "Certains jours en saison, les jardins accueillent des spectacles de fontaines.",
        ],
      },
      {
        t: "Disneyland Paris",
        d: "Un incontournable en famille, à l'est de la ville.",
        tips: [
          "Les parcs sont à environ 50 minutes du centre de Paris en voiture.",
          "Arrivez avant l'ouverture pour profiter pleinement de la journée.",
          "Les sièges enfant sont gratuits sur demande — indiquez-nous simplement l'âge des enfants.",
        ],
      },
      {
        t: "Au-delà de Paris",
        d: "Villages, jardins et châteaux à portée de route.",
        tips: [
          "Giverny : la maison et les jardins de Claude Monet sont ouverts du printemps à l'automne.",
          "Fontainebleau : un château royal entouré d'une vaste forêt.",
          "Les excursions font l'objet d'un devis individuel, avec un temps d'attente convenu à l'avance.",
        ],
      },
      {
        t: "Bon à savoir",
        d: "De petites habitudes qui font une grande différence.",
        tips: [
          "Dites « Bonjour » en entrant dans une boutique ou un café — c'est important.",
          "Le service est compris dans l'addition au restaurant ; un petit pourboire est une attention, jamais une obligation.",
          "De nombreux musées ferment un jour par semaine — vérifiez avant de partir.",
        ],
      },
    ],
    distT: "Distances depuis *le centre de Paris*",
    distNote: "Distances routières approximatives et temps de trajet habituels hors heures de pointe.",
  },
  faq: {
    groups: ["Réservation et paiement", "Aéroports et voiture", "Visites et groupes"],
    search: "Rechercher une question",
    none: "Aucune question ne correspond à votre recherche.",
    stillT: "Une autre question ?",
    stillD: "Écrivez-nous — nous répondons en français et en anglais.",
  },
  avail: {
    how: [
      "Choisissez une date disponible dans le calendrier.",
      "Parlez-nous de votre trajet et de vos passagers.",
      "Nous confirmons personnellement, par WhatsApp ou par e-mail.",
    ],
    legend: {
      available: "Libre pour de nouveaux trajets.",
      limited: "Certains trajets sont déjà prévus — demandez votre horaire.",
      booked: "Complet ou indisponible.",
    },
  },
};

export default site;
