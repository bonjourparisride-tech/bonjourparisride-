import type { Site } from "./en";

const site: Site = {
  nav: {
    home: "Início",
    transfers: "Transfers de aeroporto",
    tours: "Passeios de um dia",
    multiday: "Roteiros de vários dias",
    availability: "Disponibilidade",
    custom: "Roteiros sob medida",
    gallery: "Galeria",
    reviews: "Avaliações",
    guide: "Guia de viagem",
    about: "Sobre nós",
    faq: "Dúvidas",
    contact: "Contato",
    menu: "Menu",
    close: "Fechar",
    tagline: "Motorista particular · Paris e arredores",
  },
  common: {
    next: "Próxima página",
    discover: "Descobrir",
    readGuide: "Ler o guia de viagem",
    illustration: "Ilustração",
    illustrationLong: "Ilustração — não é uma foto do nosso carro",
    ourCar: "Foto do nosso carro",
    chapter: (n: string) => `Capítulo ${n}`,
    closingLine: "Bon voyage.",
  },
  photos: {
    eiffelLights: "A Torre Eiffel ao anoitecer",
    giverny: "Os jardins de Claude Monet em Giverny",
    fontainebleau: "O Castelo de Fontainebleau",
    village: "Uma vila francesa florida",
    rooftops: "Os telhados de Paris",
    arc: "O Arco do Triunfo ao anoitecer",
    versaillesGold: "Estátuas douradas nos jardins de Versalhes",
    croissant: "Café e croissants em um café de Paris",
    terrace: "Uma varanda de café parisiense",
    chr: "O Toyota C-HR em uma rua de Paris",
    chrAirport: "O Toyota C-HR em uma busca no aeroporto",
    interior: "O interior do Toyota C-HR",
    carSide: "O Toyota C-HR de perfil",
    carLuggage: "O porta-malas do Toyota C-HR",
  },
  home: {
    doorsEyebrow: "Nossas viagens",
    doorsTitle: "Três maneiras de *viajar bem.*",
    doors: {
      transfers: "Do CDG, Orly e Beauvais até a sua porta, com preço fixo por veículo.",
      tours: "Passeios privados por Paris, Versalhes e Disneyland Paris.",
      multiday: "Estadias longas e roteiros pessoais, com um orçamento feito para você.",
    },
    carEyebrow: "Seu carro",
    carTitle: "Um *Toyota C-HR* moderno e silencioso.",
    carText:
      "Um híbrido 2024 impecável para até 4 passageiros, com espaço para 2 malas grandes e 2 malas de mão.",
    carCta: "Conhecer o carro",
    availTitle: "Suas datas, *confirmadas pessoalmente.*",
    availText:
      "Consulte o calendário, escolha uma data e conte-nos sobre a sua viagem. Respondemos pelo WhatsApp ou por e-mail.",
  },
  transfers: {
    board: "Partidas",
    cols: ["Aeroporto", "Duração", "Preço por veículo"],
    stepsEyebrow: "Como funciona",
    stepsTitle: "Sua chegada, *passo a passo.*",
    steps: [
      { t: "Reserve em minutos", d: "Envie os dados do seu voo — confirmamos pelo WhatsApp ou por e-mail." },
      { t: "Acompanhamos seu voo", d: "Atrasos são monitorados e o horário de busca é ajustado para você." },
      { t: "Recepção no desembarque", d: "Seu motorista espera com uma placa com seu nome e ajuda com as malas." },
      { t: "Direto até a sua porta", d: "Um trajeto privado e tranquilo até o seu hotel, pelo preço combinado." },
    ],
    luggageEyebrow: "Espaço a bordo",
    luggageTitle: "Lugar para você *e sua bagagem.*",
    luggageText:
      "Nosso Toyota C-HR leva até 4 passageiros com 2 malas grandes e 2 malas de mão. Viaja com mais? Consulte-nos antes — diremos com sinceridade o que cabe.",
  },
  tours: {
    stops: "Paradas do percurso",
    fullT: "Paris do seu jeito",
    fullD:
      "Um dia inteiro moldado pelos seus desejos — museus, mercados, mirantes ou um longo almoço. Orçamento personalizado.",
  },
  custom: {
    ideasEyebrow: "Ideias para inspirar você",
    ideasTitle: "Além das *rotas clássicas.*",
    ideas: [
      { t: "A Giverny de Monet", d: "A casa e os jardins do pintor, a cerca de 75 minutos de Paris — abertos da primavera ao outono." },
      { t: "Fontainebleau", d: "Um castelo real e sua grande floresta, a cerca de 70 minutos ao sul de Paris." },
      { t: "Mirantes e paradas para fotos", d: "Os melhores ângulos da Torre Eiffel, do Sena e de Montmartre." },
      { t: "Uma noite romântica", d: "A cidade iluminada para um aniversário ou uma ocasião especial." },
    ],
  },
  about: {
    eyebrow: "Sobre nós",
    title: "Um pequeno serviço parisiense, *feito com cuidado.*",
    sub: "A Bonjour Paris Ride é um serviço pessoal: um carro confortável e um motorista, da sua primeira mensagem até a última parada.",
    storyT: "Pessoal por natureza",
    story: [
      "Quando você nos escreve, fala diretamente com a pessoa que vai dirigir para você — sem central de atendimento, sem aplicativo, sem surpresas.",
      "Mantemos tudo simples: preços claros nas rotas publicadas, conselhos honestos sobre horários e bagagem, e um carro limpo e tranquilo.",
    ],
    values: [
      { t: "Pontual", d: "Os voos são acompanhados e as buscas planejadas com folga." },
      { t: "Transparente", d: "Preços fixos por veículo nas rotas publicadas, confirmados por escrito." },
      { t: "Atencioso", d: "Água, carregadores, cadeirinha sob pedido e ajuda com as malas." },
      { t: "Flexível", d: "Paradas para fotos e desvios, no ritmo que for melhor para você." },
    ],
    carEyebrow: "O carro",
    carTitle: "Conheça nosso *Toyota C-HR.*",
    carSub: "Um híbrido autorrecarregável 2024: silencioso, confortável e limpo antes de cada trajeto.",
    slots: { front: "Frente", side: "Perfil", interior: "Interior", luggage: "Porta-malas" },
    note: "As imagens marcadas como “Ilustração” são representações artísticas do modelo, e não fotos do nosso carro.",
  },
  car: {
    capacity: "Até 4 passageiros · 2 malas grandes + 2 malas de mão",
    large: "malas grandes",
    cabin: "malas de mão",
  },
  contact: {
    formT: "Envie-nos uma *mensagem*",
    message: "Sua mensagem",
    messagePh: "Datas, lugares, dúvidas…",
    send: "Enviar minha mensagem",
    sentT: "Obrigado!",
    sentD: "Sua mensagem foi enviada. Responderemos o quanto antes.",
    readyD: "Sua mensagem está pronta — envie-a pelo WhatsApp ou por e-mail.",
    subject: "Mensagem do site",
  },
  guide: {
    eyebrow: "Guia de viagem",
    title: "O *guia* de Paris.",
    sub: "Dicas práticas de quem vive na estrada, para planejar, evitar filas e aproveitar cada hora em Paris.",
    edition: (y: number) => `Edição ${y}`,
    contents: "Sumário",
    chapters: [
      {
        t: "Chegando a Paris",
        d: "Três aeroportos atendem a cidade. Veja o que esperar.",
        tips: [
          "O Charles de Gaulle (CDG) fica a cerca de 45–60 minutos do centro de carro; Orly (ORY), a cerca de 30–45 minutos.",
          "Beauvais (BVA), usado pelas companhias low-cost, fica a cerca de 85 km — conte com 75 a 90 minutos.",
          "Tenha o endereço do hotel por escrito e o celular carregado para o WhatsApp.",
        ],
      },
      {
        t: "A Torre Eiffel",
        d: "O símbolo de Paris, mais bonito visto de um pouco de distância.",
        tips: [
          "Para a vista clássica, atravesse o Sena até os jardins do Trocadéro.",
          "Depois que escurece, a torre cintila por cinco minutos no início de cada hora.",
          "O Champ de Mars e a ponte de Bir-Hakeim oferecem ângulos mais tranquilos.",
        ],
      },
      {
        t: "Montmartre e Sacré-Cœur",
        d: "Ruas de vilarejo e o melhor panorama da cidade.",
        tips: [
          "Vá logo cedo para aproveitar as escadarias e a vista com calma.",
          "A entrada na basílica de Sacré-Cœur é gratuita; o domo é pago.",
          "As ruas são íngremes e estreitas — deixamos você o mais perto possível do alto.",
        ],
      },
      {
        t: "O Louvre",
        d: "O museu mais visitado do mundo merece um plano.",
        tips: [
          "O museu fecha às terças-feiras.",
          "Reserve um ingresso com horário marcado on-line para evitar as filas mais longas.",
          "A pirâmide de vidro fica ainda mais bonita ao pôr do sol.",
        ],
      },
      {
        t: "Versalhes",
        d: "Um dia de realeza a 40 minutos de Paris.",
        tips: [
          "O palácio fecha às segundas-feiras.",
          "Reserve pelo menos meio dia — só os jardins já merecem um longo passeio.",
          "Em alguns dias da temporada, os jardins recebem espetáculos de fontes.",
        ],
      },
      {
        t: "Disneyland Paris",
        d: "Um clássico em família, a leste da cidade.",
        tips: [
          "Os parques ficam a cerca de 50 minutos do centro de Paris de carro.",
          "Chegue antes da abertura para aproveitar ao máximo o dia.",
          "A cadeirinha infantil é grátis sob pedido — basta informar a idade das crianças.",
        ],
      },
      {
        t: "Além de Paris",
        d: "Vilarejos, jardins e castelos bem perto.",
        tips: [
          "Giverny: a casa e os jardins de Claude Monet abrem da primavera ao outono.",
          "Fontainebleau: um castelo real cercado por uma vasta floresta.",
          "Os passeios fora de Paris têm orçamento individual, com tempo de espera combinado antes.",
        ],
      },
      {
        t: "Bom saber",
        d: "Pequenos hábitos que fazem toda a diferença.",
        tips: [
          "Diga “Bonjour” ao entrar em uma loja ou café — faz diferença.",
          "O serviço já está incluído na conta do restaurante; uma gorjeta é uma gentileza, nunca uma obrigação.",
          "Muitos museus fecham um dia por semana — confira antes de ir.",
        ],
      },
    ],
    distT: "Distâncias a partir do *centro de Paris*",
    distNote: "Distâncias aproximadas por estrada e tempos habituais fora do horário de pico.",
  },
  faq: {
    groups: ["Reservas e pagamento", "Aeroportos e carro", "Passeios e grupos"],
    search: "Pesquisar uma dúvida",
    none: "Nenhuma dúvida corresponde à sua pesquisa.",
    stillT: "Ainda tem alguma dúvida?",
    stillD: "Escreva para nós — respondemos em inglês e francês.",
  },
  avail: {
    how: [
      "Escolha uma data disponível no calendário.",
      "Conte-nos sobre o trajeto e os passageiros.",
      "Confirmamos pessoalmente, pelo WhatsApp ou por e-mail.",
    ],
    legend: {
      available: "Livre para novos trajetos.",
      limited: "Já há trajetos planejados — consulte o seu horário.",
      booked: "Lotado ou indisponível.",
    },
  },
};

export default site;
