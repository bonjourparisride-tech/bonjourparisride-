/* ─────────────────────────────────────────────────────────────────────────
   BONJOUR PARIS RIDE — business settings
   Everything you are likely to change lives in this file.
   All visible texts (7 languages) live in src/i18n/*.ts
   ───────────────────────────────────────────────────────────────────────── */

export type ServiceId =
  | "airport"
  | "tour"
  | "versailles"
  | "disney"
  | "multiday"
  | "custom";
export type PricedService = "airport" | "tour" | "versailles" | "disney";
export type DayStatus = "available" | "limited" | "booked" | "blocked";

/* ── Contact ─────────────────────────────────────────────────────────────── */

export const CONTACT = {
  /** WhatsApp & phone, international format (used for wa.me and tel: links). */
  phone: "+33652333634",
  phoneDisplay: "+33 6 52 33 36 34",
  /** ⚠️ PLACEHOLDER — replace with your real email address. */
  email: "contact@bonjourparisride.com",
};

/* ── Data sources ──────────────────────────────────────────────────────────
   Leave these empty to run in DEMONSTRATION mode: availability, reviews and
   gallery photos are managed in the Owner area (#/admin) and stored in that
   browser only, and the calendar is clearly labelled as a demonstration.

   Going live without a server:
   1. Owner area → Data → export availability.json and content.json
   2. Upload both files to your hosting (any static host works)
   3. Paste their public URLs below and rebuild.
   For instant delivery of requests, create a free form endpoint
   (Formspree, Web3Forms, Basin…) and paste its URL in formEndpoint. */
export const DATA = {
  availabilityUrl: "",
  contentUrl: "",
  formEndpoint: "",
};

export const LINKS = {
  /** Public page listing your genuine reviews (e.g. Google Business profile). */
  reviews: "",
  /** Direct "write a review" link (e.g. Google review short link). */
  writeReview: "",
};

/** Owner-area passcode. A convenience lock, NOT real security — change it. */
export const ADMIN_PASSCODE = "bonjour-paris";

export const CALENDAR = {
  /** Status of a future day with no confirmed booking and no manual status. */
  defaultStatus: "available" as DayStatus,
  /** How many months ahead visitors can send requests. */
  horizonMonths: 12,
  /** Minimum gap between two confirmed journeys, in minutes. */
  bufferMinutes: 30,
  /** Busy minutes after which a day automatically counts as fully booked. */
  dayCapacityMinutes: 600,
};

/* ── The car ─────────────────────────────────────────────────────────────── */

export const CAPACITY = {
  maxPassengers: 4,
  /** Boot space of the Toyota C-HR: 2 large suitcases + 2 cabin bags. */
  largeSuitcases: 2,
  cabinBags: 2,
  /** Highest value the luggage steppers accept (above capacity shows a warning). */
  maxSuitcases: 4,
  /** Large suitcases that fit — the same whatever the number of passengers. */
  suitcasesFor: (_passengers: number) => 2,
};

export const POLICIES = { freeWaitingMinutes: 60, freeCancellationHours: 24 };

/* ── Approved price list — euros, per car, up to 4 passengers ──────────────
   price: null  → "on request" (a personalized quote is prepared)
   minutes      → how long the car is busy; used to refuse overlapping
                  confirmed bookings in the Owner area. */
export interface Option {
  id: string;
  price: number | null;
  minutes: number;
  code?: string;
  travel?: [number, number];
}

export const OPTIONS: Record<PricedService, Option[]> = {
  airport: [
    { id: "cdg", code: "CDG", price: 49, minutes: 150, travel: [45, 60] },
    { id: "ory", code: "ORY", price: 35, minutes: 120, travel: [30, 45] },
    { id: "bva", code: "BVA", price: 109, minutes: 240, travel: [75, 90] },
  ],
  tour: [
    { id: "t2", price: 89, minutes: 150 },
    { id: "t3", price: 129, minutes: 210 },
    { id: "t4", price: 169, minutes: 270 },
    { id: "t8", price: null, minutes: 540 },
  ],
  versailles: [
    { id: "oneway", price: 45, minutes: 120 },
    { id: "return", price: 139, minutes: 330 },
  ],
  disney: [
    { id: "oneway", price: null, minutes: 150 },
    { id: "return", price: null, minutes: 600 },
  ],
};

export const SERVICES: ServiceId[] = [
  "airport",
  "tour",
  "versailles",
  "disney",
  "multiday",
  "custom",
];

export const DEFAULT_OPTION: Record<PricedService, string> = {
  airport: "cdg",
  tour: "t2",
  versailles: "return",
  disney: "oneway",
};

export const isPriced = (s: ServiceId): s is PricedService => s in OPTIONS;
export const optionsOf = (s: ServiceId): Option[] =>
  isPriced(s) ? OPTIONS[s] : [];
export const findOption = (s: ServiceId, id?: string): Option | undefined =>
  optionsOf(s).find((o) => o.id === id) ?? optionsOf(s)[0];
export const fromPrice = (s: ServiceId): number | null => {
  const prices = optionsOf(s)
    .map((o) => o.price)
    .filter((p): p is number => p !== null);
  return prices.length ? Math.min(...prices) : null;
};

/** Official 2026 Paris taxi fixed fare CDG ⇄ Paris, Right Bank / Left Bank
 *  (arrêté préfectoral du 24 décembre 2025). Verify before publishing. */
export const TAXI_FARE: [number, number] = [56, 65];

/* ── Multi-day itinerary ideas (texts in i18n → multi.tours) ─────────────── */

export const PLACES = [
  "eiffel",
  "louvre",
  "montmartre",
  "notredame",
  "marais",
  "seine",
  "versailles",
  "disney",
  "giverny",
  "fontainebleau",
] as const;
export type PlaceId = (typeof PLACES)[number];

export const MULTI_TOURS: {
  id: "a" | "b" | "c";
  days: number;
  photo: string;
  places: PlaceId[];
}[] = [
  { id: "a", days: 2, photo: "eiffelGold", places: ["eiffel", "louvre", "seine", "montmartre", "versailles"] },
  { id: "b", days: 2, photo: "disney", places: ["eiffel", "louvre", "notredame", "disney"] },
  { id: "c", days: 3, photo: "versaillesGardens", places: ["eiffel", "louvre", "marais", "versailles"] },
];

/* ── Links ───────────────────────────────────────────────────────────────── */

const digits = CONTACT.phone.replace(/\D/g, "");

export const waLink = (text?: string) =>
  `https://wa.me/${digits}${text ? `?text=${encodeURIComponent(text)}` : ""}`;

export const telLink = `tel:${CONTACT.phone}`;

export const mailLink = (subject?: string, body?: string) => {
  const q = [
    subject ? `subject=${encodeURIComponent(subject)}` : "",
    body ? `body=${encodeURIComponent(body)}` : "",
  ]
    .filter(Boolean)
    .join("&");
  return `mailto:${CONTACT.email}${q ? `?${q}` : ""}`;
};

export const isPlaceholderPhone = digits.startsWith("3363998");
