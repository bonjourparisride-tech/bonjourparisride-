import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useEffect, type ReactNode } from "react";
import { LangProvider, useI18n } from "./i18n";
import { MENU, useRoute } from "./lib/router";
import { PlannerProvider } from "./components/Planner";
import Nav from "./components/Nav";
import Footer from "./components/Footer";
import Floating from "./components/Floating";
import Home from "./components/Home";
import Admin from "./components/Admin";
import TransfersPage from "./pages/Transfers";
import ToursPage from "./pages/Tours";
import MultiDayPage from "./pages/MultiDay";
import AvailabilityPage from "./pages/Availability";
import CustomPage from "./pages/Custom";
import GalleryPage from "./pages/Gallery";
import ReviewsPage from "./pages/Reviews";
import GuidePage from "./pages/Guide";
import AboutPage from "./pages/About";
import FAQPage from "./pages/FAQ";
import ContactPage from "./pages/Contact";
import LegalPage from "./pages/Legal";

/* One topic per page: Home · Airport Transfers · Day Tours · Multi-Day Tours ·
   Availability · Custom Tours · Gallery · Reviews · Travel Guide · About · FAQ ·
   Contact (+ legal pages and the owner area). */

function Site() {
  const route = useRoute();
  const { t, s } = useI18n();
  const reduce = useReducedMotion();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "auto" });
  }, [route.key]);

  useEffect(() => {
    const m = MENU.find((x) => x.page === route.page);
    if (route.page === "legal") document.title = `${t.footer.legal} — Bonjour Paris Ride`;
    else if (!m || route.page === "home") document.title = t.meta.title;
    else document.title = `${s.nav[m.key]} — Bonjour Paris Ride`;
  }, [route.page, t, s]);

  let content: ReactNode;
  switch (route.page) {
    case "transfers":
      content = <TransfersPage />;
      break;
    case "tours":
      content = <ToursPage />;
      break;
    case "multi-day":
      content = <MultiDayPage params={route.params} />;
      break;
    case "availability":
      content = <AvailabilityPage />;
      break;
    case "custom":
      content = <CustomPage params={route.params} />;
      break;
    case "gallery":
      content = <GalleryPage />;
      break;
    case "reviews":
      content = <ReviewsPage />;
      break;
    case "guide":
      content = <GuidePage />;
      break;
    case "about":
      content = <AboutPage params={route.params} />;
      break;
    case "faq":
      content = <FAQPage />;
      break;
    case "contact":
      content = <ContactPage />;
      break;
    case "legal":
      content = <LegalPage sub={route.sub} />;
      break;
    case "admin":
      content = <Admin />;
      break;
    default:
      content = <Home />;
  }

  const admin = route.page === "admin";

  return (
    <div className="grain relative min-h-screen bg-ivory">
      <Nav page={route.page} />
      <main id="main" tabIndex={-1} className="outline-none">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={route.page === "legal" ? `legal-${route.sub}` : route.page}
            initial={reduce ? { opacity: 0 } : { opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          >
            {content}
          </motion.div>
        </AnimatePresence>
      </main>
      {!admin && <Footer />}
      {!admin && <Floating page={route.page} />}
    </div>
  );
}

export default function App() {
  return (
    <LangProvider>
      <PlannerProvider>
        <Site />
      </PlannerProvider>
    </LangProvider>
  );
}
