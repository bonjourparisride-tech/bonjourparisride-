import { IMG } from "./assets";

/* Paris & France photography: Pexels (free licence, credited in the gallery viewer).
   Car images: AI illustrations of the model, never presented as photos of the real car. */

export type GalleryCat =
  | "paris"
  | "airport"
  | "disney"
  | "versailles"
  | "couples"
  | "families"
  | "guests";

export const GALLERY_CATS: GalleryCat[] = [
  "paris",
  "airport",
  "disney",
  "versailles",
  "couples",
  "families",
  "guests",
];

export interface Photo {
  id: string;
  /** caption key — looked up in i18n (site.photos first, then ui photos) */
  key: string;
  src: string;
  w: number;
  h: number;
  /** AI illustration of the car model (excluded from the gallery, always labelled) */
  local?: boolean;
  credit?: string;
  pos?: string;
  cats: GalleryCat[];
}

const PX = "https://images.pexels.com/photos";

const px = (
  id: string,
  key: string,
  pid: number,
  w: number,
  h: number,
  credit: string,
  cats: GalleryCat[],
  pos?: string,
): Photo => ({ id, key, src: `${PX}/${pid}/pexels-photo-${pid}.jpeg`, w, h, credit, cats, pos });

const ai = (id: string, src: string, pos?: string): Photo => ({
  id,
  key: id,
  src,
  w: 3,
  h: 2,
  local: true,
  cats: [],
  pos,
});

const LIST: Photo[] = [
  px("eiffelGold", "eiffelGold", 10930112, 8848, 5898, "Hans D.", ["paris"], "50% 60%"),
  px("eiffelSunset", "eiffelSunset", 32398701, 6637, 4425, "Masood Aslami", ["paris"]),
  px("eiffelLights", "eiffelLights", 35415033, 6000, 4000, "Svitlana Shakalova", ["paris"]),
  px("eiffelNight", "eiffelNight", 19917985, 9024, 12032, "Khaled Ameur", ["paris"]),
  px("rooftops", "rooftops", 29395092, 23400, 15600, "Almir Reis", ["paris"]),
  px("seine", "seine", 16823627, 7982, 5324, "Josh Withers", ["paris"]),
  px("bridgeNight", "bridgeNight", 33729364, 7952, 5304, "Hernan Berwart", ["paris"]),
  px("montmartre", "montmartre", 28688859, 6175, 4117, "Sergey Guk", ["paris"]),
  px("montmartreStreet", "montmartreStreet", 36300247, 4000, 6000, "Raylarında Şehrin", ["paris"]),
  px("louvre", "louvre", 29099940, 14173, 9448, "Almir Reis", ["paris"]),
  px("notredame", "notredame", 32393661, 6576, 4377, "Stephen Leonardi", ["paris"]),
  px("arc", "arc", 15995558, 6000, 4000, "Gökberk Keskinkılıç", ["paris"]),
  px("cafe", "cafe", 16773422, 4063, 6094, "Josh Withers", ["paris"]),
  px("terrace", "terrace", 15652571, 4016, 6016, "Harriet B.", ["paris"]),
  px("croissant", "croissant", 40076591, 6048, 4032, "Bingqian Li", ["paris"]),
  px("bistro", "bistro", 36138108, 4000, 6000, "Liisbet Luup", ["paris"]),
  px("boulevard", "boulevard", 38998727, 6960, 4640, "Efrem Efre", ["paris"]),
  px("versailles", "versailles", 15546889, 6494, 4329, "Denitsa Kireva", ["versailles"]),
  px("versaillesGardens", "versaillesGardens", 28123847, 9146, 6097, "Son Tung Tran", ["versailles"]),
  px("versaillesGold", "versaillesGold", 30835538, 6048, 4024, "Fotis Michalainas", ["versailles"]),
  px("versaillesFountain", "versaillesGardens", 24407149, 6000, 4000, "Yannick", ["versailles"]),
  px("giverny", "giverny", 29173987, 6240, 4160, "Clement Couturier", []),
  px("givernyPond", "giverny", 29173990, 4160, 6240, "Clement Couturier", []),
  px("fontainebleau", "fontainebleau", 38772250, 7597, 5065, "Lewis Bedar", []),
  px("village", "village", 29659606, 4000, 6000, "Ron Haenen", []),
  px("disney", "disney", 33675421, 4000, 6000, "Luana Scorsoni", ["disney"]),
  px("disney2", "disney", 18455389, 4672, 7008, "Joan Costa", ["disney"]),
  px("couple", "couple", 33598557, 4672, 7008, "amine photographe", ["couples"]),
  px("couple2", "couple", 11545594, 4000, 6000, "Eko Agalarov", ["couples"]),
  px("family", "family", 2253879, 6016, 4016, "Emma Bauso", ["families"]),
  px("cdg", "cdg", 26587969, 6000, 4000, "Bingqian Li", ["airport"]),
  ai("chr", IMG.chr, "70% 55%"),
  ai("chrAirport", IMG.chrAirport),
  ai("interior", IMG.interior),
  ai("carSide", IMG.carSide),
  ai("carLuggage", IMG.carLuggage),
];

export const PHOTOS: Record<string, Photo> = Object.fromEntries(LIST.map((p) => [p.id, p]));
export const photo = (id: string): Photo => PHOTOS[id] ?? LIST[0];

/** Gallery: authentic photography only — car illustrations are excluded. */
export const CURATED = LIST.filter((p) => !p.local);

/** Wide, cinematic frames for the home hero. */
export const HERO_SLIDES = ["eiffelGold", "montmartre", "seine", "bridgeNight"];

export type ReelTarget = "tour" | "versailles" | "disney" | "custom";

/** Horizontal destination journey on the home page. */
export const REEL: { id: string; target: ReelTarget }[] = [
  { id: "eiffelLights", target: "tour" },
  { id: "seine", target: "tour" },
  { id: "montmartreStreet", target: "tour" },
  { id: "louvre", target: "tour" },
  { id: "terrace", target: "tour" },
  { id: "notredame", target: "tour" },
  { id: "versailles", target: "versailles" },
  { id: "giverny", target: "custom" },
  { id: "disney", target: "disney" },
  { id: "village", target: "custom" },
];

const WIDTHS = [480, 800, 1200, 1600, 2400];
export const pxUrl = (base: string, w: number) => `${base}?auto=compress&cs=tinysrgb&w=${w}`;
export const srcOf = (p: Photo, w = 1600) => (p.local ? p.src : pxUrl(p.src, w));
export const srcSetOf = (p: Photo) =>
  p.local ? undefined : WIDTHS.map((w) => `${pxUrl(p.src, w)} ${w}w`).join(", ");
