import { get, set } from "idb-keyval";
import { useSyncExternalStore } from "react";
import { DATA, type DayStatus, type ServiceId } from "../config";
import type { GalleryCat } from "../photos";

/* Owner-managed content, stored in this browser (IndexedDB).
   In demonstration mode this powers the calendar, reviews, gallery and car photos.
   For every visitor to see it, publish the exported JSON files (see config DATA). */

export type ReqStatus = "pending" | "confirmed" | "declined";

export interface Req {
  id: string;
  createdAt: string;
  status: ReqStatus;
  kind: "booking" | "quote";
  service: ServiceId;
  optionId?: string;
  direction?: "from" | "to";
  date: string;
  endDate?: string;
  time?: string;
  /** Owner override of how long the car is busy, in minutes. */
  minutes?: number;
  pax: number;
  adults?: number;
  children?: number;
  childAges?: string;
  days?: number;
  bags?: number;
  cabin?: number;
  pickup?: string;
  dropoff?: string;
  flight?: string;
  hotel?: string;
  destinations?: string[];
  notes?: string;
  childSeat?: boolean;
  price?: number | null;
  name?: string;
  email?: string;
  phone?: string;
  lang?: string;
  source?: "website" | "manual";
}

export interface Review {
  id: string;
  name: string;
  country?: string;
  rating: number;
  text: string;
  service?: ServiceId;
  date?: string;
  sourceName?: string;
  sourceUrl?: string;
  photo?: string;
  consent: boolean;
  published: boolean;
}

export interface GalleryItem {
  id: string;
  src: string;
  w?: number;
  h?: number;
  caption: string;
  category: GalleryCat;
  consent: boolean;
  createdAt: string;
}

/* ── Real photos of the owner's Toyota C-HR ──────────────────────────────── */

export type CarSlot = "front" | "side" | "interior" | "luggage";
export const CAR_SLOTS: CarSlot[] = ["front", "side", "interior", "luggage"];
/** "Soft Paris light": a gentle tonal finish applied to real car photos. */
export const CAR_GRADE = "contrast(1.06) saturate(1.08) brightness(1.03)";

export interface CarPhoto {
  src: string;
  w: number;
  h: number;
  /** focal point kept visible when the photo is cropped, e.g. "50% 60%" */
  pos: string;
  grade: boolean;
  updatedAt: string;
}

export type CarPhotos = Partial<Record<CarSlot, CarPhoto>>;

export interface CMS {
  overrides: Record<string, DayStatus>;
  requests: Req[];
  reviews: Review[];
  photos: GalleryItem[];
  car: CarPhotos;
}

interface PublicContent {
  reviews: Review[];
  photos: GalleryItem[];
  car: CarPhotos;
}

interface Snapshot {
  state: CMS;
  remote: PublicContent | null;
  ready: boolean;
  error: string;
}

const KEY = "bpr-cms-v1";
export const EMPTY_CMS: CMS = { overrides: {}, requests: [], reviews: [], photos: [], car: {} };

let snap: Snapshot = { state: EMPTY_CMS, remote: null, ready: false, error: "" };
const listeners = new Set<() => void>();

function update(patch: Partial<Snapshot>) {
  snap = { ...snap, ...patch };
  listeners.forEach((l) => l());
}

function subscribe(l: () => void) {
  listeners.add(l);
  return () => {
    listeners.delete(l);
  };
}

export const useStore = () => useSyncExternalStore(subscribe, () => snap, () => snap);

function sanitizeCar(raw: unknown): CarPhotos {
  const out: CarPhotos = {};
  if (!raw || typeof raw !== "object") return out;
  for (const slot of CAR_SLOTS) {
    const v = (raw as Record<string, unknown>)[slot] as Partial<CarPhoto> | undefined;
    if (v && typeof v.src === "string" && v.src) {
      out[slot] = {
        src: v.src,
        w: Number(v.w) || 4,
        h: Number(v.h) || 3,
        pos: typeof v.pos === "string" ? v.pos : "50% 50%",
        grade: v.grade !== false,
        updatedAt: typeof v.updatedAt === "string" ? v.updatedAt : "",
      };
    }
  }
  return out;
}

export function sanitize(raw: unknown): CMS {
  const o = (raw && typeof raw === "object" ? raw : {}) as Partial<CMS>;
  return {
    overrides:
      o.overrides && typeof o.overrides === "object" && !Array.isArray(o.overrides) ? o.overrides : {},
    requests: Array.isArray(o.requests) ? o.requests : [],
    reviews: Array.isArray(o.reviews) ? o.reviews : [],
    photos: Array.isArray(o.photos) ? o.photos : [],
    car: sanitizeCar(o.car),
  };
}

async function boot() {
  try {
    const saved = await get(KEY);
    if (saved) update({ state: sanitize(saved) });
  } catch {
    update({ error: "Browser storage is unavailable (private mode?) — changes will not be kept." });
  }
  update({ ready: true });

  if (DATA.contentUrl) {
    try {
      const res = await fetch(DATA.contentUrl, { cache: "no-store" });
      if (!res.ok) throw new Error(String(res.status));
      const j = sanitize(await res.json());
      update({ remote: { reviews: j.reviews, photos: j.photos, car: j.car } });
    } catch {
      /* published file unavailable → keep this browser's content */
    }
  }
}

if (typeof window !== "undefined") void boot();

function commit(next: CMS) {
  update({ state: next });
  set(KEY, next)
    .then(() => {
      if (snap.error) update({ error: "" });
    })
    .catch(() => update({ error: "Could not save — browser storage may be full or disabled." }));
}

export const uid = () =>
  (Date.now().toString(36).slice(-4) + Math.random().toString(36).slice(2, 6)).toUpperCase();

const cur = () => snap.state;

export const cms = {
  setOverride(iso: string, status: DayStatus | null) {
    const overrides = { ...cur().overrides };
    if (status) overrides[iso] = status;
    else delete overrides[iso];
    commit({ ...cur(), overrides });
  },
  addRequest(r: Req) {
    commit({ ...cur(), requests: [r, ...cur().requests] });
  },
  updateRequest(id: string, patch: Partial<Req>) {
    commit({ ...cur(), requests: cur().requests.map((r) => (r.id === id ? { ...r, ...patch } : r)) });
  },
  removeRequest(id: string) {
    commit({ ...cur(), requests: cur().requests.filter((r) => r.id !== id) });
  },
  saveReview(rv: Review) {
    const exists = cur().reviews.some((x) => x.id === rv.id);
    commit({
      ...cur(),
      reviews: exists ? cur().reviews.map((x) => (x.id === rv.id ? rv : x)) : [rv, ...cur().reviews],
    });
  },
  removeReview(id: string) {
    commit({ ...cur(), reviews: cur().reviews.filter((x) => x.id !== id) });
  },
  addPhotos(items: GalleryItem[]) {
    commit({ ...cur(), photos: [...items, ...cur().photos] });
  },
  updatePhoto(id: string, patch: Partial<GalleryItem>) {
    commit({ ...cur(), photos: cur().photos.map((p) => (p.id === id ? { ...p, ...patch } : p)) });
  },
  removePhoto(id: string) {
    commit({ ...cur(), photos: cur().photos.filter((p) => p.id !== id) });
  },
  setCar(slot: CarSlot, p: CarPhoto | null) {
    const car = { ...cur().car };
    if (p) car[slot] = p;
    else delete car[slot];
    commit({ ...cur(), car });
  },
  updateCar(slot: CarSlot, patch: Partial<CarPhoto>) {
    const existing = cur().car[slot];
    if (!existing) return;
    commit({ ...cur(), car: { ...cur().car, [slot]: { ...existing, ...patch } } });
  },
  replace(next: unknown) {
    commit(sanitize(next));
  },
  reset() {
    commit(EMPTY_CMS);
  },
};

/** Public content: the published file when configured, otherwise this browser's (demo). */
export function usePublicContent() {
  const { state, remote, ready } = useStore();
  const src = remote ?? state;
  return {
    reviews: src.reviews.filter((r) => r.published),
    photos: src.photos,
    car: src.car,
    ready,
    live: Boolean(remote),
  };
}

/** Resize + recompress an uploaded photo so pages stay fast. */
export async function compressImage(
  file: File,
  max = 1600,
  quality = 0.82,
): Promise<{ src: string; w: number; h: number }> {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const i = new Image();
      i.onload = () => resolve(i);
      i.onerror = () => reject(new Error("Unreadable image"));
      i.src = url;
    });
    const scale = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas unavailable");
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    return { src: canvas.toDataURL("image/jpeg", quality), w: canvas.width, h: canvas.height };
  } finally {
    URL.revokeObjectURL(url);
  }
}
