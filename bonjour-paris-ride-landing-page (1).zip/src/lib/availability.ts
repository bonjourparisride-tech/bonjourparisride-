import { useCallback, useEffect, useMemo, useState } from "react";
import { CALENDAR, DATA, findOption, isPriced, type DayStatus } from "../config";
import { useStore, type Req } from "./store";

export type PublicStatus = DayStatus | "past" | "closed";
export const STATUSES: DayStatus[] = ["available", "limited", "booked", "blocked"];

/* ── dates (local time, ISO yyyy-mm-dd) ──────────────────────────────────── */

const pad = (n: number) => String(n).padStart(2, "0");
export const toISO = (d: Date) =>
  `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const parseISO = (s: string) => {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1, 12);
};
export const todayISO = () => toISO(new Date());
export const addDays = (s: string, n: number) => {
  const d = parseISO(s);
  d.setDate(d.getDate() + n);
  return toISO(d);
};
export const daysBetween = (a: string, b: string) =>
  Math.round((parseISO(b).getTime() - parseISO(a).getTime()) / 86400000);
export const horizonEndISO = () => {
  const n = new Date();
  return toISO(new Date(n.getFullYear(), n.getMonth() + CALENDAR.horizonMonths + 1, 0, 12));
};
export const isValidISO = (s: unknown): s is string =>
  typeof s === "string" && /^\d{4}-\d{2}-\d{2}$/.test(s);
export const toMin = (t?: string) => {
  if (!t || !/^\d{1,2}:\d{2}/.test(t)) return null;
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
};
export const fmtMin = (m: number) => `${pad(Math.floor(m / 60) % 24)}:${pad(m % 60)}`;

export const isSelectable = (s: PublicStatus) => s === "available" || s === "limited";

/* ── one car, one driver: busy slots & overlap rules ─────────────────────── */

export interface Slot {
  id: string;
  date: string;
  start: number;
  end: number;
}

export function durationOf(r: Pick<Req, "service" | "optionId" | "minutes">): number {
  if (r.minutes && r.minutes > 0) return r.minutes;
  if (isPriced(r.service)) return findOption(r.service, r.optionId)?.minutes ?? 1440;
  return 1440; // custom itineraries block the whole day until the owner sets a duration
}

/** Time slots a journey occupies. No pickup time → the whole day (conservative). */
export function slotsOf(r: Req): Slot[] {
  if (!isValidISO(r.date)) return [];
  if (r.service === "multiday") {
    const end = isValidISO(r.endDate) && r.endDate >= r.date ? r.endDate : r.date;
    const out: Slot[] = [];
    for (let d = r.date; d <= end && out.length < 60; d = addDays(d, 1)) {
      out.push({ id: r.id, date: d, start: 0, end: 1440 });
    }
    return out;
  }
  const start = toMin(r.time);
  if (start === null) return [{ id: r.id, date: r.date, start: 0, end: 1440 }];
  const end = start + durationOf(r);
  if (end <= 1440) return [{ id: r.id, date: r.date, start, end }];
  return [
    { id: r.id, date: r.date, start, end: 1440 },
    { id: r.id, date: addDays(r.date, 1), start: 0, end: Math.min(1440, end - 1440) },
  ];
}

/** Confirmed journeys that would overlap `r` (buffer included). */
export function findConflicts(r: Req, all: Req[]): Req[] {
  const mine = slotsOf(r);
  const buf = CALENDAR.bufferMinutes;
  return all.filter(
    (o) =>
      o.id !== r.id &&
      o.status === "confirmed" &&
      slotsOf(o).some((s) =>
        mine.some((m) => m.date === s.date && m.start < s.end + buf && s.start < m.end + buf),
      ),
  );
}

export function busyByDay(reqs: Req[]): Map<string, Slot[]> {
  const map = new Map<string, Slot[]>();
  for (const r of reqs) {
    if (r.status !== "confirmed") continue;
    for (const s of slotsOf(r)) map.set(s.date, [...(map.get(s.date) ?? []), s]);
  }
  return map;
}

function busyMinutes(slots: Slot[]) {
  const sorted = [...slots].sort((a, b) => a.start - b.start);
  let total = 0;
  let cs = -1;
  let ce = -1;
  for (const s of sorted) {
    if (s.start > ce) {
      if (ce > cs) total += ce - cs;
      cs = s.start;
      ce = s.end;
    } else ce = Math.max(ce, s.end);
  }
  if (ce > cs) total += ce - cs;
  return total;
}

/** Manual status first, then confirmed bookings, then the default rule. */
export function computeStatus(
  iso: string,
  overrides: Record<string, DayStatus>,
  busy: Map<string, Slot[]>,
): DayStatus {
  const manual = overrides[iso];
  if (manual) return manual;
  const slots = busy.get(iso);
  if (slots && slots.length) {
    return busyMinutes(slots) >= CALENDAR.dayCapacityMinutes ? "booked" : "limited";
  }
  return CALENDAR.defaultStatus;
}

/** Public availability file (no names, no details — only day statuses). */
export function exportAvailability(overrides: Record<string, DayStatus>, requests: Req[]) {
  const busy = busyByDay(requests);
  const days: Record<string, DayStatus> = {};
  const end = horizonEndISO();
  for (let d = todayISO(); d <= end; d = addDays(d, 1)) {
    const s = computeStatus(d, overrides, busy);
    if (s !== CALENDAR.defaultStatus) days[d] = s;
  }
  return { updated: new Date().toISOString(), defaultStatus: CALENDAR.defaultStatus, days };
}

/* ── public hook ─────────────────────────────────────────────────────────── */

interface RemoteDays {
  days: Record<string, DayStatus>;
  updated?: string;
}

let remotePromise: Promise<RemoteDays> | null = null;

function loadRemote(): Promise<RemoteDays> {
  if (!remotePromise) {
    remotePromise = fetch(DATA.availabilityUrl, { cache: "no-store" })
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then((j) => {
        const days: Record<string, DayStatus> = {};
        const src = j && typeof j.days === "object" ? (j.days as Record<string, unknown>) : {};
        for (const [k, v] of Object.entries(src)) {
          if (isValidISO(k) && STATUSES.includes(v as DayStatus)) days[k] = v as DayStatus;
        }
        return { days, updated: typeof j?.updated === "string" ? j.updated : undefined };
      });
    remotePromise.catch(() => {
      remotePromise = null; // allow a retry later
    });
  }
  return remotePromise;
}

export function useAvailability() {
  const { state } = useStore();
  const remoteOn = Boolean(DATA.availabilityUrl);
  const [remote, setRemote] = useState<RemoteDays | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    if (!remoteOn) return;
    let alive = true;
    loadRemote()
      .then((r) => alive && setRemote(r))
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, [remoteOn]);

  const busy = useMemo(() => busyByDay(state.requests), [state.requests]);
  const today = todayISO();
  const last = horizonEndISO();

  const statusOf = useCallback(
    (iso: string): PublicStatus => {
      if (iso < today) return "past";
      if (iso > last) return "closed";
      if (remoteOn) return remote?.days[iso] ?? CALENDAR.defaultStatus;
      return computeStatus(iso, state.overrides, busy);
    },
    [today, last, remoteOn, remote, state.overrides, busy],
  );

  return {
    statusOf,
    live: remoteOn && !error,
    loading: remoteOn && !remote && !error,
    error,
  };
}
