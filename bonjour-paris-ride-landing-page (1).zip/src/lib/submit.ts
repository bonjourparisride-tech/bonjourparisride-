import { DATA, isPriced, mailLink, waLink } from "../config";
import type { Dict } from "../i18n/en";
import { optText, type DateStyle } from "../i18n";
import { cms, uid, type Req } from "./store";

export const newRef = () => `BPR-${uid()}`;

export interface Fmt {
  date: (iso: string, style?: DateStyle) => string;
  price: (n: number | null) => string;
}

export function serviceLine(r: Pick<Req, "service" | "optionId">, t: Dict) {
  const base = t.services[r.service];
  if (!isPriced(r.service)) return base;
  const o = optText(t, r.service, r.optionId);
  return o ? `${base} · ${o.l}` : base;
}

/** Human-readable request, in the visitor's language (sent by WhatsApp / email / form). */
export function buildMessage(r: Req, t: Dict, f: Fmt): string {
  const lines: string[] = [t.plan.msgHello, "", `${t.plan.ref}: ${r.id}`];
  const add = (k: string, v?: string | number | null | false) => {
    if (v !== undefined && v !== null && v !== false && v !== "") lines.push(`${k}: ${v}`);
  };
  const day = (iso?: string) => (iso ? `${f.date(iso, "medium")} (${iso})` : undefined);

  add(t.plan.service, serviceLine(r, t));

  if (r.kind === "quote") {
    if (r.service === "multiday") {
      add(t.quote.arrival, day(r.date));
      add(t.quote.departure, day(r.endDate));
      add(t.quote.days, r.days);
    } else {
      add(t.quote.date, day(r.date));
    }
    add(t.quote.adults, r.adults);
    add(t.quote.children, r.children);
    add(t.quote.ages, r.childAges);
    add(t.quote.hotel, r.hotel);
    add(t.quote.dest, r.destinations?.join(", "));
    add(t.quote.pickup, r.pickup);
    add(t.quote.large, r.bags);
    add(t.quote.cabin, r.cabin);
    add(t.quote.requests, r.notes);
  } else {
    const airport = r.service === "airport";
    const fromAirport = airport && r.direction !== "to";
    add(t.plan.date, day(r.date));
    if (airport) add(t.plan.direction, fromAirport ? t.plan.fromAirport : t.plan.toAirport);
    add(fromAirport ? t.plan.landing : t.plan.time, r.time);
    add(t.common.passengers, r.pax);
    add(t.common.suitcases, r.bags);
    add(fromAirport ? t.plan.terminal : t.plan.pickup, r.pickup);
    add(t.plan.flight, r.flight);
    add(airport && !fromAirport ? t.plan.depTerminal : t.plan.dropoff, r.dropoff);
    add(t.plan.details, r.notes);
    add(t.plan.childSeat, r.childSeat ? t.common.yes : false);
    add(t.plan.fixed, r.price != null ? f.price(r.price) : t.plan.quoteNote);
  }

  lines.push("");
  add(t.plan.name, r.name);
  add(t.plan.email, r.email);
  add(t.plan.phone, r.phone);
  return lines.join("\n");
}

export const requestLinks = (r: Req, message: string, t: Dict) => ({
  wa: waLink(message),
  mail: mailLink(`${t.plan.title} — ${r.id}`, message),
});

/** Sends to the configured form endpoint; otherwise keeps the request in this
 *  browser (demo inbox) and the visitor finishes on WhatsApp or by email. */
export async function submitRequest(r: Req, message: string): Promise<{ delivered: boolean }> {
  if (!DATA.formEndpoint) {
    cms.addRequest(r);
    return { delivered: false };
  }
  try {
    const res = await fetch(DATA.formEndpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({
        ...r,
        destinations: r.destinations?.join(", "),
        message,
        _subject: `Bonjour Paris Ride — ${r.id}`,
      }),
    });
    if (!res.ok) throw new Error(String(res.status));
    return { delivered: true };
  } catch {
    cms.addRequest(r);
    return { delivered: false };
  }
}
