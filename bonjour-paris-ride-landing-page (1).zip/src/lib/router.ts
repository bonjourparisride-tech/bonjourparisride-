import { useEffect, useState } from "react";

/* Hash router for the single-file build.
   "#/" home · "#/transfers" · "#/multi-day?tour=b" · "#/legal/privacy" · "#/admin" … */

export type Page =
  | "home"
  | "transfers"
  | "tours"
  | "multi-day"
  | "availability"
  | "custom"
  | "gallery"
  | "reviews"
  | "guide"
  | "about"
  | "faq"
  | "contact"
  | "legal"
  | "admin";

export type NavKey =
  | "home"
  | "transfers"
  | "tours"
  | "multiday"
  | "availability"
  | "custom"
  | "gallery"
  | "reviews"
  | "guide"
  | "about"
  | "faq"
  | "contact";

export interface MenuItem {
  page: Exclude<Page, "legal" | "admin">;
  key: NavKey;
  /** photo shown in the menu preview and "next page" cards */
  photo: string;
  /** hero tone — decides the header colours before scrolling */
  tone: "dark" | "light";
}

export const MENU: MenuItem[] = [
  { page: "home", key: "home", photo: "eiffelGold", tone: "dark" },
  { page: "transfers", key: "transfers", photo: "cdg", tone: "light" },
  { page: "tours", key: "tours", photo: "louvre", tone: "dark" },
  { page: "multi-day", key: "multiday", photo: "versaillesGardens", tone: "light" },
  { page: "availability", key: "availability", photo: "eiffelLights", tone: "dark" },
  { page: "custom", key: "custom", photo: "giverny", tone: "light" },
  { page: "gallery", key: "gallery", photo: "eiffelSunset", tone: "light" },
  { page: "reviews", key: "reviews", photo: "seine", tone: "dark" },
  { page: "guide", key: "guide", photo: "arc", tone: "dark" },
  { page: "about", key: "about", photo: "rooftops", tone: "light" },
  { page: "faq", key: "faq", photo: "montmartreStreet", tone: "dark" },
  { page: "contact", key: "contact", photo: "terrace", tone: "dark" },
];

const PAGES: Page[] = [...MENU.map((m) => m.page), "legal", "admin"];

export const hrefOf = (p: Page, query = "") =>
  (p === "home" ? "#/" : `#/${p}`) + (query ? `?${query}` : "");

export const toneOf = (p: Page): "dark" | "light" =>
  MENU.find((m) => m.page === p)?.tone ?? (p === "legal" ? "dark" : "light");

/** Old one-page anchors keep working. */
const LEGACY: Record<string, Page> = {
  top: "home",
  trust: "home",
  transfers: "transfers",
  tours: "tours",
  multiday: "multi-day",
  destinations: "guide",
  why: "about",
  car: "about",
  stories: "reviews",
  gallery: "gallery",
  availability: "availability",
  quote: "custom",
  faq: "faq",
  contact: "contact",
};

export interface Route {
  page: Page;
  sub: string;
  params: URLSearchParams;
  key: string;
}

export function parseHash(hash: string): Route {
  let h = hash.replace(/^#/, "");
  try {
    h = decodeURIComponent(h);
  } catch {
    /* keep raw */
  }
  if (!h.startsWith("/")) {
    return { page: LEGACY[h] ?? "home", sub: "", params: new URLSearchParams(), key: `legacy:${h}` };
  }
  const [path, query = ""] = h.slice(1).split("?");
  const [p = "", sub = ""] = path.split("/");
  const page = (PAGES as string[]).includes(p) ? (p as Page) : "home";
  return { page, sub, params: new URLSearchParams(query), key: h };
}

export function useRoute() {
  const [route, setRoute] = useState(() => parseHash(window.location.hash));
  useEffect(() => {
    const on = () => setRoute(parseHash(window.location.hash));
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  return route;
}

export function navigate(hash: string) {
  if (window.location.hash === hash) {
    window.dispatchEvent(new HashChangeEvent("hashchange"));
  } else {
    window.location.hash = hash;
  }
}

export function scrollToId(id: string) {
  const el = document.getElementById(id);
  if (!el) return false;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  el.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
  return true;
}
