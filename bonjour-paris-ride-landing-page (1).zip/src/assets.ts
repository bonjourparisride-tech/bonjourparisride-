import chr from "../public/images/hero.jpg";
import chrAirport from "../public/images/airport.jpg";
import interior from "../public/images/interior.jpg";
import carSide from "../public/images/car-side.jpg";
import carLuggage from "../public/images/car-luggage.jpg";

/** The bundled car images are AI ILLUSTRATIONS of the Toyota C-HR model and are
 *  labelled "Illustration" everywhere on the site.
 *
 *  To show your real car:
 *   • easiest — upload your photos in the Owner area (#/admin → Car photos), or
 *   • replace these files with your own photos (same names: hero.jpg = front,
 *     car-side.jpg, interior.jpg, car-luggage.jpg, airport.jpg) and set the flag
 *     below to true, then rebuild. */
export const CAR_FILES_ARE_REAL_PHOTOS = false;

export const IMG = { chr, chrAirport, interior, carSide, carLuggage };
